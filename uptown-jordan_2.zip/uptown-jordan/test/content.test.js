import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { boot, createClient } from './helper.js';

/**
 * Coverage for the reviews, notifications and content surfaces.
 *
 * The review tests matter most: the whole value of a review is that it came
 * from someone who actually bought the thing, so "cannot be faked" is the
 * feature, not a side constraint.
 */

let app;
let origin;

before(async () => {
  app = await boot();
  origin = app.origin;
});

after(async () => {
  await app?.close();
});

const ADDRESS = {
  fullName: 'Review Tester',
  phone: '0791234567',
  governorate: 'amman',
  city: 'Abdoun',
  street: 'Zahran Street 12',
};

async function shopper() {
  const client = createClient(origin);
  await client.bootstrap();
  return client;
}

/** Register, buy the product, and have staff mark it delivered. */
async function buyAndReceive(email, slug, { deliver = true } = {}) {
  const client = await shopper();
  await client.post('/api/register', {
    email,
    password: 'a long enough passphrase',
    fullName: 'Rania Haddad',
  });

  const { body } = await client.get(`/api/products/${slug}`);
  const variant = body.product.variants.find((v) => v.inStock);
  await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

  const placed = await client.post('/api/checkout', {
    email,
    phone: '0791234567',
    paymentMethod: 'cod',
    shipping: ADDRESS,
  });
  assert.equal(placed.status, 200, 'the order must be placed');

  if (deliver) {
    const { markShipped, markDelivered } = await import('../src/services/orders.js');
    await markShipped(placed.body.order.id, { actor: 'test' });
    await markDelivered(placed.body.order.id, { actor: 'test' });
  }

  return { client, order: placed.body.order };
}

async function staffClient(email = 'reviewboss@example.com') {
  const client = await shopper();
  const existing = await client.post('/api/login', {
    email,
    password: 'a long enough passphrase',
  });
  if (existing.status === 200) return client;

  await client.post('/api/register', {
    email,
    password: 'a long enough passphrase',
    fullName: 'Review Boss',
  });
  const { getDb } = await import('../src/db/index.js');
  const db = await getDb();
  db.run("UPDATE users SET role = 'admin' WHERE email_normalized = ?", email);
  db.run('DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE email_normalized = ?)', email);

  const fresh = await shopper();
  await fresh.post('/api/login', { email, password: 'a long enough passphrase' });
  return fresh;
}

describe('reviews — who may write one', () => {
  it('refuses a review from someone not signed in', async () => {
    const client = await shopper();
    const res = await client.post('/api/products/urban-cuts-tee/reviews', {
      rating: 5,
      title: 'Never bought this',
      body: 'But here I am reviewing it anyway, at length.',
    });
    assert.equal(res.status, 401);
  });

  it('refuses a review from a customer who has not bought the piece', async () => {
    const client = await shopper();
    await client.post('/api/register', {
      email: 'nobuy@example.com',
      password: 'a long enough passphrase',
      fullName: 'Has Not Bought',
    });

    const res = await client.post('/api/products/urban-cuts-tee/reviews', {
      rating: 5,
      title: 'Excellent product',
      body: 'I have never owned this but would like to say it is wonderful.',
    });
    assert.equal(res.status, 403);
    assert.match(res.body.error.message, /received this piece/i);
  });

  it('refuses a review while the order is still in transit', async () => {
    const { client } = await buyAndReceive('intransit@example.com', 'minimal-hoodie', {
      deliver: false,
    });

    const res = await client.post('/api/products/minimal-hoodie/reviews', {
      rating: 5,
      title: 'Arrived quickly',
      body: 'Well, it has not arrived yet, but I am optimistic about it.',
    });
    assert.equal(res.status, 403, 'only a delivered order entitles a review');
  });

  it('accepts a review once the order is delivered, and holds it for moderation', async () => {
    const { client } = await buyAndReceive('delivered@example.com', 'acid-wash-boxy-tee');

    const res = await client.post('/api/products/acid-wash-boxy-tee/reviews', {
      rating: 4,
      title: 'Heavier than expected',
      body: 'Properly thick cotton and the boxy cut is true to the photos. Took my usual M.',
    });

    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'pending', 'nothing publishes itself');

    // Not visible to shoppers yet.
    const publicView = await client.get('/api/products/acid-wash-boxy-tee/reviews');
    assert.equal(publicView.body.reviews.count, 0);
    assert.equal(publicView.body.reviews.items.length, 0);
  });

  it('allows only one review per customer per piece', async () => {
    const { client } = await buyAndReceive('twice@example.com', 'summer-drop-shirt');

    const first = await client.post('/api/products/summer-drop-shirt/reviews', {
      rating: 5,
      title: 'Perfect for August',
      body: 'The open weave actually works in Amman heat. Bought a second one.',
    });
    const second = await client.post('/api/products/summer-drop-shirt/reviews', {
      rating: 1,
      title: 'Changed my mind',
      body: 'Actually I would like to review this one a second time, differently.',
    });

    assert.equal(first.status, 200);
    assert.equal(second.status, 409);
  });

  it('lists a delivered piece as reviewable, and stops once reviewed', async () => {
    const { client } = await buyAndReceive('eligible@example.com', 'heritage-terry-crew');

    const before = await client.get('/api/account/reviewable');
    assert.ok(
      before.body.items.some((i) => i.slug === 'heritage-terry-crew'),
      'the delivered piece should be offered for review'
    );

    await client.post('/api/products/heritage-terry-crew/reviews', {
      rating: 5,
      title: 'The best of the terry pieces',
      body: 'Five hundred GSM is no joke. Holds its shape after a dozen washes.',
    });

    const after = await client.get('/api/account/reviewable');
    assert.ok(
      !after.body.items.some((i) => i.slug === 'heritage-terry-crew'),
      'a reviewed piece should drop off the list'
    );
  });
});

describe('reviews — moderation and display', () => {
  it('publishes only what staff release, and reports the average honestly', async () => {
    const { client } = await buyAndReceive('published@example.com', 'relaxed-cargo-pants');
    await client.post('/api/products/relaxed-cargo-pants/reviews', {
      rating: 4,
      title: 'Good cut, roomy thigh',
      body: 'The taper from the knee is exactly right. Sized down one and it was perfect.',
    });

    const staff = await staffClient();
    const queue = await staff.get('/api/admin/reviews?status=pending');
    assert.equal(queue.status, 200);

    const mine = queue.body.reviews.find((r) => r.productSlug === 'relaxed-cargo-pants');
    assert.ok(mine, 'the review should be in the pending queue');
    assert.ok(mine.orderNumber, 'the backing order is recorded for audit');

    const published = await staff.post(`/api/admin/reviews/${mine.id}/moderate`, {
      action: 'publish',
    });
    assert.equal(published.status, 200);
    assert.equal(published.body.status, 'published');

    const shopper2 = await shopper();
    const view = await shopper2.get('/api/products/relaxed-cargo-pants/reviews');
    assert.equal(view.body.reviews.count, 1);
    assert.equal(view.body.reviews.average, 4);
    assert.equal(view.body.reviews.items[0].verifiedPurchase, true);
    assert.match(view.body.reviews.items[0].author, /^Rania H\.$/, 'shortened to first name + initial');
  });

  it('keeps a rejected review off the storefront', async () => {
    const { client } = await buyAndReceive('rejected@example.com', 'capsule-26-jacket');
    await client.post('/api/products/capsule-26-jacket/reviews', {
      rating: 1,
      title: 'CHEAP WATCHES AT EXAMPLE DOT COM',
      body: 'Buy cheap watches at example dot com, best prices, click here now please.',
    });

    const staff = await staffClient();
    const queue = await staff.get('/api/admin/reviews?status=pending');
    const spam = queue.body.reviews.find((r) => r.productSlug === 'capsule-26-jacket');
    await staff.post(`/api/admin/reviews/${spam.id}/moderate`, { action: 'reject' });

    const view = await (await shopper()).get('/api/products/capsule-26-jacket/reviews');
    assert.equal(view.body.reviews.count, 0);
  });

  it('refuses moderation to an ordinary customer', async () => {
    const client = await shopper();
    await client.post('/api/register', {
      email: 'notstaff@example.com',
      password: 'a long enough passphrase',
      fullName: 'Not Staff',
    });
    const res = await client.get('/api/admin/reviews');
    assert.equal(res.status, 403);
  });

  it('ships with no reviews and no invented rating', async () => {
    const client = await shopper();
    const { body } = await client.get('/api/products?limit=20');
    for (const product of body.items) {
      assert.ok(
        product.rating === null || product.rating.count > 0,
        `${product.slug} must not carry a rating with no reviews behind it`
      );
    }
  });
});

describe('newsletter', () => {
  it('requires confirmation before a subscriber is live', async () => {
    const client = await shopper();
    const res = await client.post('/api/newsletter', { email: 'subscriber@example.com' });

    assert.equal(res.status, 200);
    assert.match(res.body.message, /check your email/i);

    const { getDb } = await import('../src/db/index.js');
    const db = await getDb();
    const { sha256 } = await import('../src/core/crypto.js');
    const row = db.get('SELECT confirmed_at FROM newsletter WHERE email_hash = ?', sha256('subscriber@example.com'));
    assert.ok(row, 'the signup is recorded');
    assert.equal(row.confirmed_at, null, 'but not yet mailable');

    const url = new URL(res.body.devConfirmUrl);
    const confirmed = await client.post('/api/newsletter/confirm', {
      token: url.searchParams.get('token'),
    });
    assert.equal(confirmed.status, 200);

    const after = db.get('SELECT confirmed_at FROM newsletter WHERE email_hash = ?', sha256('subscriber@example.com'));
    assert.ok(after.confirmed_at, 'now confirmed');
  });

  it('answers identically for an address already on the list', async () => {
    const client = await shopper();
    const first = await client.post('/api/newsletter', { email: 'repeat@example.com' });
    const second = await client.post('/api/newsletter', { email: 'repeat@example.com' });

    assert.equal(first.status, second.status);
    assert.equal(first.body.message, second.body.message,
      'the response must not reveal whether an address is already subscribed');
  });

  it('rejects an invalid confirmation token', async () => {
    const client = await shopper();
    const res = await client.post('/api/newsletter/confirm', { token: 'x'.repeat(32) });
    assert.equal(res.status, 400);
  });
});

describe('back-in-stock alerts', () => {
  it('records a request for a sold-out size', async () => {
    const buyer = await shopper();
    const { body } = await buyer.get('/api/products/outlet-seasonal-hoodie');
    const size = body.product.variants.find((v) => v.inStock);

    // Buy out the remaining stock.
    await buyer.post('/api/cart/items', { variantId: size.id, qty: size.maxQty });
    await buyer.post('/api/checkout', {
      email: 'clearout@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    });

    const waiter = await shopper();
    const res = await waiter.post(`/api/variants/${size.id}/notify-me`, {
      email: 'waiting@example.com',
    });

    assert.equal(res.status, 200);
    assert.equal(res.body.inStock, false);
    assert.match(res.body.message, /moment/i);
  });

  it('says so immediately when the size is actually in stock', async () => {
    const client = await shopper();
    const { body } = await client.get('/api/products/urban-cuts-tee');
    const size = body.product.variants.find((v) => v.inStock);

    const res = await client.post(`/api/variants/${size.id}/notify-me`, {
      email: 'eager@example.com',
    });
    assert.equal(res.body.inStock, true);
    assert.match(res.body.message, /back in/i);
  });

  it('rejects a malformed email', async () => {
    const client = await shopper();
    const { body } = await client.get('/api/products/urban-cuts-tee');
    const size = body.product.variants[0];
    const res = await client.post(`/api/variants/${size.id}/notify-me`, { email: 'not-an-email' });
    assert.equal(res.status, 422);
  });
});

describe('contact', () => {
  it('records an enquiry and surfaces it to staff', async () => {
    const client = await shopper();
    const res = await client.post('/api/contact', {
      name: 'Layla Odeh',
      email: 'layla@example.com',
      phone: '0791234567',
      topic: 'sizing',
      message: 'I am between M and L in most brands. Which would you suggest for the terry crew?',
    });

    assert.equal(res.status, 200);
    assert.match(res.body.message, /thank you/i);

    const staff = await staffClient();
    const inbox = await staff.get('/api/admin/enquiries?status=open');
    assert.ok(inbox.body.enquiries.some((e) => e.email === 'layla@example.com'));
  });

  it('rejects an enquiry that is too short to act on', async () => {
    const client = await shopper();
    const res = await client.post('/api/contact', {
      name: 'Too Brief',
      email: 'brief@example.com',
      topic: 'general',
      message: 'hi',
    });
    assert.equal(res.status, 422);
  });
});

describe('content pages and metadata', () => {
  const PAGES = [
    '/about', '/size-guide', '/shipping-returns', '/faq',
    '/contact', '/privacy', '/terms',
  ];

  it('serves every brand and policy page', async () => {
    const client = createClient(origin);
    for (const path of PAGES) {
      const res = await client.get(path, { headers: { Accept: 'text/html' } });
      assert.equal(res.status, 200, `${path} -> ${res.status}`);
      assert.match(res.text, /<!doctype html>/i);
      assert.doesNotMatch(res.text, /<!--@/, `${path} has an unexpanded marker`);
    }
  });

  it('renders share metadata on the server for a product', async () => {
    const client = createClient(origin);
    const res = await client.get('/product/vintage-washed-hoodie', {
      headers: { Accept: 'text/html' },
    });

    assert.match(res.text, /<meta property="og:title" content="Vintage Washed Hoodie/);
    assert.match(res.text, /<meta property="og:type" content="product">/);
    assert.match(res.text, /<meta property="og:image" content="https:\/\//);
    assert.match(res.text, /<link rel="canonical" href="[^"]*\/product\/vintage-washed-hoodie">/);
    assert.match(res.text, /"@type":"Product"/);
    assert.match(res.text, /"priceCurrency":"JOD"/);
  });

  it('omits aggregateRating until real reviews exist', async () => {
    const client = createClient(origin);
    const res = await client.get('/product/acid-wash-boxy-tee', {
      headers: { Accept: 'text/html' },
    });
    // This product's only review is still pending in an earlier test.
    assert.doesNotMatch(res.text, /aggregateRating/,
      'structured data must not claim a rating with nothing behind it');
  });

  it('marks transactional pages noindex', async () => {
    const client = createClient(origin);
    for (const path of ['/cart', '/checkout', '/account', '/admin']) {
      const res = await client.get(path, { headers: { Accept: 'text/html' } });
      assert.match(res.text, /<meta name="robots" content="noindex/, `${path} should be noindex`);
    }
  });

  it('keeps the landing page indexable with organisation data', async () => {
    const client = createClient(origin);
    const res = await client.get('/', { headers: { Accept: 'text/html' } });
    assert.doesNotMatch(res.text, /noindex/);
    assert.match(res.text, /"@type":"ClothingStore"/);
    assert.match(res.text, /<title>Uptown Jordan/);
  });

  it('gives the JSON-LD block the CSP nonce', async () => {
    const client = createClient(origin);
    const res = await client.get('/', { headers: { Accept: 'text/html' } });
    const csp = res.headers.get('content-security-policy');
    const nonce = /'nonce-([^']+)'/.exec(csp)[1];
    assert.match(
      res.text,
      new RegExp(`<script nonce="${nonce.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}" type="application/ld\\+json">`),
      'structured data must satisfy the strict script policy'
    );
  });

  it('lists the new pages in robots.txt and the sitemap', async () => {
    const client = createClient(origin);
    const robots = await client.get('/robots.txt');
    assert.match(robots.text, /Allow: \/size-guide/);

    const sitemap = await client.get('/sitemap.xml');
    assert.match(sitemap.text, /\/about/);
    assert.match(sitemap.text, /\/shipping-returns/);
  });
});
