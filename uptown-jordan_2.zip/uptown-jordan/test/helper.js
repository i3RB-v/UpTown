import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';

/**
 * Test harness.
 *
 * Boots a real server on an ephemeral port against a throwaway database, and
 * hands back a tiny client that keeps a cookie jar and echoes the CSRF
 * cookie into the header — i.e. it behaves like a browser, so the tests
 * exercise the same code paths a browser does rather than bypassing the
 * protections under test.
 */

let started = null;

export async function boot() {
  if (started) return started;

  const dir = mkdtempSync(path.join(tmpdir(), 'uj-test-'));
  process.env.NODE_ENV = 'test';
  process.env.DATABASE_FILE = path.join(dir, 'test.db');
  process.env.SESSION_SECRET = 'test-session-secret-0123456789abcdefghijk';
  process.env.CSRF_SECRET = 'test-csrf-secret-0123456789abcdefghijklmn';
  process.env.PASSWORD_PEPPER = 'test-pepper-secret-0123456789abcdefghijk';
  process.env.PAYMENT_WEBHOOK_SECRET = 'test-webhook-secret-0123456789abcdefghi';
  process.env.PAYMENT_PROVIDER = 'mock';
  process.env.LOG_LEVEL = 'silent';
  // Keep the KDF cheap in tests; production uses the configured cost.
  process.env.SCRYPT_N = '1024';
  // Generous budgets so unrelated tests do not trip each other's limits.
  process.env.RL_API_MAX = '100000';
  process.env.RL_AUTH_MAX = '1000';
  process.env.RL_REGISTER_MAX = '1000';
  process.env.RL_CHECKOUT_MAX = '1000';

  const { createApp } = await import('../src/app.js');
  const { seed } = await import('../src/db/seed.js');
  const http = await import('node:http');

  await seed();
  const router = await createApp();
  const server = http.createServer((req, res) => {
    router.handle(req, res).catch(() => {
      if (!res.writableEnded) {
        res.writeHead(500);
        res.end('{}');
      }
    });
  });

  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  const origin = `http://127.0.0.1:${port}`;

  started = {
    origin,
    server,
    dir,
    async close() {
      await new Promise((resolve) => server.close(resolve));
      const { closeDb } = await import('../src/db/index.js');
      await closeDb();
      rmSync(dir, { recursive: true, force: true });
      started = null;
    },
  };
  return started;
}

/** A browser-like client: persistent cookie jar, automatic CSRF echo. */
export function createClient(origin) {
  const jar = new Map();

  const cookieHeader = () =>
    [...jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');

  function absorb(res) {
    const raw = res.headers.getSetCookie?.() ?? [];
    for (const line of raw) {
      const [pair] = line.split(';');
      const eq = pair.indexOf('=');
      if (eq === -1) continue;
      const key = pair.slice(0, eq).trim();
      const value = pair.slice(eq + 1).trim();
      if (value === '' || /Max-Age=0/i.test(line)) jar.delete(key);
      else jar.set(key, value);
    }
  }

  async function request(method, urlPath, body, options = {}) {
    const headers = {
      // Same-origin signal a browser would send — the CSRF origin check
      // requires it for unsafe methods.
      Origin: origin,
      'Sec-Fetch-Site': 'same-origin',
      ...options.headers,
    };
    const cookies = cookieHeader();
    if (cookies) headers.Cookie = cookies;

    if (body !== undefined && !options.raw) {
      headers['Content-Type'] = 'application/json';
    }
    if (!['GET', 'HEAD'].includes(method) && options.csrf !== false) {
      const token = jar.get('uj_csrf');
      if (token) headers['x-csrf-token'] = decodeURIComponent(token);
    }
    if (options.csrfToken) headers['x-csrf-token'] = options.csrfToken;

    const res = await fetch(`${origin}${urlPath}`, {
      method,
      headers,
      body: body === undefined ? undefined : options.raw ? body : JSON.stringify(body),
      redirect: 'manual',
    });
    absorb(res);

    const text = await res.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      /* HTML pages and plain-text errors are fine */
    }
    return { status: res.status, headers: res.headers, body: json, text };
  }

  return {
    jar,
    get: (p, o) => request('GET', p, undefined, o),
    post: (p, b, o) => request('POST', p, b, o),
    patch: (p, b, o) => request('PATCH', p, b, o),
    delete: (p, b, o) => request('DELETE', p, b, o),
    /** Fetch a CSRF token, as the real front-end does on boot. */
    async bootstrap() {
      await request('GET', '/api/csrf');
      return this;
    },
  };
}
