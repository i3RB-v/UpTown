import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { boot, createClient } from './helper.js';

/**
 * Functional coverage of the commerce paths: the cart, the two checkout
 * routes, inventory movement through an order's life, and the admin API.
 */

let app;
let origin;

before(async () => {
  app = await boot();
  origin = app.origin;
});

after(async () => {
  await app?.close();
});

const ADDRESS = {
  fullName: 'Hisham Al Khatib',
  phone: '0791234567',
  governorate: 'amman',
  city: 'Abdoun',
  street: 'Zahran Street 12',
};

async function shopper() {
  const client = createClient(origin);
  await client.bootstrap();
  return client;
}

async function variantOf(client, slug, size) {
  const { body } = await client.get(`/api/products/${slug}`);
  const variant = size
    ? body.product.variants.find((v) => v.size === size)
    : body.product.variants.find((v) => v.inStock);
  return { product: body.product, variant };
}

/** Promote a user to admin directly, the way create-admin.js does. */
async function promote(email) {
  const { getDb } = await import('../src/db/index.js');
  const db = await getDb();
  db.run("UPDATE users SET role = 'admin' WHERE email_normalized = ?", email);
  db.run('DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE email_normalized = ?)', email);
}

describe('catalogue', () => {
  it('lists products with prices formatted in dinar', async () => {
    const client = await shopper();
    const { body } = await client.get('/api/products?limit=5');
    assert.ok(body.total >= 12);
    assert.match(body.items[0].price, /^\d+\.\d{3}$/);
  });

  it('filters by collection', async () => {
    const client = await shopper();
    const { body } = await client.get('/api/products?collection=hoodies');
    assert.ok(body.items.length > 0);
    for (const item of body.items) assert.equal(item.collection.slug, 'hoodies');
  });

  it('does not publish exact stock counts to shoppers', async () => {
    const client = await shopper();
    const { body } = await client.get('/api/products/vintage-washed-hoodie');
    for (const variant of body.product.variants) {
      assert.equal(variant.stock, undefined, 'raw stock must not be exposed');
      assert.equal(variant.reserved, undefined, 'reservations must not be exposed');
      assert.equal(typeof variant.inStock, 'boolean');
    }
  });

  it('404s on an unknown slug', async () => {
    const client = await shopper();
    const res = await client.get('/api/products/does-not-exist');
    assert.equal(res.status, 404);
  });
});

describe('cart', () => {
  it('adds, updates and removes lines, recomputing totals each time', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'acid-wash-boxy-tee');

    let res = await client.post('/api/cart/items', { variantId: variant.id, qty: 2 });
    assert.equal(res.body.cart.count, 2);
    assert.equal(res.body.cart.subtotalFils, 44_000);

    res = await client.patch(`/api/cart/items/${variant.id}`, { qty: 1 });
    assert.equal(res.body.cart.count, 1);
    assert.equal(res.body.cart.subtotalFils, 22_000);

    res = await client.delete(`/api/cart/items/${variant.id}`);
    assert.equal(res.body.cart.count, 0);
    assert.equal(res.body.cart.totalFils, 0);
  });

  it('charges delivery below the free threshold and not above it', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'acid-wash-boxy-tee');

    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });
    let res = await client.get('/api/cart?governorate=aqaba');
    assert.equal(res.body.cart.shippingFils, 5_000, 'Aqaba is the far rate');
    assert.equal(res.body.cart.totalFils, 27_000);

    await client.patch(`/api/cart/items/${variant.id}`, { qty: 3 });
    res = await client.get('/api/cart?governorate=aqaba');
    assert.equal(res.body.cart.subtotalFils, 66_000);
    assert.equal(res.body.cart.shippingFils, 0, 'free above 50.000 JOD');
    assert.equal(res.body.cart.totalFils, 66_000);
  });

  it('keeps separate shoppers’ bags separate', async () => {
    const a = await shopper();
    const b = await shopper();
    const { variant } = await variantOf(a, 'urban-cuts-tee');

    await a.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    const mine = await a.get('/api/cart');
    const theirs = await b.get('/api/cart');
    assert.equal(mine.body.cart.count, 1);
    assert.equal(theirs.body.cart.count, 0);
  });

  it('rejects an unknown governorate', async () => {
    const client = await shopper();
    const res = await client.post('/api/shipping/quote', { governorate: 'atlantis' });
    assert.equal(res.status, 422);
  });
});

describe('cash-on-delivery checkout', () => {
  it('places an order, moves stock into reservation and empties the bag', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'heritage-terry-crew', 'M');

    const before = await client.get('/api/products/heritage-terry-crew');
    const beforeVariant = before.body.product.variants.find((v) => v.size === 'M');

    await client.post('/api/cart/items', { variantId: variant.id, qty: 2 });
    const cart = await client.get('/api/cart?governorate=amman');

    const res = await client.post('/api/checkout', {
      email: 'cod@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
      expectedTotalFils: cart.body.cart.totalFils,
    });

    assert.equal(res.status, 200);
    assert.match(res.body.order.number, /^UJ-\d{4}-[A-Z0-9]{5}$/);
    assert.equal(res.body.order.paymentMethod, 'cod');
    assert.equal(res.body.order.paymentStatus, 'unpaid');
    assert.ok(res.body.lookupToken.length >= 16);

    const emptied = await client.get('/api/cart');
    assert.equal(emptied.body.cart.count, 0, 'the bag is cleared on success');

    // Two units are now held, so availability drops even though nothing shipped.
    const afterRes = await client.get('/api/products/heritage-terry-crew');
    const afterVariant = afterRes.body.product.variants.find((v) => v.size === 'M');
    if (beforeVariant.maxQty > 2) {
      assert.equal(afterVariant.maxQty, beforeVariant.maxQty - 2);
    }
  });

  it('refuses to check out an empty bag', async () => {
    const client = await shopper();
    const res = await client.post('/api/checkout', {
      email: 'empty@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    });
    assert.equal(res.status, 400);
  });

  it('returns the same order for a repeated idempotency key', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'summer-drop-shirt');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    const payload = {
      email: 'idem@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    };
    const headers = { 'Idempotency-Key': 'repeat-me-please' };

    const first = await client.post('/api/checkout', payload, { headers });
    const second = await client.post('/api/checkout', payload, { headers });

    assert.equal(first.status, 200);
    assert.equal(second.status, 200);
    assert.equal(first.body.order.number, second.body.order.number, 'one order, not two');
    assert.equal(second.body.idempotentReplay, true);
  });

  it('validates the address', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'urban-cuts-tee');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    const res = await client.post('/api/checkout', {
      email: 'not-an-email',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    });
    assert.equal(res.status, 422);
    assert.equal(res.body.error.details.field, 'email');
  });

  it('normalises Jordanian mobile numbers', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'urban-cuts-tee');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    const placed = await client.post('/api/checkout', {
      email: 'phone@example.com',
      phone: '+962 79 123 4567',
      paymentMethod: 'cod',
      shipping: { ...ADDRESS, phone: '0791234567' },
    });
    assert.equal(placed.status, 200);

    const order = await client.post('/api/orders/lookup', {
      number: placed.body.order.number,
      token: placed.body.lookupToken,
    });
    assert.equal(order.body.order.address.phone, '+962791234567');
  });
});

describe('card checkout', () => {
  it('runs intent → hosted page → signed webhook → paid', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'capsule-26-jacket', 'M');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    const placed = await client.post('/api/checkout', {
      email: 'card-flow@example.com',
      phone: '0791234567',
      paymentMethod: 'card',
      shipping: ADDRESS,
    });
    assert.equal(placed.status, 200);
    assert.ok(placed.body.payment.redirectUrl.startsWith('/pay/pi_'));

    const reference = placed.body.payment.reference;

    const intent = await client.get(`/api/pay/${reference}/intent`);
    assert.equal(intent.status, 200);
    assert.equal(intent.body.amountFils, placed.body.order.totalFils);
    assert.equal(intent.body.status, 'created');

    const paid = await client.post(`/api/pay/${reference}/complete`, { outcome: 'succeed' });
    assert.equal(paid.status, 200);
    assert.equal(paid.body.applied, true);

    const order = await client.post('/api/orders/lookup', {
      number: placed.body.order.number,
      token: placed.body.lookupToken,
    });
    assert.equal(order.body.order.paymentStatus, 'paid');
    assert.equal(order.body.order.status, 'paid');
  });

  it('leaves the order unpaid when the card is declined', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'everyday-runner');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    const placed = await client.post('/api/checkout', {
      email: 'declined@example.com',
      phone: '0791234567',
      paymentMethod: 'card',
      shipping: ADDRESS,
    });
    const failed = await client.post(`/api/pay/${placed.body.payment.reference}/complete`, {
      outcome: 'fail',
    });
    assert.equal(failed.status, 200);

    const order = await client.post('/api/orders/lookup', {
      number: placed.body.order.number,
      token: placed.body.lookupToken,
    });
    assert.equal(order.body.order.paymentStatus, 'failed');
    assert.notEqual(order.body.order.status, 'paid');
  });

  it('refuses to process the same payment session twice', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'minimal-hoodie');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    const placed = await client.post('/api/checkout', {
      email: 'double@example.com',
      phone: '0791234567',
      paymentMethod: 'card',
      shipping: ADDRESS,
    });
    const reference = placed.body.payment.reference;

    const first = await client.post(`/api/pay/${reference}/complete`, { outcome: 'succeed' });
    const second = await client.post(`/api/pay/${reference}/complete`, { outcome: 'succeed' });

    assert.equal(first.status, 200);
    assert.equal(second.status, 400);
  });
});

describe('inventory', () => {
  it('cannot be oversold by concurrent checkouts', async () => {
    // outlet-seasonal-hoodie XL was seeded with exactly 1 unit.
    const probe = await shopper();
    const { variant } = await variantOf(probe, 'outlet-seasonal-hoodie', 'XL');
    assert.ok(variant.inStock);

    const buyers = await Promise.all([shopper(), shopper(), shopper()]);
    for (const buyer of buyers) {
      await buyer.post('/api/cart/items', { variantId: variant.id, qty: 1 });
    }

    const results = await Promise.all(
      buyers.map((buyer, i) =>
        buyer.post('/api/checkout', {
          email: `race${i}@example.com`,
          phone: '0791234567',
          paymentMethod: 'cod',
          shipping: ADDRESS,
        })
      )
    );

    const succeeded = results.filter((r) => r.status === 200);
    const rejected = results.filter((r) => r.status === 409);

    assert.equal(succeeded.length, 1, 'exactly one buyer may win the last unit');
    assert.equal(rejected.length, 2, 'the others get a clean sold-out conflict');

    const after = await probe.get('/api/products/outlet-seasonal-hoodie');
    const xl = after.body.product.variants.find((v) => v.size === 'XL');
    assert.equal(xl.inStock, false);
  });

  it('returns reserved units to stock when an order is cancelled', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'signature-oversize-crew', 'L');

    const before = await client.get('/api/products/signature-oversize-crew');
    const beforeQty = before.body.product.variants.find((v) => v.size === 'L').maxQty;

    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });
    const placed = await client.post('/api/checkout', {
      email: 'cancel-me@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    });

    const { cancel } = await import('../src/services/orders.js');
    await cancel(placed.body.order.id, { reason: 'test' });

    const after = await client.get('/api/products/signature-oversize-crew');
    const afterQty = after.body.product.variants.find((v) => v.size === 'L').maxQty;
    assert.equal(afterQty, beforeQty, 'availability is restored');
  });
});

describe('accounts', () => {
  it('carries a guest bag into the account at sign-in', async () => {
    const client = await shopper();
    const { variant } = await variantOf(client, 'relaxed-cargo-pants');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });

    await client.post('/api/register', {
      email: 'merge@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Merge Test',
    });

    const cart = await client.get('/api/cart');
    assert.equal(cart.body.cart.count, 1, 'the guest bag survives registration');
  });

  it('saves addresses and lists past orders', async () => {
    const client = await shopper();
    await client.post('/api/register', {
      email: 'history@example.com',
      password: 'a reasonable passphrase',
      fullName: 'History Test',
      phone: '0791234567',
    });

    const saved = await client.post('/api/account/addresses', {
      label: 'Home',
      ...ADDRESS,
      isDefault: true,
    });
    assert.equal(saved.status, 200);
    assert.equal(saved.body.addresses.length, 1);
    assert.equal(saved.body.addresses[0].isDefault, true);

    const { variant } = await variantOf(client, 'urban-cuts-tee');
    await client.post('/api/cart/items', { variantId: variant.id, qty: 1 });
    await client.post('/api/checkout', {
      email: 'history@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    });

    const orders = await client.get('/api/account/orders');
    assert.equal(orders.body.orders.length, 1);
  });

  it('changes a password and signs out other devices', async () => {
    const laptop = await shopper();
    await laptop.post('/api/register', {
      email: 'devices@example.com',
      password: 'the original passphrase',
      fullName: 'Two Devices',
    });

    const phone = await shopper();
    await phone.post('/api/login', {
      email: 'devices@example.com',
      password: 'the original passphrase',
    });
    assert.equal((await phone.get('/api/me')).body.user.email, 'devices@example.com');

    const changed = await laptop.post('/api/account/password', {
      currentPassword: 'the original passphrase',
      newPassword: 'a brand new passphrase',
    });
    assert.equal(changed.status, 200);

    assert.equal((await laptop.get('/api/me')).body.user.email, 'devices@example.com',
      'the device that changed it stays signed in');
    assert.equal((await phone.get('/api/me')).body.user, null,
      'every other device is signed out');
  });

  it('completes a password reset and invalidates the token', async () => {
    const client = await shopper();
    await client.post('/api/register', {
      email: 'forgot@example.com',
      password: 'a mislaid brass lantern',
      fullName: 'Forgetful',
    });
    await client.post('/api/logout', {});
    await client.bootstrap();

    const asked = await client.post('/api/password/forgot', { email: 'forgot@example.com' });
    const token = asked.body.devResetToken;
    assert.ok(token, 'development mode returns the token in place of an email');

    const reset = await client.post('/api/password/reset', {
      token,
      password: 'a replacement passphrase',
    });
    assert.equal(reset.status, 200);

    const reuse = await client.post('/api/password/reset', {
      token,
      password: 'yet another passphrase',
    });
    assert.equal(reuse.status, 400, 'a reset token is single-use');

    const signedIn = await client.post('/api/login', {
      email: 'forgot@example.com',
      password: 'a replacement passphrase',
    });
    assert.equal(signedIn.status, 200);
  });
});

describe('admin', () => {
  it('walks an order through its lifecycle and decrements stock on shipment', async () => {
    const buyer = await shopper();
    const { variant } = await variantOf(buyer, 'uptown-club-set', 'L');
    await buyer.post('/api/cart/items', { variantId: variant.id, qty: 1 });
    const placed = await buyer.post('/api/checkout', {
      email: 'lifecycle@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    });
    const orderId = placed.body.order.id;

    const staff = await shopper();
    await staff.post('/api/register', {
      email: 'boss@example.com',
      password: 'a reasonable passphrase',
      fullName: 'The Boss',
    });
    await promote('boss@example.com');
    await staff.post('/api/logout', {});
    await staff.bootstrap();
    await staff.post('/api/login', {
      email: 'boss@example.com',
      password: 'a reasonable passphrase',
    });

    const stats = await staff.get('/api/admin/stats');
    assert.equal(stats.status, 200);
    assert.ok(stats.body.orderCount > 0);

    const list = await staff.get('/api/admin/orders?status=pending');
    assert.equal(list.status, 200);
    assert.ok(list.body.items.some((o) => o.id === orderId));

    const shipped = await staff.post(`/api/admin/orders/${orderId}/transition`, {
      action: 'mark_shipped',
    });
    assert.equal(shipped.status, 200);
    assert.equal(shipped.body.order.status, 'shipped');

    const delivered = await staff.post(`/api/admin/orders/${orderId}/transition`, {
      action: 'mark_delivered',
    });
    assert.equal(delivered.body.order.status, 'delivered');
    assert.equal(delivered.body.order.paymentStatus, 'paid', 'COD settles on delivery');

    // Shipping moved the unit out of both stock and reservation.
    const { getDb } = await import('../src/db/index.js');
    const db = await getDb();
    const row = db.get('SELECT stock, reserved FROM variants WHERE id = ?', variant.id);
    assert.equal(row.reserved, 0);

    // And the action is on the record.
    const audit = await staff.get('/api/admin/audit?limit=20');
    assert.ok(
      audit.body.entries.some((e) => e.action === 'order.mark_shipped'),
      'privileged actions are audited'
    );
  });

  it('will not let stock drop below units held by open orders', async () => {
    const buyer = await shopper();
    const { variant } = await variantOf(buyer, 'summer-drop-shirt', 'M');
    await buyer.post('/api/cart/items', { variantId: variant.id, qty: 2 });
    await buyer.post('/api/checkout', {
      email: 'holds-stock@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: ADDRESS,
    });

    const staff = await shopper();
    await staff.post('/api/login', {
      email: 'boss@example.com',
      password: 'a reasonable passphrase',
    });

    const res = await staff.patch(`/api/admin/variants/${variant.id}`, { stock: 0 });
    assert.equal(res.status, 409);
    assert.match(res.body.error.message, /held by open orders/i);
  });

  it('creates a product and its variants', async () => {
    const staff = await shopper();
    await staff.post('/api/login', {
      email: 'boss@example.com',
      password: 'a reasonable passphrase',
    });

    const created = await staff.post('/api/admin/products', {
      slug: 'test-only-piece',
      title: 'Test Only Piece',
      subtitle: 'Created by the suite',
      price: '44.500',
      status: 'active',
    });
    assert.equal(created.status, 200);

    const variant = await staff.post(`/api/admin/products/${created.body.id}/variants`, {
      sku: 'TESTONLY-M',
      size: 'M',
      stock: 5,
    });
    assert.equal(variant.status, 200);

    const shopfront = await staff.get('/api/products/test-only-piece');
    assert.equal(shopfront.status, 200);
    assert.equal(shopfront.body.product.price, '44.500');
    assert.equal(shopfront.body.product.variants.length, 1);
  });

  it('rejects a duplicate SKU', async () => {
    const staff = await shopper();
    await staff.post('/api/login', {
      email: 'boss@example.com',
      password: 'a reasonable passphrase',
    });
    const { body } = await staff.get('/api/admin/products?search=Test Only Piece');
    const product = body.items.find((p) => p.slug === 'test-only-piece');

    const res = await staff.post(`/api/admin/products/${product.id}/variants`, {
      sku: 'TESTONLY-M',
      size: 'L',
      stock: 3,
    });
    assert.equal(res.status, 409);
  });
});

describe('pages and health', () => {
  it('serves every storefront page', async () => {
    const client = createClient(origin);
    for (const path of ['/', '/shop', '/cart', '/checkout', '/order', '/login', '/account', '/admin']) {
      const res = await client.get(path, { headers: { Accept: 'text/html' } });
      assert.equal(res.status, 200, `${path} -> ${res.status}`);
      assert.match(res.text, /<!doctype html>/i);
    }
  });

  it('expands shared partials into pages', async () => {
    const client = createClient(origin);
    const res = await client.get('/shop', { headers: { Accept: 'text/html' } });
    assert.match(res.text, /class="site-head"/, 'the header partial is inlined');
    assert.match(res.text, /class="site-foot"/, 'the footer partial is inlined');
    assert.doesNotMatch(res.text, /<!--@header-->/, 'no unexpanded markers remain');
  });

  it('serves a product page for a real slug and 404s otherwise', async () => {
    const client = createClient(origin);
    const ok = await client.get('/product/vintage-washed-hoodie', { headers: { Accept: 'text/html' } });
    assert.equal(ok.status, 200);

    const missing = await client.get('/no-such-page', { headers: { Accept: 'text/html' } });
    assert.equal(missing.status, 404);
    assert.match(missing.text, /out of stock/i, 'the branded 404 page is served');
  });

  it('reports database health', async () => {
    const client = createClient(origin);
    const res = await client.get('/api/healthz');
    assert.equal(res.status, 200);
    assert.equal(res.body.ok, true);
    assert.equal(res.body.database.foreignKeyViolations, 0);
  });

  it('serves robots.txt and a sitemap', async () => {
    const client = createClient(origin);
    const robots = await client.get('/robots.txt');
    assert.match(robots.text, /Disallow: \/admin/);

    const sitemap = await client.get('/sitemap.xml');
    assert.match(sitemap.text, /<urlset/);
    assert.match(sitemap.text, /\/product\//);
  });
});
