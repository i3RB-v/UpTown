import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { boot, createClient } from './helper.js';

/**
 * These tests are the security claims, executable.
 *
 * Each one attempts a specific attack against a running server and asserts
 * that it fails. If someone later "simplifies" a guard away, one of these
 * goes red.
 */

let app;
let origin;

before(async () => {
  app = await boot();
  origin = app.origin;
});

after(async () => {
  await app?.close();
});

async function anyVariantId(client) {
  const { body } = await client.get('/api/products/vintage-washed-hoodie');
  return body.product.variants.find((v) => v.inStock).id;
}

describe('CSRF', () => {
  it('rejects a state-changing request with no token', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);

    const res = await client.post('/api/cart/items', { variantId, qty: 1 }, {
      csrf: false,
      headers: { 'x-csrf-token': '' },
    });
    assert.equal(res.status, 403);
    assert.equal(res.body.error.code, 'forbidden');
  });

  it('rejects a forged token that was not signed by the server', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);

    const forged = `v1.AAAAAAAAAAAAAAAA.${Date.now() + 60_000}.${'f'.repeat(64)}`;
    client.jar.set('uj_csrf', forged);

    const res = await client.post('/api/cart/items', { variantId, qty: 1 });
    assert.equal(res.status, 403);
  });

  it('rejects a cross-site request even when it carries a valid token', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);

    const res = await client.post('/api/cart/items', { variantId, qty: 1 }, {
      headers: { Origin: 'https://evil.example', 'Sec-Fetch-Site': 'cross-site' },
    });
    assert.equal(res.status, 403);
  });
});

describe('price integrity', () => {
  it('ignores a price sent by the client', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);

    // Every field a hopeful attacker might try.
    await client.post('/api/cart/items', {
      variantId,
      qty: 1,
      price: 1,
      priceFils: 1,
      unitFils: 1,
      lineFils: 1,
      total: 0,
    });

    const { body } = await client.get('/api/cart');
    assert.equal(body.cart.lines.length, 1);
    assert.equal(body.cart.lines[0].unitFils, 38_000, 'unit price must come from the catalogue');
    assert.equal(body.cart.subtotalFils, 38_000);
  });

  it('refuses checkout when the client total disagrees with the server total', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);
    await client.post('/api/cart/items', { variantId, qty: 1 });

    const res = await client.post('/api/checkout', {
      email: 'tamper@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: {
        fullName: 'Tamper Test',
        phone: '0791234567',
        governorate: 'amman',
        city: 'Abdoun',
        street: 'Zahran 1',
      },
      expectedTotalFils: 1,
    });

    assert.equal(res.status, 400);
    assert.match(res.body.error.message, /bag changed/i);
  });

  it('prices the order from the catalogue, not the request', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);
    await client.post('/api/cart/items', { variantId, qty: 2 });

    const res = await client.post('/api/checkout', {
      email: 'priced@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      subtotal_fils: 1,
      total_fils: 1,
      shipping_fils: 0,
      shipping: {
        fullName: 'Priced Correctly',
        phone: '0791234567',
        governorate: 'amman',
        city: 'Abdoun',
        street: 'Zahran 1',
      },
    });

    assert.equal(res.status, 200);
    // 2 x 38.000 = 76.000, over the 50.000 free-shipping threshold.
    assert.equal(res.body.order.totalFils, 76_000);
  });
});

describe('injection and traversal', () => {
  it('treats SQL metacharacters in search as literal text', async () => {
    const client = createClient(origin);
    const res = await client.get(
      `/api/products?search=${encodeURIComponent("'; DROP TABLE products; --")}`
    );
    assert.equal(res.status, 200);
    assert.equal(res.body.items.length, 0);

    // The table is still there.
    const after = await client.get('/api/products?limit=1');
    assert.equal(after.status, 200);
    assert.ok(after.body.total > 0, 'products table must survive');
  });

  it('cannot be steered by an injected ORDER BY', async () => {
    const client = createClient(origin);
    const res = await client.get('/api/products?sort=price_asc;DELETE%20FROM%20users');
    // The sort value is mapped through a fixed table, so an unknown value
    // simply falls back to the default rather than reaching SQL.
    // The value is validated against a fixed allow-list before it can reach
    // SQL, so it is rejected outright rather than interpolated.
    assert.equal(res.status, 422);

    const users = await client.get('/api/products?limit=1');
    assert.equal(users.status, 200, 'the database must be intact');
  });

  it('refuses path traversal on static assets', async () => {
    const client = createClient(origin);
    for (const attempt of [
      '/assets/../../package.json',
      '/assets/%2e%2e%2f%2e%2e%2fpackage.json',
      '/assets/....//....//package.json',
    ]) {
      const res = await client.get(attempt);
      assert.ok(res.status === 400 || res.status === 404, `${attempt} -> ${res.status}`);
      assert.ok(!res.text.includes('"name": "uptown-jordan"'), 'must not serve package.json');
    }
  });

  it('refuses a body with a __proto__ key', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const res = await client.post('/api/register', {
      email: 'proto@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Proto',
      __proto__: { role: 'admin' },
    });
    // Either rejected outright, or the key is dropped — never applied.
    assert.ok(res.status === 422 || res.status === 200);
    assert.equal({}.role, undefined, 'Object.prototype must be untouched');
  });
});

describe('privilege boundaries', () => {
  it('refuses the admin API to an anonymous caller', async () => {
    const client = createClient(origin);
    const res = await client.get('/api/admin/stats');
    assert.equal(res.status, 401);
  });

  it('refuses the admin API to an ordinary customer', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    await client.post('/api/register', {
      email: 'ordinary@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Ordinary Customer',
    });

    for (const path of ['/api/admin/stats', '/api/admin/orders', '/api/admin/audit']) {
      const res = await client.get(path);
      assert.equal(res.status, 403, `${path} must be forbidden`);
    }
  });

  it('will not let a customer escalate their own role', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    await client.post('/api/register', {
      email: 'climber@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Role Climber',
    });

    await client.patch('/api/account', {
      fullName: 'Role Climber',
      role: 'admin',
      status: 'active',
    });

    const me = await client.get('/api/me');
    assert.equal(me.body.user.role, 'customer');
  });

  it('will not show one customer another customer’s order', async () => {
    const a = createClient(origin);
    await a.bootstrap();
    await a.post('/api/register', {
      email: 'owner@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Order Owner',
    });
    const variantId = await anyVariantId(a);
    await a.post('/api/cart/items', { variantId, qty: 1 });
    const placed = await a.post('/api/checkout', {
      email: 'owner@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: {
        fullName: 'Order Owner', phone: '0791234567',
        governorate: 'amman', city: 'Abdoun', street: 'Zahran 1',
      },
    });
    assert.equal(placed.status, 200);

    const b = createClient(origin);
    await b.bootstrap();
    await b.post('/api/register', {
      email: 'snoop@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Snooper',
    });

    const res = await b.get(`/api/account/orders/${placed.body.order.id}`);
    assert.equal(res.status, 404);
  });

  it('requires the lookup token, not just the order number', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);
    await client.post('/api/cart/items', { variantId, qty: 1 });
    const placed = await client.post('/api/checkout', {
      email: 'guest@example.com',
      phone: '0791234567',
      paymentMethod: 'cod',
      shipping: {
        fullName: 'Guest Buyer', phone: '0791234567',
        governorate: 'irbid', city: 'Irbid', street: 'University St',
      },
    });

    const guessed = await client.post('/api/orders/lookup', {
      number: placed.body.order.number,
      token: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    });
    assert.equal(guessed.status, 404);

    const correct = await client.post('/api/orders/lookup', {
      number: placed.body.order.number,
      token: placed.body.lookupToken,
    });
    assert.equal(correct.status, 200);
  });
});

describe('authentication', () => {
  it('gives the same answer for an unknown address and a wrong password', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    await client.post('/api/register', {
      email: 'known@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Known User',
    });
    await client.post('/api/logout', {});
    await client.bootstrap(); // logout clears the CSRF token; a browser refetches it

    const unknown = await client.post('/api/login', {
      email: 'nobody-here@example.com',
      password: 'a reasonable passphrase',
    });
    const wrong = await client.post('/api/login', {
      email: 'known@example.com',
      password: 'definitely the wrong one',
    });

    assert.equal(unknown.status, wrong.status);
    assert.equal(unknown.body.error.message, wrong.body.error.message);
  });

  it('does not reveal whether an address is already registered', async () => {
    const client = createClient(origin);
    await client.bootstrap();

    const first = await client.post('/api/register', {
      email: 'duplicate@example.com',
      password: 'a reasonable passphrase',
      fullName: 'First',
    });
    await client.post('/api/logout', {});
    await client.bootstrap();

    const second = await client.post('/api/register', {
      email: 'duplicate@example.com',
      password: 'a different passphrase',
      fullName: 'Second',
    });

    assert.equal(first.status, second.status);
    assert.equal(second.body.created, true, 'the response shape must not differ');
    assert.equal(second.body.user, null, 'but no session is granted');

    const me = await client.get('/api/me');
    assert.equal(me.body.user, null, 'the impostor must not be signed in');
  });

  it('rotates the session id on sign-in', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    await client.post('/api/register', {
      email: 'rotate@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Rotation Test',
    });
    const first = client.jar.get('uj_sid');
    await client.post('/api/logout', {});
    await client.bootstrap();
    await client.post('/api/login', {
      email: 'rotate@example.com',
      password: 'a reasonable passphrase',
    });
    const second = client.jar.get('uj_sid');

    assert.ok(first && second);
    assert.notEqual(first, second, 'a new session id must be issued at sign-in');
  });

  it('rejects a weak password', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const res = await client.post('/api/register', {
      email: 'weak@example.com',
      password: 'password123',
      fullName: 'Weak Password',
    });
    assert.equal(res.status, 400);
  });

  it('invalidates the session cookie after logout', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    await client.post('/api/register', {
      email: 'bye@example.com',
      password: 'a reasonable passphrase',
      fullName: 'Goodbye',
    });
    const sid = client.jar.get('uj_sid');
    await client.post('/api/logout', {});

    // Replay the old cookie explicitly.
    client.jar.set('uj_sid', sid);
    const me = await client.get('/api/me');
    assert.equal(me.body.user, null, 'a logged-out session id must not authenticate');
  });
});

describe('payment webhooks', () => {
  it('rejects an unsigned webhook', async () => {
    const client = createClient(origin);
    const res = await client.post(
      '/api/webhooks/payments',
      JSON.stringify({ id: 'evt_forged', type: 'payment.succeeded', data: { reference: 'pi_x' } }),
      { raw: true, headers: { 'Content-Type': 'application/json' } }
    );
    assert.equal(res.status, 400);
  });

  it('rejects a webhook with a wrong signature', async () => {
    const client = createClient(origin);
    const body = JSON.stringify({ id: 'evt_bad', type: 'payment.succeeded', data: { reference: 'pi_x' } });
    const res = await client.post('/api/webhooks/payments', body, {
      raw: true,
      headers: {
        'Content-Type': 'application/json',
        'x-uj-signature': `t=${Math.floor(Date.now() / 1000)},v1=${'0'.repeat(64)}`,
      },
    });
    assert.equal(res.status, 400);
  });

  it('rejects a correctly-signed but stale webhook', async () => {
    const { signWebhook } = await import('../src/services/payments.js');
    const client = createClient(origin);
    const body = JSON.stringify({ id: 'evt_stale', type: 'payment.succeeded', data: { reference: 'pi_x' } });
    const staleTs = Math.floor(Date.now() / 1000) - 3600;

    const res = await client.post('/api/webhooks/payments', body, {
      raw: true,
      headers: {
        'Content-Type': 'application/json',
        'x-uj-signature': signWebhook(body, staleTs),
      },
    });
    assert.equal(res.status, 400, 'a replayed old delivery must be refused');
  });

  it('will not mark an order paid for the wrong amount', async () => {
    const { signWebhook } = await import('../src/services/payments.js');
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);
    await client.post('/api/cart/items', { variantId, qty: 1 });

    const placed = await client.post('/api/checkout', {
      email: 'card@example.com',
      phone: '0791234567',
      paymentMethod: 'card',
      shipping: {
        fullName: 'Card Buyer', phone: '0791234567',
        governorate: 'amman', city: 'Abdoun', street: 'Zahran 1',
      },
    });
    assert.equal(placed.status, 200);
    const reference = placed.body.payment.reference;

    // Properly signed, but claims a payment of 1 fils.
    const body = JSON.stringify({
      id: 'evt_underpay',
      type: 'payment.succeeded',
      data: { reference, amountFils: 1, currency: 'JOD' },
    });
    const res = await client.post('/api/webhooks/payments', body, {
      raw: true,
      headers: { 'Content-Type': 'application/json', 'x-uj-signature': signWebhook(body) },
    });
    assert.equal(res.status, 200, 'the webhook is accepted...');

    const order = await client.post('/api/orders/lookup', {
      number: placed.body.order.number,
      token: placed.body.lookupToken,
    });
    assert.notEqual(order.body.order.paymentStatus, 'paid', '...but the order must NOT be paid');
  });

  it('ignores a replayed event id', async () => {
    const { signWebhook } = await import('../src/services/payments.js');
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);
    await client.post('/api/cart/items', { variantId, qty: 1 });

    const placed = await client.post('/api/checkout', {
      email: 'replay@example.com',
      phone: '0791234567',
      paymentMethod: 'card',
      shipping: {
        fullName: 'Replay Buyer', phone: '0791234567',
        governorate: 'amman', city: 'Abdoun', street: 'Zahran 1',
      },
    });

    const body = JSON.stringify({
      id: 'evt_once_only',
      type: 'payment.succeeded',
      data: {
        reference: placed.body.payment.reference,
        amountFils: placed.body.order.totalFils,
        currency: 'JOD',
      },
    });
    const headers = { 'Content-Type': 'application/json', 'x-uj-signature': signWebhook(body) };

    const first = await client.post('/api/webhooks/payments', body, { raw: true, headers });
    const second = await client.post('/api/webhooks/payments', body, { raw: true, headers });

    assert.equal(first.status, 200);
    assert.equal(second.status, 200, 'a replay is acknowledged, not errored');

    const { getDb } = await import('../src/db/index.js');
    const db = await getDb();
    const count = db.get(
      'SELECT COUNT(*) AS n FROM webhook_events WHERE event_id = ?', 'evt_once_only'
    ).n;
    assert.equal(count, 1, 'the event must be recorded exactly once');
  });
});

describe('response headers', () => {
  it('sets a strict CSP with a per-request nonce and no unsafe-inline scripts', async () => {
    const client = createClient(origin);
    const res = await client.get('/', { headers: { Accept: 'text/html' } });
    const csp = res.headers.get('content-security-policy');

    assert.ok(csp, 'a CSP must be present');
    assert.match(csp, /script-src [^;]*'nonce-/, 'script-src must be nonce-based');
    assert.match(csp, /frame-ancestors 'none'/);
    assert.match(csp, /object-src 'none'/);
    assert.match(csp, /base-uri 'none'/);
    assert.doesNotMatch(csp, /script-src[^;]*'unsafe-eval'/);

    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(res.headers.get('x-frame-options'), 'DENY');
    assert.ok(res.headers.get('referrer-policy'));
    assert.equal(res.headers.get('x-powered-by'), null);
  });

  it('issues a different nonce on every request', async () => {
    const client = createClient(origin);
    const a = await client.get('/', { headers: { Accept: 'text/html' } });
    const b = await client.get('/', { headers: { Accept: 'text/html' } });
    assert.notEqual(
      a.headers.get('content-security-policy'),
      b.headers.get('content-security-policy')
    );
  });

  it('never caches an API response in a shared cache', async () => {
    const client = createClient(origin);
    const res = await client.get('/api/cart');
    assert.match(res.headers.get('cache-control'), /no-store/);
  });

  it('marks session and cart cookies HttpOnly and SameSite', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);
    const res = await client.post('/api/cart/items', { variantId, qty: 1 });

    const cookies = res.headers.getSetCookie();
    const cart = cookies.find((c) => c.startsWith('uj_cart='));
    assert.ok(cart, 'a cart cookie must be issued');
    assert.match(cart, /HttpOnly/);
    assert.match(cart, /SameSite=Lax/);
  });
});

describe('input limits', () => {
  it('refuses an oversized request body', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const huge = JSON.stringify({ email: 'x'.repeat(200_000) });
    const res = await client.post('/api/password/forgot', huge, {
      raw: true,
      headers: { 'Content-Type': 'application/json' },
    });
    assert.equal(res.status, 413);
  });

  it('refuses a malformed JSON body', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const res = await client.post('/api/password/forgot', '{not json', {
      raw: true,
      headers: { 'Content-Type': 'application/json' },
    });
    assert.equal(res.status, 400);
  });

  it('refuses a quantity above the per-line maximum', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const variantId = await anyVariantId(client);
    const res = await client.post('/api/cart/items', { variantId, qty: 9999 });
    assert.equal(res.status, 422);
  });

  it('clamps quantity to what is actually in stock', async () => {
    const client = createClient(origin);
    await client.bootstrap();
    const { body } = await client.get('/api/products/uptown-club-set');
    // XS was seeded with 2 units.
    const scarce = body.product.variants.find((v) => v.size === 'XS');

    // 10 is the per-line schema maximum; stock is the tighter constraint.
    const res = await client.post('/api/cart/items', { variantId: scarce.id, qty: 10 });
    assert.equal(res.status, 200);
    const line = res.body.cart.lines.find((l) => l.variantId === scarce.id);
    assert.ok(line.qty <= 2, `expected at most 2, got ${line.qty}`);
  });
});
