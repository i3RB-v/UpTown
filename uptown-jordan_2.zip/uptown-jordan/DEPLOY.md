# Deployment

Target: one Linux VPS, Docker Compose, nginx terminating TLS, Let's Encrypt,
nightly backups. A 1 GB / 1 vCPU box handles this comfortably — SQLite means
there is no separate database server to run or pay for.

---

## Before you start

You need:

- a server with Docker and the Compose plugin
- a domain with an **A record already pointing at the server** (certificate
  issuance will fail otherwise)
- ports 80 and 443 open

---

## 1. Get the code onto the server

```bash
git clone <your-repo> /srv/uptown-jordan
cd /srv/uptown-jordan
```

## 2. Configure

```bash
cp .env.example .env
```

Generate each secret **separately** — do not reuse one value across four
variables:

```bash
for k in SESSION_SECRET CSRF_SECRET PASSWORD_PEPPER PAYMENT_WEBHOOK_SECRET; do
  echo "$k=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")"
done
```

Paste those in, then set:

```ini
NODE_ENV=production
PUBLIC_ORIGIN=https://uptownjordan.com     # must be https
TRUST_PROXY=1
SUPPORT_WHATSAPP=9627XXXXXXXX
```

```bash
chmod 600 .env
```

The app refuses to boot in production if a secret is missing, shorter than 32
characters, or if `PUBLIC_ORIGIN` is not HTTPS. That is intentional.

## 3. Point nginx at your domain

`nginx/conf.d/uptownjordan.conf` has `uptownjordan.com` in five places:

```bash
sed -i 's/uptownjordan\.com/yourdomain.com/g' nginx/conf.d/uptownjordan.conf
```

## 4. Issue the certificate

```bash
DOMAIN=yourdomain.com EMAIL=you@yourdomain.com ./scripts/init-letsencrypt.sh
```

The script drops a temporary self-signed pair so nginx can start, requests the
real certificate over the ACME HTTP-01 challenge, then brings the stack up.
Test against the staging CA first if you are unsure — `STAGING=1` — because
the production rate limit is 5 failures per hostname per hour.

## 5. Start, migrate, seed

```bash
docker compose up -d --build
docker compose exec app node src/db/migrate.js
docker compose exec app node src/db/seed.js          # optional demo catalogue
docker compose exec -it app node scripts/create-admin.js --email you@yourdomain.com --name "Your Name"
```

`create-admin` reads the password with echo off, so it never lands in shell
history or `ps`.

## 6. Verify

```bash
curl -s https://yourdomain.com/api/healthz | jq
curl -sI https://yourdomain.com | grep -Ei 'strict-transport|content-security|x-frame'
docker compose ps        # every service healthy
```

Then sign in at `/login`, open `/admin`, and **turn on two-factor from
`/account` immediately**.

---

## Go-live checklist

- [ ] Four distinct secrets, 32+ chars, `.env` is `chmod 600` and not in git
- [ ] `PUBLIC_ORIGIN` matches the real domain, over HTTPS
- [ ] Domain replaced throughout `nginx/conf.d/uptownjordan.conf`
- [ ] Certificate issued; `https://` loads without a warning
- [ ] `PAYMENT_PROVIDER` switched off `mock`, webhook secret is the provider's
- [ ] Provider webhook pointed at `https://yourdomain.com/api/webhooks/payments`
- [ ] Email transport wired for resets and order confirmations
- [ ] Admin account created, **2FA enabled**
- [ ] Real catalogue loaded; demo products removed or archived
- [ ] `SUPPORT_WHATSAPP` set to the real number
- [ ] A backup taken **and a restore rehearsed** (see below)
- [ ] Backups copied off this machine
- [ ] Full-disk encryption on the host
- [ ] Uptime monitoring on `/api/healthz`
- [ ] SSH: key-only, no root login, firewall allowing only 22/80/443
- [ ] Unattended security upgrades enabled

---

## Backups

The `backup` service runs nightly: `VACUUM INTO` a consistent archive in
`./backups`, 30-day retention, and it **refuses to run if the integrity check
fails**.

Manual:

```bash
docker compose exec app node scripts/backup.js --dir /backups --keep 30
```

**Copy them off the machine.** A backup on the same disk as the database is
not a backup:

```bash
# in root's crontab
17 4 * * * rsync -az --delete /srv/uptown-jordan/backups/ backup@elsewhere:/srv/uj/
```

### Restoring

```bash
./scripts/restore.sh backups/uptown-2026-09-17T02-00-00-000Z.db
```

It verifies the archive first, stops the app, keeps a copy of the current
database, removes the stale `-wal` / `-shm` files (skipping that step is the
classic way to corrupt a restore), installs the archive, and restarts.

**Rehearse this before you need it.** Restore into a staging copy and confirm
`/api/healthz` reports `ok` and recent orders are present.

---

## Operations

```bash
docker compose logs -f app                  # structured JSON, secrets redacted
docker compose logs -f app | jq 'select(.level=="error")'
docker compose exec app node -e "import('./src/db/index.js').then(m=>m.integrityCheck()).then(console.log)"
```

Deploying a change:

```bash
git pull
docker compose up -d --build app
docker compose exec app node src/db/migrate.js   # idempotent
```

The app handles `SIGTERM` gracefully: stops accepting, finishes in-flight
requests, checkpoints the WAL so the file on disk is self-contained, then
exits. Compose sends `SIGTERM` on `up -d --build`, so rolling a new image does
not drop orders mid-flight.

Rotating a secret:

- `SESSION_SECRET` — signs everyone out. Safe, occasionally useful.
- `CSRF_SECRET` — invalidates in-flight tokens; the front-end refetches
  automatically on the first 403.
- `PASSWORD_PEPPER` — **invalidates every password.** Only with a planned
  forced reset for all users.
- `PAYMENT_WEBHOOK_SECRET` — must be changed at the provider at the same
  moment, or webhooks start failing verification.

---

## Scaling, when it matters

SQLite comfortably serves a store of this size — reads are in-process and WAL
lets readers run while a write is in flight. Order writes are short
transactions.

If you outgrow one box:

1. **Vertical first.** More RAM and a faster disk goes a long way; this
   workload is overwhelmingly reads.
2. **`npm install better-sqlite3`.** The adapter picks it up automatically and
   it is measurably faster under concurrency.
3. **Add a CDN** in front for `/assets/*` and product images.
4. **Only then consider Postgres.** All SQL lives in `src/services/*` and
   `src/db/schema.sql`. Ports to watch: `INTEGER` epoch-ms columns, `VACUUM
   INTO` in the backup script, and the `ON CONFLICT` upserts.

Note that SQLite ties you to one machine's filesystem, so horizontal scaling
means moving the database first.

---

## Troubleshooting

**"FATAL: refusing to start in production with unsafe secrets"** — exactly what
it says. Check `.env` is present, readable by the container, and that each
secret is 32+ characters.

**Certificate issuance fails** — DNS is not pointing here yet, or port 80 is
blocked. Confirm with `curl -I http://yourdomain.com/.well-known/acme-challenge/test`.

**"database is locked"** — a long-running write is holding the lock.
`busy_timeout` is 5s. Check for a stuck backup or a manual `sqlite3` session.

**Rate limits firing for everyone** — `TRUST_PROXY` is off behind nginx, so
every request looks like it comes from the proxy's IP. Set `TRUST_PROXY=1`.

**Webhooks rejected** — the signing secret differs from the provider's, or the
server clock has drifted more than 5 minutes. Check `timedatectl`.

**Styles or scripts missing, CSP errors in the console** — something was added
to a page that the policy does not allow. Read the violation in the browser
console and add the source to `src/middleware/security.js` deliberately rather
than loosening `script-src`.
