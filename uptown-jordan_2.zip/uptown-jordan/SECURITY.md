# Security

What this application defends against, how, and — just as importantly — what
it does not.

Every claim below has a test in `test/security.test.js`. Run `npm test` and
they should all be green; if one goes red, a defence has been removed.

---

## Threat model

This is a small retail storefront handling names, addresses, phone numbers,
order history and passwords. It does **not** handle card data (see *Payments*).
The realistic adversaries are:

- an opportunistic attacker with a scanner, looking for injection, traversal,
  exposed admin routes, or default credentials
- a customer tampering with their own requests to pay less or see someone
  else's order
- credential stuffing against customer accounts using leaked password lists
- someone who obtains a copy of the database file

The design takes all four seriously.

---

## Passwords

Hashed with **scrypt** (memory-hard), `N=32768, r=8, p=1`, 16-byte random salt
per password, 32-byte output. Stored as `scrypt$N$r$p$salt$hash`, so the
parameters travel with the hash and can be raised later — `needsRehash()`
upgrades a password silently on the owner's next successful sign-in.

Before hashing, the password is HMAC'd with a server-side **pepper**
(`PASSWORD_PEPPER`) that lives in the environment, never in the database. A
dump of the `users` table alone cannot be attacked offline.

Comparison is constant-time (`timingSafeEqual` over fixed-width digests, so
even the length does not leak).

**Why not argon2id?** It is the better primitive, and it needs a native module.
Keeping the dependency count at zero was judged the larger win here; scrypt is
memory-hard and remains an OWASP-acceptable choice. If you want argon2id,
`@node-rs/argon2` ships prebuilt binaries and only `hashPassword` /
`verifyPassword` in `src/core/crypto.js` need to change — the stored format is
already versioned for exactly this.

**Policy:** minimum 10 characters, a small block-list of the obvious, and a
refusal to let the password contain the email's local part. No character-class
theatre — length is what actually matters.

**Lockout:** 8 consecutive failures locks an account for 15 minutes. Combined
with the rate limits below, this makes credential stuffing impractical.

---

## Sessions

The cookie holds a **256-bit opaque token and nothing else** — no user id, no
role, no signed claims. All state lives in the `sessions` table, and only the
**SHA-256 of the token** is stored.

Two consequences, both deliberate:

- A session can be revoked *instantly* — logout everywhere, a role change, an
  account lock. A JWT would stay valid until it expired.
- Someone who reads the database still cannot mint a cookie that
  authenticates as anyone.

The session id is **rotated on every sign-in**, which is what defeats session
fixation. A password change drops every *other* session and keeps the current
device. A password reset drops *all* of them.

Cookies are `HttpOnly`, `Secure` (production), `SameSite=Lax`, `Path=/`, with
no `Domain` attribute, and carry the `__Host-` prefix in production — so a
compromised sibling subdomain cannot write a session cookie for this one.

Lifetimes: 14 days absolute, 3 days idle. The bound user-agent changing
mid-session revokes it (a strong stolen-cookie signal). IP is deliberately
*not* treated that way — mobile networks rotate addresses constantly and it
would sign people out all day for nothing.

---

## CSRF

Two independent barriers, both of which must fall:

1. **Origin checking.** `Sec-Fetch-Site` / `Origin` are set by the browser and
   cannot be forged by script. A POST from `evil.example` is rejected before
   the body is even parsed.
2. **A signed double-submit token.** The token is HMAC'd by the server (so it
   cannot be invented) and must be echoed from a cookie into the
   `x-csrf-token` header (so it cannot be read cross-origin). The signature is
   **bound to the current session id**, so a token minted before sign-in stops
   working after it.

`SameSite=Lax` is a third layer but is not relied on — not every client
enforces it, and it does not cover same-site subdomain takeover.

The payment webhook is exempt, because it authenticates by HMAC signature and
a payment provider has no cookie jar.

---

## Injection

**SQL:** every query in the codebase is a prepared statement with bound
parameters. There is no string interpolation of user input into SQL anywhere.
The two places that trip people up are handled explicitly:

- `ORDER BY` cannot be parameterised, so `sort` is validated against a fixed
  allow-list before it is used.
- `LIKE` wildcards are added to the *value*, and `%` / `_` inside the user's
  text are escaped, so searching for "50%" cannot become a full-table wildcard
  scan.

**XSS:** the front-end **never assigns server data to `innerHTML`**. Every
dynamic value goes through `textContent` or an attribute, via the `el()`
helper in `public/assets/app.js`. Merchant-authored copy is stored and rendered
as plain text — no HTML is accepted anywhere, so there is no sanitiser to get
wrong.

On top of that sits a **nonce-based CSP** with no `'unsafe-inline'` and no
`'unsafe-eval'` in `script-src`, plus `object-src 'none'`, `base-uri 'none'`,
`frame-ancestors 'none'`, `form-action 'self'`. Even if attacker text reached
the DOM, the browser would not run it.

> **The one CSP compromise.** `style-src` keeps `'unsafe-inline'`. The hero
> composition positions dozens of elements with inline `style` attributes, and
> a nonce in `style-src` makes the browser ignore `'unsafe-inline'` and blank
> the page. Inline *styles* are a far smaller hazard than inline *scripts*:
> this application never renders supplied HTML, so there is no path by which
> attacker-controlled CSS reaches a page. The strict `script-src` — where XSS
> actually lives — is intact.

**Prototype pollution:** `__proto__`, `constructor` and `prototype` keys are
rejected by the validator, and object schemas are strict allow-lists — unknown
keys are dropped, never forwarded. A body cannot smuggle `role: "admin"` into
something that later gets spread into a query.

**Path traversal:** the router rejects any `..` segment outright rather than
normalising it away, and the static handler re-checks containment on the
*resolved* path, which also defeats symlinks.

---

## Commerce integrity

- **The client never supplies money.** Prices, delivery and totals are derived
  server-side from the catalogue and the shipping table on every request. The
  `expectedTotalFils` field a checkout may send is used *only* to detect that
  the bag changed and show a message — it can never lower a charge.
- **Stock cannot be oversold.** Reservation is a conditional UPDATE inside a
  transaction; concurrent buyers serialise and the loser gets a 409.
- **Checkout is idempotent.** An `Idempotency-Key` header makes a retry return
  the same order instead of placing a second one. A repeated key with a
  *different* body is refused rather than silently replayed.
- **Order history is immutable in the ways that matter.** Line items carry
  their own copy of title, SKU and unit price; a `CHECK` constraint enforces
  `total = subtotal - discount + shipping + tax` at the database level.
- **Guest order lookup needs two secrets.** The order number (which appears on
  receipts) is not enough; a 24-byte token, stored only as a digest, is also
  required, and lookups are rate limited.

---

## Payments

**No card data enters this system.** There is no field for a PAN, no code path
that accepts one, and nothing to log or store. The flow is hosted-redirect:

```
order created → intent created with the provider
             → customer redirected to the provider's page
             → provider POSTs a signed webhook back
             → the order is marked paid from the webhook
```

The browser's return URL is treated as a hint, never as proof — anyone can
visit a success URL. Only a webhook that passes **all** of these moves an
order to paid:

1. HMAC-SHA256 signature over the raw bytes, compared in constant time
2. A signed timestamp within a 5-minute window (defeats capture-and-replay)
3. A previously-unseen event id (enforced by a UNIQUE index, so simultaneous
   deliveries cannot both proceed)
4. **An amount and currency matching the order.** A correctly signed webhook
   claiming a payment of 1 fils marks the payment *failed*, not paid.

Keeping card handling out of scope this way keeps the deployment clear of the
most demanding parts of PCI-DSS. Confirm your obligations with your acquirer;
"we use a hosted page" usually means SAQ A, but that is their call, not mine.

---

## Reviews and user-submitted content

Reviews are the one place customers write text that other customers read, so
they get three independent controls:

1. **Eligibility is a database join, not a checkbox.** Only a signed-in
   customer with a *delivered* order containing that product can submit one.
   The order id is stored on the review, so the "verified purchase" claim
   stays auditable after the fact.
2. **Nothing self-publishes.** Every review lands `pending`; the storefront
   reads only `published`. Moderation exists to catch spam, abuse and text
   that names a private individual — not to filter criticism.
3. **Text is text.** Review bodies are stored and rendered as plain strings
   via `textContent`. No HTML is accepted, so there is no sanitiser to get
   wrong, and the strict `script-src` catches anything that slipped through.

One review per customer per product, enforced by a UNIQUE constraint rather
than an application check.

The rate limit on submission is keyed on the **account**, not the IP. Keying
it on IP would let customers behind one mobile-network NAT — normal in Jordan
— silently block each other. Abuse is bounded instead by the per-IP limit on
account creation, plus moderation.

The store ships with **zero reviews**, and `aggregateRating` structured data
is emitted only when real ones exist. Seeding invented reviews would be
fabricated social proof: dishonest to customers, and a search-engine policy
violation that also endangers a merchant account.

The same reasoning covers the other public write endpoints — newsletter
signup, restock alerts and the contact form. All three are unauthenticated, so
all three are rate limited, validated against strict schemas, and written to
respond identically whether or not an address is already on file.

## Rate limiting

Budgets live in SQLite, not process memory, so they survive a restart and hold
across workers. Bucket keys are HMAC'd, so the table never contains a
plaintext list of visitor IPs or attempted email addresses.

| Bucket | Budget | Keyed on |
|---|---|---|
| API (all `/api/*`) | 300 / min | IP |
| Sign-in | 8 / 15 min | IP **and**, separately, the account |
| Registration | 5 / hour | IP |
| Checkout | 15 / hour | IP |
| Order lookup | 30 / 15 min | IP |
| Password reset request | 5 / hour | IP |
| TOTP verification | 10 / 10 min | account |
| Review submission | 3 / day | **account** |
| Restock alert | 20 / hour, 10 / hour | IP, and separately the email address |
| Newsletter signup | 5 / hour | IP |
| Contact form | 5 / hour | IP |

Sign-in uses two budgets on purpose: per-IP stops one host spraying many
accounts, per-account stops a botnet grinding one account from many hosts. A
*successful* sign-in refunds its consumption, so honest users are not punished
for a typo.

nginx applies a coarser outer layer before requests reach Node at all.

---

## Account enumeration

Registration, sign-in and password reset are all designed to reveal nothing:

- Registering an address that already exists returns the **same status, shape
  and message** as a successful registration — no session is granted, and the
  real owner is told by email. Both paths spend the same KDF time.
- Sign-in returns one message for unknown address, wrong password and locked
  account, and `fakeVerify()` burns equivalent CPU on the unknown-address path
  so the timing matches.
- Password reset always answers "if that address has an account, a link is on
  its way".

---

## The database

- `PRAGMA foreign_keys = ON` on every connection, with every relationship
  declared — the database refuses to hold an order line pointing at a deleted
  variant.
- `CHECK` constraints encode the invariants (no negative stock, no qty 0, no
  unknown status, `reserved <= stock`, totals that add up), so an application
  bug cannot persist nonsense.
- WAL journalling with `synchronous = NORMAL` — durable across process
  crashes, and a crash cannot tear a commit.
- `trusted_schema = OFF` blocks the class of attack where a tampered database
  file executes code on open. `cell_size_check = ON` catches corrupt pages on
  read.
- The file is `chmod 600` and lives on a Docker volume **outside** the
  application directory, so it is not in any path that could be served.
- Session ids, cart tokens, reset tokens and order lookup tokens are stored as
  SHA-256 digests. A database leak does not hand over live credentials.
- Backups use `VACUUM INTO` (consistent while serving) and **refuse to run if
  the integrity check fails** — a corrupt backup quietly rotating out the good
  ones is worse than no backup.

**Encryption at rest is not included.** For a storefront holding addresses and
phone numbers, use full-disk encryption on the host (LUKS, or your cloud
provider's encrypted volumes). If you need database-level encryption, SQLCipher
is a drop-in for the `better-sqlite3` path.

---

## Operational hardening

- The container runs as **non-root**, with a read-only root filesystem, all
  capabilities dropped, and `no-new-privileges`.
- The app is **never published to the host** — only nginx is. It listens on an
  internal Docker network.
- The process **refuses to start in production** if any secret is missing or
  under 32 characters, or if `PUBLIC_ORIGIN` is not `https://`. A store that
  boots on a default key is worse than a store that does not boot.
- Error responses are curated. A 500 never contains the exception text, so
  stack traces, file paths and SQL fragments cannot leak.
- Logs are structured JSON with a redaction list covering passwords, tokens,
  cookies, signatures, emails, phones and addresses.
- `TRUST_PROXY` reads the **last** `X-Forwarded-For` hop — the one nginx
  appends — so a client cannot pre-populate the header to evade rate limiting.
- Slowloris defences at both layers: header/request timeouts in Node, plus
  nginx body and header timeouts.
- Every privileged action writes an append-only `audit_log` row. Nothing in
  the codebase updates or deletes from that table.

---

## Two-factor authentication

TOTP (RFC 6238, SHA-1, 6 digits, 30s, ±1 step drift) is available to every
account and **enforced for staff**: `requireRole` checks that a staff account
with TOTP enrolled has satisfied it *for the current session*, not merely at
some point in the past. Enrolment only activates once a valid code proves the
authenticator actually holds the secret. Turning it off requires the password.

---

## What is still your responsibility

1. **Set the secrets.** Four of them, all different, all 32+ characters. The
   app will not start in production without them, but it cannot check that you
   generated them properly.
2. **Swap the mock payment provider** before taking real money.
   `PAYMENT_PROVIDER=mock` ships a working simulator so the full signed-webhook
   path is testable; it is not a payment processor.
3. **Wire email.** Password resets and order confirmations currently have no
   transport.
4. **Keep Node patched.** Zero dependencies means the runtime is the entire
   supply chain — which is the point, but it does mean rebuilding the image
   when Node ships a security release.
5. **Encrypt the disk** and store backups somewhere that is not the same
   machine.
6. **Review the privacy side.** Jordan's Personal Data Protection Law applies
   to the addresses and phone numbers in this database. Retention, deletion
   requests and a privacy notice are policy decisions, not code.
7. **Watch the audit log.** It records everything staff do; nothing alerts on
   it.

---

## Reporting a problem

Send details to the address in your deployment's contact page. Please include
the request that reproduces it. If it is a live exploitation, rotate
`SESSION_SECRET` (signs everyone out), take a backup, and check `audit_log` and
`orders` for anything unexpected before anything else.
