# Uptown Jordan

A production-ready storefront for a contemporary streetwear label in Amman:
catalogue, server-authoritative cart, cash-on-delivery and card checkout,
customer accounts, verified-purchase reviews, restock alerts, a staff
dashboard and the brand and policy pages a real shop needs — built around
the existing full-viewport hero.

**Zero runtime dependencies.** The whole server is Node's standard library:
`node:sqlite`, `node:http`, `node:crypto`, `node:zlib`. There is no framework,
no ORM, no lockfile to audit, and no transitive CVE surface. That is a
deliberate security decision, not minimalism for its own sake.

---

## Quick start

Works the same in PowerShell, cmd, bash and zsh. You need **Node 22.5 or
newer** — check with `node --version`, and install the current LTS from
[nodejs.org](https://nodejs.org) if you are below that.

```bash
npm run setup             # .env + secrets + database + demo catalogue
npm run admin:create      # your admin login (password entry is hidden)
npm run dev               # http://localhost:3000
```

There is no `npm install` step. The project has no runtime dependencies, so
there is nothing to download.

<details>
<summary>What <code>npm run setup</code> does, if you would rather do it by hand</summary>

```bash
cp .env.example .env
# generate four DIFFERENT secrets and paste them in:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
npm run migrate           # create the schema
npm run seed              # 12 products, 66 variants, 5 collections
```

</details>

Then:

- `/` — the hero landing page (unchanged; its nav and CTAs now go somewhere)
- `/shop` — the collection, filterable and searchable
- `/cart` → `/checkout` → `/order` — the buying path
- `/login`, `/account` — customer accounts, addresses, order history, 2FA
- `/admin` — orders, inventory, review moderation, messages, audit trail
- `/about`, `/size-guide`, `/shipping-returns`, `/faq`, `/contact` — the brand
  and help pages
- `/privacy`, `/terms` — policy pages, accurate to what the code does

Run the tests:

```bash
npm test                  # 89 tests: 33 security, 31 functional, 25 content
```

---

## How it is put together

```
src/
  server.js            HTTP entry, graceful shutdown, expiry sweeper
  app.js               middleware pipeline, route mounting, page routes
  config.js            env loading; refuses to boot on unsafe production config
  core/
    router.js          method + path routing, onion middleware, error shaping
    http.js            cookies, body limits, client IP, responses
    crypto.js          scrypt passwords, tokens, HMAC, TOTP, order numbers
    validate.js        allow-list schema validation
    money.js           integer fils arithmetic — no floats touch money
    errors.js          typed errors with safe, user-facing messages
    logger.js          structured JSON logs with key redaction
  db/
    schema.sql         the data model, with the reasoning in comments
    driver.js          node:sqlite / better-sqlite3 adapter
    index.js           connection pragmas, migrations, integrity, sweeping
    seed.js            idempotent catalogue seed
  middleware/
    security.js        CSP with a per-request nonce, and the rest of the headers
    session.js         server-side sessions, role and MFA guards
    csrf.js            signed double-submit token + origin checking
    ratelimit.js       DB-backed fixed-window budgets
    static.js          asset serving, HTML partials, nonce stamping
  services/            catalog, cart, orders, payments, users, shipping,
                       reviews, notify (newsletter/alerts/enquiries), audit
  routes/              store, auth, admin, payments, pages (server-rendered
                       titles, Open Graph and JSON-LD)
  public/              pages, shared partials, CSS, page scripts
```

### The decisions worth knowing

**The cart lives on the server.** A client can only ever say *variant X,
quantity N*. Prices, delivery and totals are recomputed from the catalogue on
every read and again at checkout. There is no request shape that results in
being charged an amount the client chose.

**Money is integer fils.** 1 JOD = 1000 fils. No floating point anywhere near
a price, a total or an invoice.

**Stock moves under a conditional UPDATE.** `UPDATE variants SET reserved =
reserved + ? WHERE id = ? AND (stock - reserved) >= ?` inside a transaction.
Two customers racing for the last hoodie cannot both win; the loser gets a
clean "just sold out". There is a test for exactly this.

**Order lines are denormalised on purpose.** Title, SKU, and unit price are
copied onto the order at capture time, so renaming or repricing a product
never rewrites the history of what somebody was charged.

**Payments never touch card data.** The flow is hosted-redirect: create an
intent, send the customer to the provider, and mark the order paid only when a
*signed webhook* arrives for the *expected amount*. The browser's return URL
is a hint, not proof.

**Reviews cannot be faked.** Only a customer with a *delivered* order
containing the product can write one, and nothing publishes until a human
releases it. The store ships with zero reviews, and `aggregateRating`
structured data is emitted only once real ones exist — inventing social proof
is both dishonest and a fast way to lose a merchant account.

**Share metadata is server-rendered.** Titles, Open Graph tags and JSON-LD are
built before the HTML leaves the server, because WhatsApp's link-preview
crawler — which is how most of this shop's links will travel — does not run
JavaScript.

---

## Working on it

| Command | What it does |
|---|---|
| `npm run dev` | Watch mode on port 3000 |
| `npm run migrate` | Apply `schema.sql`, report engine + integrity |
| `npm run seed` | Upsert the catalogue (never overwrites real stock) |
| `npm run admin:create` | Create or promote an admin; password read hidden |
| `npm run backup` | `VACUUM INTO` a consistent archive, prune old ones |
| `npm test` | The full suite |

### Adding a product

Through `/admin` as an admin, or directly:

```bash
curl -X POST http://localhost:3000/api/admin/products \
  -H 'content-type: application/json' -H "x-csrf-token: $TOKEN" \
  -b cookies.txt \
  -d '{"slug":"new-piece","title":"New Piece","price":"45.000","status":"active"}'
```

Prices are sent as human strings (`"45.000"`) and parsed into integer fils.
A malformed amount is rejected, never rounded.

### Swapping in a real payment provider

One function, `createIntent` in `src/services/payments.js`, needs to call your
provider and return their hosted-checkout URL. Then:

1. Set `PAYMENT_PROVIDER` to the provider's name.
2. Set `PAYMENT_WEBHOOK_SECRET` to their signing secret.
3. Point their webhook at `https://yourdomain/api/webhooks/payments`.
4. Adjust `verifyWebhookSignature` to their header format if it differs from
   the Stripe-style `t=<unix>,v1=<hex>` this ships with.

Everything else — replay protection, amount verification, order transitions —
already works and is covered by tests.

### Wiring email

No mail provider is bundled. Two places want one:

- `src/routes/auth.routes.js` → `/password/forgot` currently logs the reset
  link (and returns it in development only). Send it instead.
- `src/services/orders.js` → after `createFromCart`, send the confirmation
  with the order number and lookup token.
- `src/services/notify.js` → newsletter confirmation links, and the
  back-in-stock queue. `pendingStockAlerts()` returns everyone waiting on a
  size that is now available; send to them, then call `markAlertsSent()`.

Both are marked with comments. Keep the "we always respond the same way"
behaviour on the forgot-password route — it is what stops the endpoint being
used to enumerate which addresses have accounts.

---

## API surface

Public:

```
GET    /api/config                    store rules, governorates, payment methods
GET    /api/csrf                      issue/refresh the CSRF cookie
GET    /api/collections
GET    /api/products                  ?collection= &search= &sort= &limit= &offset=
GET    /api/products/:slug
GET    /api/cart                      ?governorate= &paymentMethod=
POST   /api/cart/items                { variantId, qty }
PATCH  /api/cart/items/:variantId     { qty }   (0 removes)
DELETE /api/cart/items/:variantId
POST   /api/shipping/quote            { governorate, paymentMethod }
POST   /api/checkout                  Idempotency-Key header supported
POST   /api/orders/lookup             { number, token }
GET    /api/products/:slug/reviews
POST   /api/products/:slug/reviews    signed in + delivered order required
POST   /api/variants/:id/notify-me    { email }  restock alert
POST   /api/newsletter                { email }  double opt-in
POST   /api/newsletter/confirm        { token }
POST   /api/newsletter/unsubscribe    { email }
POST   /api/contact                   { name, email, topic, message }
```

Accounts:

```
POST   /api/register  /api/login  /api/login/totp  /api/logout
GET    /api/me  /api/account  /api/account/orders  /api/account/orders/:id
PATCH  /api/account
POST   /api/account/password
GET|POST|PATCH|DELETE /api/account/addresses[/:id]
POST   /api/account/totp/start  /enable  /disable
POST   /api/password/forgot  /api/password/reset
```

Staff (`admin` or `staff` role):

```
GET    /api/admin/stats  /orders  /orders/:id  /products
POST   /api/admin/orders/:id/transition   { action: mark_paid|mark_shipped|mark_delivered|cancel }
POST   /api/admin/products                (admin only)
PATCH  /api/admin/products/:id            (admin only)
POST   /api/admin/products/:id/variants   (admin only)
PATCH  /api/admin/variants/:id            stock + active
GET    /api/admin/audit                   (admin only)
GET    /api/admin/reviews                 ?status=pending|published|rejected
POST   /api/admin/reviews/:id/moderate    { action: publish|reject }
GET    /api/admin/enquiries               contact-form messages
POST   /api/admin/enquiries/:id/status    { status }
GET    /api/admin/stock-alerts            who is waiting on a restock
GET    /api/account/reviewable            pieces this customer may review
```

Every state-changing request needs the `x-csrf-token` header echoing the
`uj_csrf` cookie, and a same-origin `Origin`/`Sec-Fetch-Site`. The bundled
front-end does this for you.

---

## Deployment

See **[DEPLOY.md](DEPLOY.md)** — Docker Compose, nginx, Let's Encrypt,
backups, and the go-live checklist.

See **[SECURITY.md](SECURITY.md)** — what is defended, how, and what is
explicitly still your responsibility.

---

## A note on `node:sqlite`

Node marks this module experimental, which means its API may change across
major Node versions — not that it is unreliable; it is the same SQLite engine
everything else uses (3.51 here).

Two things make that safe in practice: the Docker image pins Node 22, and
every database call goes through `src/db/driver.js`. If you would rather run
the long-established native binding, `npm install better-sqlite3` and the
adapter picks it up automatically — no other code changes.
