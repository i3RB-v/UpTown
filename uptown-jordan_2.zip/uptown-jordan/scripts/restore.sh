#!/usr/bin/env bash
# Restore a backup over the live database.
#
#   ./scripts/restore.sh backups/uptown-2026-09-17T12-00-00-000Z.db
#
# Stops the app first, keeps a copy of the current database, verifies the
# archive before it replaces anything, and refuses to continue on any failure.
set -euo pipefail

ARCHIVE="${1:-}"
DB_FILE="${DATABASE_FILE:-./data/uptown.db}"

if [[ -z "$ARCHIVE" ]]; then
  echo "usage: $0 <backup.db>" >&2
  exit 1
fi
if [[ ! -f "$ARCHIVE" ]]; then
  echo "No such backup: $ARCHIVE" >&2
  exit 1
fi

echo "Verifying archive..."
if command -v sqlite3 >/dev/null 2>&1; then
  if ! sqlite3 "$ARCHIVE" 'PRAGMA integrity_check;' | grep -qx 'ok'; then
    echo "Archive failed its integrity check. Refusing to restore." >&2
    exit 2
  fi
else
  echo "sqlite3 not found; skipping the pre-flight integrity check." >&2
fi

if command -v docker >/dev/null 2>&1 && docker compose ps --quiet app >/dev/null 2>&1; then
  echo "Stopping the application..."
  docker compose stop app
fi

if [[ -f "$DB_FILE" ]]; then
  SAFETY="${DB_FILE}.replaced-$(date -u +%Y%m%dT%H%M%SZ)"
  echo "Keeping the current database at $SAFETY"
  cp "$DB_FILE" "$SAFETY"
fi

# The -wal and -shm files belong to the OLD database. Leaving them beside a
# restored file is the classic way to corrupt a restore.
rm -f "${DB_FILE}-wal" "${DB_FILE}-shm"

install -m 600 "$ARCHIVE" "$DB_FILE"
echo "Restored $ARCHIVE -> $DB_FILE"

if command -v docker >/dev/null 2>&1; then
  echo "Starting the application..."
  docker compose start app || true
fi

echo "Done. Check /api/healthz before announcing recovery."
