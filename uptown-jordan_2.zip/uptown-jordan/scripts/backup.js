#!/usr/bin/env node
/**
 * Online backup.
 *
 * Uses SQLite's `VACUUM INTO`, which writes a consistent, defragmented copy
 * while the application keeps serving traffic. Copying the .db file with
 * `cp` while WAL is active can capture a torn state; this cannot.
 *
 *   npm run backup
 *   node scripts/backup.js --dir /mnt/backups --keep 30
 */
import { chmodSync, existsSync, mkdirSync, readdirSync, statSync, unlinkSync } from 'node:fs';
import path from 'node:path';
import { ROOT } from '../src/config.js';
import { closeDb, getDb, integrityCheck } from '../src/db/index.js';

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  return i === -1 ? fallback : process.argv[i + 1] ?? fallback;
}

const dir = path.resolve(arg('dir', path.join(ROOT, 'backups')));
const keep = Math.max(1, Number(arg('keep', 14)));

if (!existsSync(dir)) mkdirSync(dir, { recursive: true, mode: 0o700 });

const db = await getDb();

// Refuse to archive a database that is already damaged. A corrupt backup
// quietly rotating out the good ones is worse than having no backup at all.
const health = await integrityCheck();
if (!health.ok) {
  console.error('Integrity check FAILED. Refusing to back up a damaged database.');
  console.error(JSON.stringify(health, null, 2));
  process.exit(2);
}

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const target = path.join(dir, `uptown-${stamp}.db`);

// VACUUM INTO does not accept a bound parameter, so the path is escaped as a
// SQL string literal. It comes from the operator's own command line, never
// from a request.
db.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
chmodSync(target, 0o600);

const size = statSync(target).size;
console.log(`Backup written: ${target} (${(size / 1024 / 1024).toFixed(2)} MB)`);

/* Retention: keep the newest N, delete the rest. */
const archives = readdirSync(dir)
  .filter((f) => f.startsWith('uptown-') && f.endsWith('.db'))
  .map((f) => ({ f, t: statSync(path.join(dir, f)).mtimeMs }))
  .sort((a, b) => b.t - a.t);

for (const stale of archives.slice(keep)) {
  unlinkSync(path.join(dir, stale.f));
  console.log(`Pruned old backup: ${stale.f}`);
}

console.log(`Retained ${Math.min(archives.length, keep)} backup(s) in ${dir}.`);
await closeDb();
