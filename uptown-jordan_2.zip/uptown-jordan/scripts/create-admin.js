#!/usr/bin/env node
/**
 * Create or promote an administrator.
 *
 *   npm run admin:create -- --email you@example.com --name "Your Name"
 *
 * The password is read from stdin with echo disabled, so it never lands in
 * shell history, `ps` output, or a container's process list. Passing it as a
 * command-line flag is deliberately not supported.
 */
import readline from 'node:readline';
import { hashPassword, uuid } from '../src/core/crypto.js';
import { assertPasswordAcceptable } from '../src/services/users.js';
import { closeDb, getDb, migrate } from '../src/db/index.js';

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i === -1 ? null : process.argv[i + 1] ?? null;
}

function ask(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

/**
 * Reads a line with the terminal's echo turned off.
 *
 * Some terminals (a few Windows shells, CI runners, piped input) do not
 * support raw mode. Rather than failing, fall back to a visible prompt and
 * say so, so the operator can decide whether anyone is looking over their
 * shoulder.
 */
function askSecret(question) {
  return new Promise((resolve, reject) => {
    if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
      console.log('  (this terminal cannot hide input — what you type will be visible)');
      ask(question).then(resolve, reject);
      return;
    }
    process.stdout.write(question);
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');

    let value = '';
    const onData = (chunk) => {
      for (const char of chunk) {
        const code = char.charCodeAt(0);
        if (code === 13 || code === 10) {
          process.stdin.setRawMode(false);
          process.stdin.pause();
          process.stdin.removeListener('data', onData);
          process.stdout.write('\n');
          resolve(value);
          return;
        }
        if (code === 3) {
          process.stdin.setRawMode(false);
          process.stdout.write('\n');
          process.exit(130);
        }
        if (code === 127 || code === 8) {
          value = value.slice(0, -1);
          continue;
        }
        if (code < 32) continue;
        value += char;
      }
    };
    process.stdin.on('data', onData);
  });
}

const email = (arg('email') || (await ask('Email: '))).toLowerCase();
if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
  console.error('That does not look like an email address.');
  process.exit(1);
}

const name = arg('name') || (await ask('Full name: '));

const password = await askSecret('Password (hidden): ');
const confirm = await askSecret('Confirm password: ');

if (password !== confirm) {
  console.error('Passwords do not match.');
  process.exit(1);
}

try {
  assertPasswordAcceptable(password, { email });
} catch (err) {
  console.error(err.message);
  process.exit(1);
}

await migrate();
const db = await getDb();
const now = Date.now();
const hash = await hashPassword(password);
const existing = db.get('SELECT id, role FROM users WHERE email_normalized = ?', email);

if (existing) {
  db.run(
    `UPDATE users SET password_hash = ?, role = 'admin', status = 'active',
                      full_name = COALESCE(NULLIF(?, ''), full_name),
                      failed_logins = 0, locked_until = NULL,
                      password_changed_at = ?, updated_at = ? WHERE id = ?`,
    hash, name, now, now, existing.id
  );
  // Every session that existed under the previous role is dropped.
  db.run('DELETE FROM sessions WHERE user_id = ?', existing.id);
  console.log(`Promoted ${email} to admin and reset the password.`);
} else {
  db.run(
    `INSERT INTO users (id, email, email_normalized, password_hash, full_name, phone,
                        role, status, password_changed_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, '', 'admin', 'active', ?, ?, ?)`,
    uuid(), email, email, hash, name, now, now, now
  );
  console.log(`Created admin ${email}.`);
}

console.log('');
console.log('Next: sign in at /login, then turn on two-factor from /account.');
await closeDb();
process.exit(0);
