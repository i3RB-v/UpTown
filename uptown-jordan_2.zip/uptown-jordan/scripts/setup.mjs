#!/usr/bin/env node
/**
 * First-run setup. Cross-platform — works in PowerShell, cmd, bash, zsh.
 *
 *   node scripts/setup.mjs
 *
 * Checks the Node version, writes a .env with freshly generated secrets,
 * creates the database, loads the demo catalogue, and tells you what to do
 * next. Safe to re-run: an existing .env is never overwritten.
 */
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(import.meta.url), '../..');
const ok = (m) => console.log(`  ✓ ${m}`);
const info = (m) => console.log(`    ${m}`);

console.log('\nUptown Jordan — setup\n');

/* ---------------------------------------------------------- 1. Node version */

const [major, minor] = process.versions.node.split('.').map(Number);
const supported = major > 22 || (major === 22 && minor >= 5);

if (!supported) {
  console.error(`  ✗ Node ${process.versions.node} is too old.\n`);
  console.error('    This project needs Node 22.5 or newer, because it uses');
  console.error('    the built-in node:sqlite module instead of a database');
  console.error('    dependency.\n');
  console.error('    Install the current LTS from https://nodejs.org, reopen');
  console.error('    your terminal, and run this again.\n');
  process.exit(1);
}
ok(`Node ${process.versions.node}`);

// node:sqlite is the one hard requirement — check it directly rather than
// trusting the version number, in case of an unusual build.
try {
  await import('node:sqlite');
  ok('node:sqlite available');
} catch {
  console.error('\n  ✗ This Node build has no node:sqlite module.');
  console.error('    Install the official build from https://nodejs.org.\n');
  process.exit(1);
}

/* ------------------------------------------------------------------ 2. .env */

const envPath = path.join(ROOT, '.env');
const examplePath = path.join(ROOT, '.env.example');

if (existsSync(envPath)) {
  ok('.env already exists — leaving it alone');
} else {
  const secret = () => randomBytes(32).toString('hex');
  let env = readFileSync(examplePath, 'utf8');

  for (const key of ['SESSION_SECRET', 'CSRF_SECRET', 'PASSWORD_PEPPER', 'PAYMENT_WEBHOOK_SECRET']) {
    env = env.replace(new RegExp(`^${key}=.*$`, 'm'), `${key}=${secret()}`);
  }

  // Local development defaults. DEPLOY.md covers the production values.
  env = env
    .replace(/^NODE_ENV=.*$/m, 'NODE_ENV=development')
    .replace(/^PUBLIC_ORIGIN=.*$/m, 'PUBLIC_ORIGIN=http://localhost:3000')
    .replace(/^TRUST_PROXY=.*$/m, 'TRUST_PROXY=0')
    .replace(/^DATABASE_FILE=.*$/m, 'DATABASE_FILE=./data/uptown.db')
    .replace(/^LOG_LEVEL=.*$/m, 'LOG_LEVEL=debug');

  writeFileSync(envPath, env, { mode: 0o600 });
  ok('.env created with four freshly generated secrets');
  info('(development settings — see DEPLOY.md before going live)');
}

/* -------------------------------------------------------- 3. database + seed */

// Keep setup output readable. Real env wins over .env, so this does not
// change the LOG_LEVEL written to the file.
process.env.LOG_LEVEL = 'silent';

const { migrate, closeDb } = await import('../src/db/index.js');
const { seed } = await import('../src/db/seed.js');

await migrate();
ok('database created (data/uptown.db)');

const counts = await seed();
ok(`catalogue loaded — ${counts.products} products, ${counts.variants} variants`);

await closeDb();

/* ----------------------------------------------------------------- 4. next */

console.log(`
Done. Two things left:

  1. Make yourself an admin account:

       npm run admin:create

  2. Start the store:

       npm run dev

  Then open http://localhost:3000

  Try: browse the shop, add something to your bag, check out with cash
  on delivery, then check out again by card — the card path runs through
  a built-in payment simulator so you can see the whole redirect and
  confirmation flow. Sign in at /admin to ship the order and watch the
  stock move.
`);
