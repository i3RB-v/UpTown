#!/usr/bin/env bash
# First-time TLS certificate issuance.
#
#   DOMAIN=uptownjordan.com EMAIL=you@example.com ./scripts/init-letsencrypt.sh
#
# Run once, after DNS points at this server and before `docker compose up -d`.
set -euo pipefail

DOMAIN="${DOMAIN:-}"
EMAIL="${EMAIL:-}"
STAGING="${STAGING:-0}"

if [[ -z "$DOMAIN" || -z "$EMAIL" ]]; then
  echo "usage: DOMAIN=example.com EMAIL=you@example.com $0" >&2
  exit 1
fi

mkdir -p ./certbot/conf ./certbot/www

# A throwaway self-signed pair so nginx can start; certbot replaces it.
if [[ ! -f "./certbot/conf/live/$DOMAIN/fullchain.pem" ]]; then
  echo "Creating a temporary self-signed certificate so nginx can boot..."
  mkdir -p "./certbot/conf/live/$DOMAIN"
  openssl req -x509 -nodes -newkey rsa:2048 -days 1 \
    -keyout "./certbot/conf/live/$DOMAIN/privkey.pem" \
    -out "./certbot/conf/live/$DOMAIN/fullchain.pem" \
    -subj "/CN=$DOMAIN" >/dev/null 2>&1
  cp "./certbot/conf/live/$DOMAIN/fullchain.pem" "./certbot/conf/live/$DOMAIN/chain.pem"
fi

docker compose up -d nginx
sleep 3

STAGING_FLAG=""
if [[ "$STAGING" == "1" ]]; then
  STAGING_FLAG="--staging"
  echo "Using the Let's Encrypt STAGING environment."
fi

echo "Requesting a certificate for $DOMAIN..."
docker compose run --rm --entrypoint certbot certbot \
  certonly --webroot -w /var/www/certbot \
  $STAGING_FLAG \
  --email "$EMAIL" --agree-tos --no-eff-email \
  --force-renewal \
  -d "$DOMAIN" -d "www.$DOMAIN"

docker compose up -d
echo "Done. Verify with: curl -I https://$DOMAIN"
