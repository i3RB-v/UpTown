import config from '../config.js';
import Router from '../core/router.js';
import { newTotpSecret, totpUri, verifyTotp } from '../core/crypto.js';
import { badRequest, forbidden, unauthorized } from '../core/errors.js';
import { readJson } from '../core/http.js';
import logger from '../core/logger.js';
import v from '../core/validate.js';
import { issueToken } from '../middleware/csrf.js';
import { guard, rateLimit, refund } from '../middleware/ratelimit.js';
import {
  createSession,
  destroyAllSessions,
  destroySession,
  markMfaSatisfied,
  requireAuth,
} from '../middleware/session.js';
import { getDb } from '../db/index.js';
import * as audit from '../services/audit.js';
import { mergeGuestCart } from '../services/cart.js';
import * as orders from '../services/orders.js';
import { governorateCodes } from '../services/shipping.js';
import * as users from '../services/users.js';

const router = new Router();

/* ------------------------------------------------------------------ auth */

const credentials = v.object({
  email: v.email(),
  password: v.string({ min: 1, max: config.password.maxLength, trim: false }),
});

const registration = v.object({
  email: v.email(),
  password: v.string({ min: 1, max: config.password.maxLength, trim: false }),
  fullName: v.string({ min: 2, max: 120, label: 'Full name' }),
  phone: v.phone().optional(''),
});

router.post('/register', rateLimit('register', config.limits.register), async (ctx) => {
  const body = registration.parse(await readJson(ctx.req));
  const result = await users.register(body);

  if (result.created) {
    await createSession(ctx, result.user);
    await mergeGuestCart(ctx, result.user.id);
    issueToken(ctx);
    await audit.record(ctx, 'user.register', { entity: 'user', entityId: result.user.id });
    return { user: result.user, created: true };
  }

  // The address was already registered. The response is deliberately the
  // same shape and status as a success — the endpoint must not reveal which
  // addresses have accounts. The real owner is told by email (wired in
  // src/services/mailer when you connect a provider).
  logger.info('registration attempt for existing address');
  return { user: null, created: true, checkEmail: true };
});

router.post('/login', async (ctx) => {
  const body = credentials.parse(await readJson(ctx.req));

  // Two budgets: one per IP (stops a single host spraying many accounts),
  // one per account (stops a botnet grinding one account from many hosts).
  await guard('login_ip', ctx.ip, config.limits.auth, 'Too many sign-in attempts. Try again in a few minutes.');
  await guard('login_account', body.email, config.limits.auth, 'Too many sign-in attempts. Try again in a few minutes.');

  const result = await users.authenticate(body);

  if (result.requiresTotp) {
    // Credentials are correct but the session is not yet privileged. A
    // short-lived half-session is created so the second factor has
    // something to attach to, with mfaOk explicitly false.
    await createSession(ctx, result.user, { mfaOk: false });
    issueToken(ctx);
    return { user: null, mfaRequired: true };
  }

  await createSession(ctx, result.user, { mfaOk: true });
  await mergeGuestCart(ctx, result.user.id);
  issueToken(ctx);

  await refund('login_ip', ctx.ip);
  await refund('login_account', body.email);
  await audit.record(ctx, 'user.login', { entity: 'user', entityId: result.user.id });

  return { user: result.user, mfaRequired: false };
});

const totpSchema = v.object({ code: v.string({ min: 6, max: 6, label: 'Code' }) });

router.post('/login/totp', async (ctx) => {
  const session = ctx.state.session;
  if (!session?.userId) throw unauthorized('Start by entering your email and password.');
  if (session.mfaOk) return { user: ctx.state.user, mfaRequired: false };

  await guard('totp', session.userId, [10, 10 * 60_000], 'Too many codes. Please wait a moment.');

  const body = totpSchema.parse(await readJson(ctx.req));
  const db = await getDb();
  const row = db.get('SELECT totp_secret, totp_enabled FROM users WHERE id = ?', session.userId);
  if (!row?.totp_enabled || !row.totp_secret) throw badRequest('Two-factor is not enabled on this account.');

  if (!verifyTotp(row.totp_secret, body.code)) {
    await audit.record(ctx, 'user.totp_failed', { entity: 'user', entityId: session.userId });
    throw unauthorized('That code is not valid.');
  }

  await markMfaSatisfied(ctx);
  await mergeGuestCart(ctx, session.userId);
  await audit.record(ctx, 'user.login_totp', { entity: 'user', entityId: session.userId });
  return { user: await users.findById(session.userId), mfaRequired: false };
});

router.post('/logout', async (ctx) => {
  const userId = ctx.state.user?.id;
  await destroySession(ctx);
  if (userId) await audit.record(ctx, 'user.logout', { entity: 'user', entityId: userId });
  return { ok: true };
});

router.get('/me', async (ctx) => ({
  user: ctx.state.user
    ? { ...(await users.findById(ctx.state.user.id)), mfaSatisfied: Boolean(ctx.state.session?.mfaOk) }
    : null,
}));

/* -------------------------------------------------------- password reset */

router.post('/password/forgot', rateLimit('forgot', [5, 60 * 60_000]), async (ctx) => {
  const body = v.object({ email: v.email() }).parse(await readJson(ctx.req));
  const result = await users.requestReset(body.email);

  if (result.token) {
    // No mail provider is wired in by default. The link is logged at debug
    // level in development and MUST be sent by email in production — see
    // README "Wiring email".
    logger.debug('password reset issued', { userId: result.userId });
    if (!config.isProd) {
      return { ok: true, devResetToken: result.token };
    }
  }

  // Identical response either way: this endpoint cannot enumerate accounts.
  return { ok: true };
});

router.post('/password/reset', rateLimit('reset', [10, 60 * 60_000]), async (ctx) => {
  const body = v
    .object({
      token: v.token({ max: 128 }),
      password: v.string({ min: 1, max: config.password.maxLength, trim: false }),
    })
    .parse(await readJson(ctx.req));

  const result = await users.completeReset({ token: body.token, newPassword: body.password });
  await audit.record(ctx, 'user.password_reset', { entity: 'user', entityId: result.userId });
  return { ok: true };
});

/* ----------------------------------------------------------- the account */

router.get('/account', requireAuth, async (ctx) => ({
  user: await users.findById(ctx.state.user.id),
  addresses: await users.listAddresses(ctx.state.user.id),
}));

const profileSchema = v.object({
  fullName: v.string({ min: 2, max: 120, label: 'Full name' }),
  phone: v.phone().optional(''),
});

router.patch('/account', requireAuth, async (ctx) => {
  const body = profileSchema.parse(await readJson(ctx.req));
  const user = await users.updateProfile(ctx.state.user.id, body);
  await audit.record(ctx, 'user.profile_update', { entity: 'user', entityId: user.id });
  return { user };
});

router.post('/account/password', requireAuth, async (ctx) => {
  const body = v
    .object({
      currentPassword: v.string({ min: 1, max: config.password.maxLength, trim: false }),
      newPassword: v.string({ min: 1, max: config.password.maxLength, trim: false }),
    })
    .parse(await readJson(ctx.req));

  await guard('change_pw', ctx.state.user.id, [10, 60 * 60_000], 'Too many attempts. Please wait.');
  await users.changePassword({ userId: ctx.state.user.id, ...body });

  // Keep the current device signed in, drop every other one.
  await destroyAllSessions(ctx.state.user.id, ctx.state.session.id);
  await audit.record(ctx, 'user.password_change', { entity: 'user', entityId: ctx.state.user.id });

  return { ok: true, otherSessionsSignedOut: true };
});

const addressSchema = v.object({
  label: v.string({ max: 40 }).optional(''),
  fullName: v.string({ min: 3, max: 120, label: 'Full name' }),
  phone: v.phone(),
  governorate: v.enum(governorateCodes(), { label: 'Governorate' }),
  city: v.string({ min: 2, max: 80, label: 'City' }),
  street: v.string({ min: 3, max: 200, label: 'Street' }),
  building: v.string({ max: 120 }).optional(''),
  notes: v.text({ max: 500 }).optional(''),
  isDefault: v.bool().optional(false),
});

router.get('/account/addresses', requireAuth, async (ctx) => ({
  addresses: await users.listAddresses(ctx.state.user.id),
}));

router.post('/account/addresses', requireAuth, async (ctx) => {
  const body = addressSchema.parse(await readJson(ctx.req));
  const result = await users.saveAddress(ctx.state.user.id, body);
  return { id: result.id, addresses: await users.listAddresses(ctx.state.user.id) };
});

router.patch('/account/addresses/:id', requireAuth, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  const body = addressSchema.parse(await readJson(ctx.req));
  await users.saveAddress(ctx.state.user.id, body, id);
  return { addresses: await users.listAddresses(ctx.state.user.id) };
});

router.delete('/account/addresses/:id', requireAuth, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  await users.deleteAddress(ctx.state.user.id, id);
  return { addresses: await users.listAddresses(ctx.state.user.id) };
});

router.get('/account/orders', requireAuth, async (ctx) => {
  const q = v
    .object({
      limit: v.int({ min: 1, max: 50 }).optional(20),
      offset: v.int({ min: 0, max: 5000 }).optional(0),
    })
    .parse(ctx.query);
  return { orders: await orders.listForUser(ctx.state.user.id, q) };
});

router.get('/account/orders/:id', requireAuth, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  return { order: await orders.getForUser(ctx.state.user.id, id) };
});

router.get('/account/reviewable', requireAuth, async (ctx) => {
  const reviews = await import('../services/reviews.js');
  const items = await reviews.reviewableFor(ctx.state.user.id);
  return {
    items: items.map((i) => ({
      slug: i.slug,
      title: i.title,
      sizeBought: i.size_bought,
      imageUrl: i.image_url || '',
      deliveredAt: i.delivered_at,
    })),
  };
});

/* ---------------------------------------------------- two-factor set-up */

router.post('/account/totp/start', requireAuth, async (ctx) => {
  const db = await getDb();
  const secret = newTotpSecret();
  // Stored but not yet enabled: it only becomes active once a valid code
  // proves the authenticator app actually holds it.
  db.run('UPDATE users SET totp_secret = ?, updated_at = ? WHERE id = ?', secret, Date.now(), ctx.state.user.id);
  return { secret, uri: totpUri(secret, ctx.state.user.email) };
});

router.post('/account/totp/enable', requireAuth, async (ctx) => {
  const body = totpSchema.parse(await readJson(ctx.req));
  const db = await getDb();
  const row = db.get('SELECT totp_secret FROM users WHERE id = ?', ctx.state.user.id);
  if (!row?.totp_secret) throw badRequest('Start the set-up first.');
  if (!verifyTotp(row.totp_secret, body.code)) throw badRequest('That code is not valid. Try the next one.');

  db.run('UPDATE users SET totp_enabled = 1, updated_at = ? WHERE id = ?', Date.now(), ctx.state.user.id);
  await markMfaSatisfied(ctx);
  await audit.record(ctx, 'user.totp_enabled', { entity: 'user', entityId: ctx.state.user.id });
  return { ok: true };
});

router.post('/account/totp/disable', requireAuth, async (ctx) => {
  const body = v
    .object({ password: v.string({ min: 1, max: config.password.maxLength, trim: false }) })
    .parse(await readJson(ctx.req));

  // Turning off a second factor is a sensitive action — re-authenticate.
  await users.authenticate({ email: ctx.state.user.email, password: body.password }).catch(() => {
    throw forbidden('Please confirm your password.');
  });

  const db = await getDb();
  db.run('UPDATE users SET totp_enabled = 0, totp_secret = NULL, updated_at = ? WHERE id = ?',
    Date.now(), ctx.state.user.id);
  await audit.record(ctx, 'user.totp_disabled', { entity: 'user', entityId: ctx.state.user.id });
  return { ok: true };
});

export default router;
