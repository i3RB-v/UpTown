import config from '../config.js';
import Router from '../core/router.js';
import { randomToken } from '../core/crypto.js';
import { badRequest, conflict } from '../core/errors.js';
import { readJson } from '../core/http.js';
import v from '../core/validate.js';
import { rateLimit } from '../middleware/ratelimit.js';
import * as cart from '../services/cart.js';
import * as catalog from '../services/catalog.js';
import * as orders from '../services/orders.js';
import * as payments from '../services/payments.js';
import * as notify from '../services/notify.js';
import * as reviews from '../services/reviews.js';
import { governorateCodes, GOVERNORATES, quote } from '../services/shipping.js';
import { requireAuth } from '../middleware/session.js';

const router = new Router();

/* ------------------------------------------------------------------ meta */

router.get('/config', async () => ({
  store: {
    name: config.store.name,
    currency: config.store.currency,
    freeShippingThresholdFils: config.store.freeShippingThreshold,
    supportWhatsapp: config.store.supportWhatsapp,
  },
  governorates: GOVERNORATES.map((g) => ({
    code: g.code,
    name: g.name,
    feeFils: g.feeFils,
    etaDays: g.etaDays,
    sameDay: g.sameDay,
  })),
  paymentMethods: [
    { code: 'cod', label: 'Cash on delivery', available: true },
    { code: 'card', label: 'Card payment', available: true },
  ],
}));

/** Issues/refreshes the CSRF cookie. The client calls this on boot. */
router.get('/csrf', async (ctx) => {
  const { issueToken } = await import('../middleware/csrf.js');
  return { token: issueToken(ctx) };
});

/* -------------------------------------------------------------- catalogue */

const listQuery = v.object({
  collection: v.slug().optional(null),
  search: v.string({ max: 80 }).optional(''),
  sort: v.enum(['featured', 'newest', 'price_asc', 'price_desc', 'name']).optional('featured'),
  limit: v.int({ min: 1, max: 60 }).optional(24),
  offset: v.int({ min: 0, max: 5000 }).optional(0),
  featured: v.bool().optional(false),
});

router.get('/collections', async () => ({ collections: await catalog.listCollections() }));

router.get('/products', async (ctx) => {
  const q = listQuery.parse(ctx.query);
  return catalog.listProducts({
    collection: q.collection,
    search: q.search,
    sort: q.sort,
    limit: q.limit,
    offset: q.offset,
    featuredOnly: q.featured,
  });
});

router.get('/products/:slug', async (ctx) => {
  const slug = v.slug().parse(ctx.params.slug);
  return catalog.getProductBySlug(slug);
});

/* ------------------------------------------------------------------- cart */

const cartQuery = v.object({
  governorate: v.enum(governorateCodes()).optional(null),
  paymentMethod: v.enum(['cod', 'card']).optional('cod'),
});

router.get('/cart', async (ctx) => {
  const q = cartQuery.parse(ctx.query);
  return { cart: await cart.getCart(ctx, q) };
});

const addSchema = v.object({
  variantId: v.uuid(),
  qty: v.int({ min: 1, max: config.cart.maxQtyPerLine }).optional(1),
});

router.post('/cart/items', async (ctx) => {
  const body = addSchema.parse(await readJson(ctx.req));
  const result = await cart.addItem(ctx, body.variantId, body.qty);
  return {
    cart: await cart.getCart(ctx),
    clamped: result.clamped,
    message: result.clamped ? `Only ${result.capped} available — we adjusted the quantity.` : null,
  };
});

const qtySchema = v.object({
  qty: v.int({ min: 0, max: config.cart.maxQtyPerLine }),
});

router.patch('/cart/items/:variantId', async (ctx) => {
  const variantId = v.uuid().parse(ctx.params.variantId);
  const { qty } = qtySchema.parse(await readJson(ctx.req));
  const result = await cart.setQty(ctx, variantId, qty);
  return { cart: await cart.getCart(ctx), clamped: Boolean(result.clamped) };
});

router.delete('/cart/items/:variantId', async (ctx) => {
  const variantId = v.uuid().parse(ctx.params.variantId);
  await cart.removeItem(ctx, variantId);
  return { cart: await cart.getCart(ctx) };
});

router.delete('/cart', async (ctx) => {
  await cart.clearCart(ctx);
  return { cart: await cart.getCart(ctx) };
});

/* --------------------------------------------------------------- shipping */

const quoteSchema = v.object({
  governorate: v.enum(governorateCodes(), { label: 'Governorate' }),
  paymentMethod: v.enum(['cod', 'card']).optional('cod'),
});

router.post('/shipping/quote', async (ctx) => {
  const body = quoteSchema.parse(await readJson(ctx.req));
  const current = await cart.getCart(ctx, body);
  return {
    shipping: quote({ subtotalFils: current.subtotalFils, ...body }),
    cart: current,
  };
});

/* --------------------------------------------------------------- checkout */

const checkoutSchema = v.object({
  email: v.email(),
  phone: v.phone(),
  paymentMethod: v.enum(['cod', 'card'], { label: 'Payment method' }),
  shipping: v.object({
    fullName: v.string({ min: 3, max: 120, label: 'Full name' }),
    phone: v.phone(),
    governorate: v.enum(governorateCodes(), { label: 'Governorate' }),
    city: v.string({ min: 2, max: 80, label: 'City' }),
    street: v.string({ min: 3, max: 200, label: 'Street' }),
    building: v.string({ max: 120 }).optional(''),
    notes: v.text({ max: 500 }).optional(''),
  }),
  // Accepted but never trusted: the server recomputes the real total and
  // rejects the order if the client's figure disagrees. That turns a
  // tampered or merely stale checkout page into an error rather than a
  // mispriced sale.
  expectedTotalFils: v.int({ min: 0 }).optional(null),
});

router.post(
  '/checkout',
  rateLimit('checkout', config.limits.checkout),
  async (ctx) => {
    const body = checkoutSchema.parse(await readJson(ctx.req));
    const idempotencyKey =
      String(ctx.req.headers['idempotency-key'] || '').slice(0, 200) || null;

    // A retry of an order that already succeeded must return that order, not
    // complain that the (now emptied) bag is empty.
    const replay = await orders.replayCheckout({ ...body, idempotencyKey });
    if (replay) return replay;

    const preview = await cart.getCart(ctx, {
      governorate: body.shipping.governorate,
      paymentMethod: body.paymentMethod,
    });

    if (!preview.lines.length) {
      // getCart drops lines that sold out while the customer was deciding.
      // Say which item went, rather than the unhelpful "your bag is empty".
      if (preview.issues.length) throw conflict(preview.issues[0].message);
      throw badRequest('Your bag is empty.');
    }

    if (body.expectedTotalFils !== null && body.expectedTotalFils !== preview.totalFils) {
      throw badRequest(
        'Your bag changed while you were checking out. Please review the updated total.'
      );
    }

    const result = await orders.createFromCart(ctx, {
      ...body,
      idempotencyKey,
    });

    if (body.paymentMethod === 'card' && !result.idempotentReplay) {
      const intent = await payments.createIntent({
        id: result.order.id,
        totalFils: result.order.totalFils,
        currency: result.order.currency,
      });
      return { ...result, payment: { redirectUrl: intent.redirectUrl, reference: intent.reference } };
    }

    return result;
  }
);

/* ------------------------------------------------------------ order lookup */

const lookupSchema = v.object({
  number: v.string({ min: 6, max: 32, label: 'Order number' }),
  token: v.token({ max: 128 }),
});

router.post(
  '/orders/lookup',
  // Throttled per IP: the order number plus token pair is unguessable, but
  // there is no reason to allow anyone to grind at it.
  rateLimit('order_lookup', [30, 15 * 60_000]),
  async (ctx) => {
    const body = lookupSchema.parse(await readJson(ctx.req));
    return { order: await orders.lookup(body.number, body.token) };
  }
);

/* ---------------------------------------------------------------- reviews */

router.get('/products/:slug/reviews', async (ctx) => {
  const slug = v.slug().parse(ctx.params.slug);
  const q = v
    .object({
      limit: v.int({ min: 1, max: 50 }).optional(20),
      offset: v.int({ min: 0, max: 5000 }).optional(0),
    })
    .parse(ctx.query);
  return { reviews: await reviews.forProduct(slug, q) };
});

const reviewSchema = v.object({
  rating: v.int({ min: 1, max: 5 }),
  title: v.string({ min: 3, max: 90, label: 'Headline' }),
  body: v.text({ min: 10, max: 1500 }),
});

router.post(
  '/products/:slug/reviews',
  requireAuth,
  // Keyed on the ACCOUNT, not the IP. Jordanian mobile networks put large
  // numbers of customers behind one address, and an IP-keyed budget here
  // would have them silently blocking each other. Abuse is bounded instead
  // by the per-IP limit on account creation, plus moderation.
  rateLimit('review', [3, 24 * 60 * 60_000], (ctx) => ctx.state.user?.id ?? ctx.ip),
  async (ctx) => {
    const slug = v.slug().parse(ctx.params.slug);
    const body = reviewSchema.parse(await readJson(ctx.req));

    const result = await reviews.submit({
      userId: ctx.state.user.id,
      productSlug: slug,
      authorName: ctx.state.user.fullName || '',
      ...body,
    });

    return {
      ...result,
      message: 'Thank you — your review is with us and will appear once it has been read.',
    };
  }
);

/* ----------------------------------------------------- newsletter & alerts */

router.post('/newsletter', rateLimit('newsletter', [5, 60 * 60_000]), async (ctx) => {
  const body = v.object({ email: v.email() }).parse(await readJson(ctx.req));
  const result = await notify.subscribe(body.email);

  // The same answer whether the address is new, pending or already on the
  // list — this form cannot be used to check who is subscribed.
  const response = {
    ok: true,
    message: 'Almost there — check your email and confirm to finish subscribing.',
  };

  // Without a mail provider there is no way to deliver the link, so in
  // development it comes back in the response to keep the flow testable.
  if (!config.isProd && result.token) {
    response.devConfirmUrl = notify.confirmUrl(result.token);
  }
  return response;
});

router.post('/newsletter/confirm', rateLimit('newsletter_confirm', [20, 60 * 60_000]), async (ctx) => {
  const body = v.object({ token: v.token({ max: 128 }) }).parse(await readJson(ctx.req));
  const result = await notify.confirm(body.token);
  return {
    ok: true,
    message: result.alreadyConfirmed
      ? 'You were already on the list — nothing more to do.'
      : 'You are on the list. Drops land in your inbox first.',
  };
});

router.post('/newsletter/unsubscribe', rateLimit('newsletter', [10, 60 * 60_000]), async (ctx) => {
  const body = v.object({ email: v.email() }).parse(await readJson(ctx.req));
  await notify.unsubscribe(body.email);
  return { ok: true, message: 'You will not hear from us again.' };
});

router.post('/variants/:id/notify-me', rateLimit('stock_alert', [20, 60 * 60_000]), async (ctx) => {
  const variantId = v.uuid().parse(ctx.params.id);
  const body = v.object({ email: v.email() }).parse(await readJson(ctx.req));

  // A second budget per address, so one person cannot queue alerts on the
  // whole catalogue and one shared IP cannot lock everyone else out.
  const { guard } = await import('../middleware/ratelimit.js');
  await guard('stock_alert_email', body.email, [10, 60 * 60_000],
    'You have set up several alerts already. Try again later.');

  const result = await notify.watchVariant(variantId, body.email);

  return {
    ok: true,
    inStock: result.inStock,
    message: result.inStock
      ? `Good news — ${result.product} is back in ${result.size}.`
      : `We'll email you the moment ${result.product} returns in ${result.size}.`,
  };
});

/* ---------------------------------------------------------------- contact */

const enquirySchema = v.object({
  name: v.string({ min: 2, max: 120, label: 'Name' }),
  email: v.email(),
  phone: v.phone().optional(''),
  topic: v.enum(['general', 'order', 'returns', 'sizing', 'wholesale'], { label: 'Topic' }),
  orderNumber: v.string({ max: 32 }).optional(''),
  message: v.text({ min: 10, max: 2000 }),
});

router.post('/contact', rateLimit('contact', [5, 60 * 60_000]), async (ctx) => {
  const body = enquirySchema.parse(await readJson(ctx.req));
  const { fingerprint } = await import('../core/crypto.js');
  await notify.recordEnquiry({ ...body, ipHash: fingerprint(ctx.ip) });
  return {
    ok: true,
    message: 'Thank you — we read everything and usually reply within one working day.',
  };
});

export default router;
