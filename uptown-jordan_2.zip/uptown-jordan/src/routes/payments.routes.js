import config from '../config.js';
import Router from '../core/router.js';
import { badRequest, forbidden } from '../core/errors.js';
import { readJson, readRawBody } from '../core/http.js';
import { formatFils } from '../core/money.js';
import logger from '../core/logger.js';
import v from '../core/validate.js';
import { rateLimit } from '../middleware/ratelimit.js';
import * as payments from '../services/payments.js';

const router = new Router();

/* ------------------------------------------------------------- webhooks */

/**
 * Provider webhook.
 *
 * Deliberately *not* CSRF-protected and not session-authenticated: the HMAC
 * signature over the raw body is the authentication. Three things are
 * checked before any state changes — signature, timestamp freshness, and
 * event-id uniqueness — and the response is a bare 200 with no detail, so a
 * prober learns nothing about which references exist.
 */
router.post(
  '/webhooks/payments',
  rateLimit('webhook', config.limits.webhook),
  async (ctx) => {
    const raw = await readRawBody(ctx.req, 32 * 1024);

    if (!payments.verifyWebhookSignature(ctx.req.headers, raw)) {
      logger.warn('webhook signature rejected', { ip: 'redacted' });
      // 400, not 401: the caller is not a user and there is nothing to
      // authenticate against. No hint about which check failed.
      throw badRequest('Invalid signature.');
    }

    const result = await payments.handleEvent(raw);
    logger.info('webhook processed', { applied: result.applied, reason: result.reason });
    return { received: true };
  }
);

/* --------------------------------------------------- mock hosted checkout */

/**
 * The bundled `mock` provider.
 *
 * It exists so the full card path — intent, redirect, signed webhook,
 * order confirmation — is exercisable end to end without a merchant
 * account, and so the tests cover the same verification code a real
 * provider hits. It refuses to run unless PAYMENT_PROVIDER=mock.
 *
 * It accepts no card number. There is no field for one, by design: swapping
 * in a real provider means pointing createIntent at their hosted page, not
 * adding PAN handling here.
 */
function assertMock() {
  if (config.payments.provider !== 'mock') {
    throw forbidden('The mock payment provider is not enabled.');
  }
}

/** Intent details for the mock page to render. Read-only, no secrets. */
router.get('/pay/:reference/intent', async (ctx) => {
  assertMock();
  const reference = v.string({ max: 64, pattern: /^pi_[A-Za-z0-9_-]+$/ }).parse(ctx.params.reference);
  const intent = await payments.getIntent(reference);
  return {
    reference,
    orderNumber: intent.number,
    amountFils: intent.amount_fils,
    amount: formatFils(intent.amount_fils),
    currency: intent.currency,
    status: intent.status,
  };
});

const completeSchema = v.object({
  outcome: v.enum(['succeed', 'fail'], { label: 'Outcome' }),
});

router.post('/pay/:reference/complete', rateLimit('mockpay', [30, 15 * 60_000]), async (ctx) => {
  assertMock();
  const reference = v.string({ max: 64, pattern: /^pi_[A-Za-z0-9_-]+$/ }).parse(ctx.params.reference);
  const body = completeSchema.parse(await readJson(ctx.req));
  const intent = await payments.getIntent(reference);

  if (intent.status !== 'created') throw badRequest('This payment has already been processed.');

  // The amount comes from the intent row. Even the simulator cannot choose
  // what it pays — which is the point being demonstrated.
  const event =
    body.outcome === 'succeed'
      ? await payments.emitMockEvent('payment.succeeded', {
          reference,
          amountFils: intent.amount_fils,
          currency: intent.currency,
          cardBrand: 'visa',
          cardLast4: '4242',
        })
      : await payments.emitMockEvent('payment.failed', {
          reference,
          reason: 'The card was declined by the issuer.',
        });

  // Routed through the same verification path a real provider takes.
  if (!payments.verifyWebhookSignature({ [payments.SIGNATURE_HEADER]: event.signature }, event.body)) {
    throw badRequest('Signature generation failed.');
  }
  const result = await payments.handleEvent(event.body);

  return {
    ok: true,
    outcome: body.outcome,
    orderNumber: intent.number,
    applied: result.applied,
  };
});

export default router;
