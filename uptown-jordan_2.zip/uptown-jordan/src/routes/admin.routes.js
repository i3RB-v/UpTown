import config from '../config.js';
import Router from '../core/router.js';
import { uuid } from '../core/crypto.js';
import { badRequest, conflict, notFound } from '../core/errors.js';
import { readJson } from '../core/http.js';
import { parseAmount } from '../core/money.js';
import v from '../core/validate.js';
import { rateLimit } from '../middleware/ratelimit.js';
import { requireRole } from '../middleware/session.js';
import { getDb } from '../db/index.js';
import * as audit from '../services/audit.js';
import * as catalog from '../services/catalog.js';
import * as notify from '../services/notify.js';
import * as orders from '../services/orders.js';
import * as reviews from '../services/reviews.js';

const router = new Router();

/**
 * Admin API.
 *
 * Every route carries `requireRole`, which also enforces that a staff
 * account with TOTP enrolled has satisfied it *for this session*. Every
 * mutation writes an audit row. Amounts arriving from the admin UI go
 * through parseAmount, so a typo cannot store a float or a negative price.
 */

const staff = requireRole('admin', 'staff');
const adminOnly = requireRole('admin');
const limit = rateLimit('admin', config.limits.admin);

/* ------------------------------------------------------------- dashboard */

router.get('/stats', limit, staff, async () => orders.stats());

router.get('/audit', limit, adminOnly, async (ctx) => {
  const q = v
    .object({
      limit: v.int({ min: 1, max: 200 }).optional(100),
      offset: v.int({ min: 0, max: 100000 }).optional(0),
    })
    .parse(ctx.query);
  return { entries: await audit.list(q) };
});

/* ---------------------------------------------------------------- orders */

router.get('/orders', limit, staff, async (ctx) => {
  const q = v
    .object({
      status: v
        .enum(['pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'])
        .optional(null),
      search: v.string({ max: 80 }).optional(''),
      limit: v.int({ min: 1, max: 100 }).optional(30),
      offset: v.int({ min: 0, max: 100000 }).optional(0),
    })
    .parse(ctx.query);
  return orders.adminList(q);
});

router.get('/orders/:id', limit, staff, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  return { order: await orders.adminGet(id) };
});

const transitionSchema = v.object({
  action: v.enum(['mark_paid', 'mark_shipped', 'mark_delivered', 'cancel'], { label: 'Action' }),
  reason: v.text({ max: 300 }).optional(''),
});

router.post('/orders/:id/transition', limit, staff, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  const body = transitionSchema.parse(await readJson(ctx.req));
  const actor = ctx.state.user.email;

  switch (body.action) {
    case 'mark_paid':
      await orders.markPaid(id, { provider: 'manual', reference: actor });
      break;
    case 'mark_shipped':
      await orders.markShipped(id, { actor });
      break;
    case 'mark_delivered':
      await orders.markDelivered(id, { actor });
      break;
    case 'cancel':
      await orders.cancel(id, { reason: body.reason || 'Cancelled by staff.', actor });
      break;
    default:
      throw badRequest('Unknown action.');
  }

  await audit.record(ctx, `order.${body.action}`, {
    entity: 'order',
    entityId: id,
    detail: body.reason || '',
  });
  return { order: await orders.adminGet(id) };
});

/* -------------------------------------------------------------- products */

router.get('/products', limit, staff, async (ctx) => {
  const q = v
    .object({
      search: v.string({ max: 80 }).optional(''),
      limit: v.int({ min: 1, max: 60 }).optional(40),
      offset: v.int({ min: 0, max: 100000 }).optional(0),
    })
    .parse(ctx.query);
  return catalog.listProducts({ ...q, includeDrafts: true, sort: 'newest' });
});

const productSchema = v.object({
  slug: v.slug(),
  title: v.string({ min: 2, max: 140, label: 'Title' }),
  subtitle: v.string({ max: 200 }).optional(''),
  description: v.text({ max: 4000 }).optional(''),
  material: v.string({ max: 300 }).optional(''),
  care: v.string({ max: 300 }).optional(''),
  collectionSlug: v.slug().optional(null),
  price: v.string({ max: 20, label: 'Price' }),
  compareAt: v.string({ max: 20 }).optional(''),
  badge: v.string({ max: 24 }).optional(''),
  status: v.enum(['draft', 'active', 'archived']).optional('draft'),
  isFeatured: v.bool().optional(false),
  images: v
    .array(
      v.object({
        url: v.url({ hosts: [new URL(config.assetOrigin).host] }),
        alt: v.string({ max: 200 }).optional(''),
      }),
      { max: 8 }
    )
    .optional([]),
});

async function resolveCollectionId(db, slug) {
  if (!slug) return null;
  const row = db.get('SELECT id FROM collections WHERE slug = ?', slug);
  if (!row) throw badRequest('That collection does not exist.');
  return row.id;
}

router.post('/products', limit, adminOnly, async (ctx) => {
  const body = productSchema.parse(await readJson(ctx.req));
  const priceFils = parseAmount(body.price);
  if (priceFils === null) throw badRequest('Price must be an amount like 38.500');
  const compareFils = body.compareAt ? parseAmount(body.compareAt) : null;
  if (body.compareAt && compareFils === null) throw badRequest('Compare-at price is not valid.');

  const db = await getDb();
  const collectionId = await resolveCollectionId(db, body.collectionSlug);
  const now = Date.now();
  const id = uuid();

  try {
    db.tx(() => {
      db.run(
        `INSERT INTO products (id, slug, title, subtitle, description, material, care,
                               collection_id, price_fils, compare_at_fils, badge, status,
                               is_featured, sort_order, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`,
        id, body.slug, body.title, body.subtitle, body.description, body.material, body.care,
        collectionId, priceFils, compareFils, body.badge, body.status,
        body.isFeatured ? 1 : 0, now, now
      );
      body.images.forEach((img, i) => {
        db.run(
          'INSERT INTO product_images (id, product_id, url, alt, sort_order) VALUES (?, ?, ?, ?, ?)',
          uuid(), id, img.url, img.alt, i
        );
      });
    });
  } catch (err) {
    if (String(err?.message || '').includes('UNIQUE')) throw conflict('That slug is already in use.');
    throw err;
  }

  await audit.record(ctx, 'product.create', { entity: 'product', entityId: id, detail: body.slug });
  return { id, slug: body.slug };
});

router.patch('/products/:id', limit, adminOnly, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  const body = productSchema.parse(await readJson(ctx.req));
  const priceFils = parseAmount(body.price);
  if (priceFils === null) throw badRequest('Price must be an amount like 38.500');
  const compareFils = body.compareAt ? parseAmount(body.compareAt) : null;

  const db = await getDb();
  const collectionId = await resolveCollectionId(db, body.collectionSlug);

  const changed = db.tx(() => {
    const n = db.run(
      `UPDATE products SET slug = ?, title = ?, subtitle = ?, description = ?, material = ?,
                           care = ?, collection_id = ?, price_fils = ?, compare_at_fils = ?,
                           badge = ?, status = ?, is_featured = ?, updated_at = ?
        WHERE id = ?`,
      body.slug, body.title, body.subtitle, body.description, body.material, body.care,
      collectionId, priceFils, compareFils, body.badge, body.status,
      body.isFeatured ? 1 : 0, Date.now(), id
    ).changes;
    if (!n) return 0;
    if (body.images.length) {
      db.run('DELETE FROM product_images WHERE product_id = ?', id);
      body.images.forEach((img, i) => {
        db.run(
          'INSERT INTO product_images (id, product_id, url, alt, sort_order) VALUES (?, ?, ?, ?, ?)',
          uuid(), id, img.url, img.alt, i
        );
      });
    }
    return n;
  });

  if (!changed) throw notFound('Product not found.');
  await audit.record(ctx, 'product.update', { entity: 'product', entityId: id, detail: body.slug });
  return { ok: true };
});

/* -------------------------------------------------------------- variants */

const variantSchema = v.object({
  sku: v.string({ min: 2, max: 40, label: 'SKU', pattern: /^[A-Za-z0-9._-]+$/ }),
  size: v.string({ min: 1, max: 20, label: 'Size' }),
  colour: v.string({ max: 40 }).optional(''),
  price: v.string({ max: 20 }).optional(''),
  stock: v.int({ min: 0, max: 100000 }),
  isActive: v.bool().optional(true),
});

router.post('/products/:id/variants', limit, adminOnly, async (ctx) => {
  const productId = v.uuid().parse(ctx.params.id);
  const body = variantSchema.parse(await readJson(ctx.req));
  const priceFils = body.price ? parseAmount(body.price) : null;
  if (body.price && priceFils === null) throw badRequest('Variant price is not valid.');

  const db = await getDb();
  if (!db.get('SELECT id FROM products WHERE id = ?', productId)) throw notFound('Product not found.');

  const id = uuid();
  const now = Date.now();
  try {
    db.run(
      `INSERT INTO variants (id, product_id, sku, size, colour, price_fils, stock, reserved,
                             is_active, sort_order, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 0, ?, ?)`,
      id, productId, body.sku, body.size, body.colour, priceFils, body.stock,
      body.isActive ? 1 : 0, now, now
    );
  } catch (err) {
    if (String(err?.message || '').includes('UNIQUE')) throw conflict('That SKU already exists.');
    throw err;
  }

  await audit.record(ctx, 'variant.create', { entity: 'variant', entityId: id, detail: body.sku });
  return { id };
});

const stockSchema = v.object({
  stock: v.int({ min: 0, max: 100000 }),
  isActive: v.bool().optional(true),
});

router.patch('/variants/:id', limit, staff, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  const body = stockSchema.parse(await readJson(ctx.req));

  const db = await getDb();
  const row = db.get('SELECT reserved FROM variants WHERE id = ?', id);
  if (!row) throw notFound('Variant not found.');
  // The schema's `reserved <= stock` CHECK would reject this anyway; failing
  // here gives the operator a sentence they can act on instead of a
  // constraint error.
  if (body.stock < row.reserved) {
    throw conflict(`${row.reserved} unit(s) are held by open orders. Stock cannot go below that.`);
  }

  db.run('UPDATE variants SET stock = ?, is_active = ?, updated_at = ? WHERE id = ?',
    body.stock, body.isActive ? 1 : 0, Date.now(), id);

  await audit.record(ctx, 'variant.stock', {
    entity: 'variant', entityId: id, detail: `stock=${body.stock}`,
  });
  return { ok: true };
});

/* --------------------------------------------------------------- reviews */

router.get('/reviews', limit, staff, async (ctx) => {
  const q = v
    .object({
      status: v.enum(['pending', 'published', 'rejected']).optional('pending'),
      limit: v.int({ min: 1, max: 100 }).optional(50),
      offset: v.int({ min: 0, max: 10000 }).optional(0),
    })
    .parse(ctx.query);
  return { reviews: await reviews.pending(q) };
});

router.post('/reviews/:id/moderate', limit, staff, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  const body = v
    .object({ action: v.enum(['publish', 'reject'], { label: 'Action' }) })
    .parse(await readJson(ctx.req));

  const result = await reviews.moderate(id, { action: body.action, moderator: ctx.state.user.email });
  await audit.record(ctx, `review.${body.action}`, { entity: 'review', entityId: id });
  return result;
});

/* ------------------------------------------------------------- enquiries */

router.get('/enquiries', limit, staff, async (ctx) => {
  const q = v
    .object({
      status: v.enum(['open', 'answered', 'closed']).optional('open'),
      limit: v.int({ min: 1, max: 100 }).optional(50),
      offset: v.int({ min: 0, max: 10000 }).optional(0),
    })
    .parse(ctx.query);
  return { enquiries: await notify.listEnquiries(q) };
});

router.post('/enquiries/:id/status', limit, staff, async (ctx) => {
  const id = v.uuid().parse(ctx.params.id);
  const body = v
    .object({ status: v.enum(['open', 'answered', 'closed']) })
    .parse(await readJson(ctx.req));
  const result = await notify.closeEnquiry(id, body.status);
  await audit.record(ctx, 'enquiry.status', { entity: 'enquiry', entityId: id, detail: body.status });
  return result;
});

/* ------------------------------------------------- outstanding stock alerts */

/**
 * Customers waiting on sizes that are now back in stock.
 *
 * Purely a read. Once a mail transport exists, send to these and call
 * markAlertsSent — until then this at least tells staff who is waiting.
 */
router.get('/stock-alerts', limit, staff, async () => ({
  waiting: await notify.pendingStockAlerts(),
  newsletter: await notify.newsletterStats(),
}));

export default router;
