import config from '../config.js';
import Router from '../core/router.js';
import v from '../core/validate.js';
import { sendHtml } from '../middleware/static.js';
import { formatFils } from '../core/money.js';

/**
 * Page routes.
 *
 * Each one renders a static HTML shell, but the head block is built on the
 * server so that crawlers and link-preview bots — which do not run
 * JavaScript — see a real title, description and image.
 */

const router = new Router();

const BRAND = config.store.name;
const OG_DEFAULT = `${config.assetOrigin}/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260912_110504_0316394c-37bd-432b-a1f2-ee46a461c22b.png`;

/** Organisation-level structured data, attached to the landing page. */
function organisationLd() {
  return {
    '@context': 'https://schema.org',
    '@type': 'ClothingStore',
    name: BRAND,
    description:
      'Elevated contemporary streetwear, cut and finished in Amman. Heavyweight cotton, considered fits, delivered across Jordan.',
    url: config.origin,
    image: OG_DEFAULT,
    address: { '@type': 'PostalAddress', addressLocality: 'Amman', addressCountry: 'JO' },
    currenciesAccepted: config.store.currency,
    paymentAccepted: 'Cash on delivery, Credit card',
    areaServed: { '@type': 'Country', name: 'Jordan' },
  };
}

/** Breadcrumbs help search engines show the shop → collection → item path. */
function breadcrumbLd(trail) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: trail.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: `${config.origin}${item.path}`,
    })),
  };
}

/* ------------------------------------------------------------- the hero */

router.get('/', async (ctx) =>
  sendHtml(ctx, 'index.html', 200, {
    title: `${BRAND} — Contemporary Streetwear & Wardrobe Essentials`,
    description:
      'Elevated contemporary streetwear from Amman. Heavyweight cotton, considered fits, cash on delivery and same-day Amman delivery.',
    image: OG_DEFAULT,
    path: '/',
    jsonLd: organisationLd(),
  })
);

/* -------------------------------------------------------------- the shop */

router.get('/shop', async (ctx) => {
  const collection = typeof ctx.query.collection === 'string' ? ctx.query.collection : null;

  let title = `Shop — ${BRAND}`;
  let description =
    'Heavyweight hoodies, cargo trousers, boxy tees and footwear. Free delivery on Jordan orders over 50.000 JOD.';

  if (collection && /^[a-z0-9-]{1,40}$/.test(collection)) {
    try {
      const { listCollections } = await import('../services/catalog.js');
      const found = (await listCollections()).find((c) => c.slug === collection);
      if (found) {
        title = `${found.title} — ${BRAND}`;
        if (found.subtitle) description = found.subtitle;
      }
    } catch {
      /* the default copy stands in */
    }
  }

  return sendHtml(ctx, 'shop.html', 200, {
    title,
    description,
    image: OG_DEFAULT,
    path: collection ? `/shop?collection=${collection}` : '/shop',
    jsonLd: breadcrumbLd([
      { name: 'Home', path: '/' },
      { name: 'Shop', path: '/shop' },
    ]),
  });
});

/* ----------------------------------------------------------- the product */

/**
 * The one page where server-rendered metadata really earns its keep: a
 * product link pasted into WhatsApp should show the piece, its price and
 * whether it is in stock.
 */
router.get('/product/:slug', async (ctx) => {
  let slug;
  try {
    slug = v.slug().parse(ctx.params.slug);
  } catch {
    return sendHtml(ctx, '404.html', 404);
  }

  let product = null;
  try {
    const { getProductBySlug } = await import('../services/catalog.js');
    ({ product } = await getProductBySlug(slug));
  } catch {
    return sendHtml(ctx, '404.html', 404, {
      title: `Not found — ${BRAND}`,
      path: `/product/${slug}`,
      noindex: true,
    });
  }

  const price = formatFils(product.priceFils);
  const description =
    product.description?.slice(0, 200) ||
    `${product.title} — ${product.subtitle}. ${price} ${config.store.currency}.`;

  const offers = {
    '@type': 'Offer',
    url: `${config.origin}/product/${product.slug}`,
    priceCurrency: config.store.currency,
    price,
    availability: product.inStock
      ? 'https://schema.org/InStock'
      : 'https://schema.org/OutOfStock',
    itemCondition: 'https://schema.org/NewCondition',
    seller: { '@type': 'Organization', name: BRAND },
  };

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.title,
    description,
    sku: product.variants[0]?.sku || product.slug,
    brand: { '@type': 'Brand', name: BRAND },
    image: product.images.map((i) => i.url),
    offers,
  };

  // Only published when real customers have left reviews. An aggregateRating
  // with no reviews behind it is fabricated social proof, and search engines
  // treat it as a policy violation besides.
  if (product.rating?.count > 0) {
    jsonLd.aggregateRating = {
      '@type': 'AggregateRating',
      ratingValue: product.rating.average,
      reviewCount: product.rating.count,
    };
  }

  return sendHtml(ctx, 'product.html', 200, {
    title: `${product.title} — ${BRAND}`,
    description,
    image: product.image?.url || OG_DEFAULT,
    path: `/product/${product.slug}`,
    type: 'product',
    jsonLd,
  });
});

/* ------------------------------------------------- brand & policy pages */

const CONTENT_PAGES = [
  ['/about', 'about.html', 'Our story',
    'Cut and finished in Amman. Why Uptown Jordan exists, how the pieces are made, and who makes them.'],
  ['/size-guide', 'size-guide.html', 'Size & fit guide',
    'Measurements for every piece, how our boxy cuts run, and how to measure yourself at home.'],
  ['/shipping-returns', 'shipping-returns.html', 'Delivery & returns',
    'Delivery times and costs for every governorate, cash on delivery, and our 14-day exchange policy.'],
  ['/faq', 'faq.html', 'Frequently asked questions',
    'Payment, delivery, sizing, exchanges and caring for heavyweight cotton.'],
  ['/contact', 'contact.html', 'Contact us',
    'Questions about an order, sizing or wholesale — reach us on WhatsApp or send a message.'],
  ['/privacy', 'privacy.html', 'Privacy notice',
    'What we collect, why, how long we keep it, and the rights you have over it.'],
  ['/terms', 'terms.html', 'Terms of sale',
    'The terms that apply when you buy from Uptown Jordan.'],
];

for (const [path, file, title, description] of CONTENT_PAGES) {
  router.get(path, async (ctx) =>
    sendHtml(ctx, file, 200, {
      title: `${title} — ${BRAND}`,
      description,
      image: OG_DEFAULT,
      path,
      type: 'article',
      jsonLd: breadcrumbLd([
        { name: 'Home', path: '/' },
        { name: title, path },
      ]),
    })
  );
}

/* --------------------------------------- transactional pages (noindex) */

const PRIVATE_PAGES = [
  ['/cart', 'cart.html', 'Your bag'],
  ['/checkout', 'checkout.html', 'Checkout'],
  ['/order', 'order.html', 'Your order'],
  ['/account', 'account.html', 'Your account'],
  ['/login', 'login.html', 'Sign in'],
  ['/admin', 'admin.html', 'Dashboard'],
  ['/pay/:reference', 'pay.html', 'Secure payment'],
  ['/newsletter/confirm', 'newsletter-confirm.html', 'Confirm your subscription'],
];

for (const [path, file, title] of PRIVATE_PAGES) {
  router.get(path, async (ctx) =>
    sendHtml(ctx, file, 200, {
      title: `${title} — ${BRAND}`,
      path: ctx.path,
      noindex: true,
    })
  );
}

export default router;
