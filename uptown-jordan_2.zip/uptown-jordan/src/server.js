import http from 'node:http';
import { pathToFileURL } from 'node:url';
import config from './config.js';
import logger from './core/logger.js';
import { createApp } from './app.js';
import { closeDb, sweepExpired } from './db/index.js';

/**
 * HTTP entrypoint.
 *
 * TLS is terminated by nginx in front of this process (see nginx/ and
 * DEPLOY.md). This server binds plain HTTP and is never exposed directly.
 */

const SWEEP_INTERVAL_MS = 15 * 60_000;

export async function start() {
  const router = await createApp();

  const server = http.createServer((req, res) => {
    router.handle(req, res).catch((err) => {
      logger.error('unhandled request error', { err });
      if (!res.writableEnded) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end('{"error":{"code":"server_error","message":"Something went wrong."}}');
      }
    });
  });

  // Slowloris hardening: a client cannot hold a connection open indefinitely
  // by dribbling headers one byte at a time.
  server.headersTimeout = 20_000;
  server.requestTimeout = 60_000;
  server.keepAliveTimeout = 65_000;
  server.maxHeadersCount = 64;
  server.timeout = 0;

  await new Promise((resolve) => server.listen(config.port, config.host, resolve));
  logger.info('uptown jordan listening', {
    port: config.port,
    env: config.env,
    origin: config.origin,
  });

  const sweeper = setInterval(() => {
    sweepExpired()
      .then((counts) => logger.debug('expired rows swept', counts))
      .catch((err) => logger.error('sweep failed', { err }));
  }, SWEEP_INTERVAL_MS);
  sweeper.unref();

  /* ------------------------------------------------------ graceful exit */

  let closing = false;
  const shutdown = async (signal) => {
    if (closing) return;
    closing = true;
    logger.info('shutting down', { signal });
    clearInterval(sweeper);

    // Stop accepting, let in-flight requests finish, then checkpoint the WAL
    // so the database file on disk is complete and self-contained.
    server.close(async () => {
      try {
        await closeDb();
      } catch (err) {
        logger.error('database close failed', { err });
      }
      process.exit(0);
    });

    setTimeout(() => {
      logger.warn('forcing exit after timeout');
      process.exit(1);
    }, 10_000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  process.on('unhandledRejection', (reason) => {
    logger.error('unhandled rejection', { err: reason });
  });
  process.on('uncaughtException', (err) => {
    // An uncaught exception leaves the process in an unknown state. Log it
    // and let the supervisor restart cleanly rather than limping on.
    logger.error('uncaught exception', { err });
    shutdown('uncaughtException');
  });

  return server;
}

/**
 * Run only when this file is the entry point.
 *
 * `pathToFileURL` rather than string concatenation: on Windows argv[1] is
 * `C:\\path\\to\\server.js`, and `'file://' + that` never equals
 * import.meta.url. The comparison silently failed, the process exited
 * without listening, and nothing was logged. Only correct on POSIX by
 * accident.
 */
const isEntrypoint =
  Boolean(process.argv[1]) && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isEntrypoint) {
  start().catch((err) => {
    logger.error('failed to start', { err });
    process.exit(1);
  });
}
