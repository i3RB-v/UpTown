import { createHmac, timingSafeEqual } from 'node:crypto';
import config from '../config.js';
import { randomToken, sha256, uuid } from '../core/crypto.js';
import { badRequest, forbidden, notFound } from '../core/errors.js';
import { getDb } from '../db/index.js';
import logger from '../core/logger.js';
import { markPaid, markPaymentFailed } from './orders.js';

/**
 * Payments.
 *
 * Card data never touches this server. The flow is hosted-redirect:
 *
 *    order created ──► intent created with the provider
 *                 ──► customer is redirected to the provider's page
 *                 ──► provider posts a signed webhook back here
 *                 ──► we confirm the order from the webhook, not from the
 *                     browser's return URL
 *
 * That last point matters: the browser redirect back to /order is a
 * *hint*, not proof of payment. Anyone can visit a success URL. Only a
 * signed webhook moves an order to paid, and only for the amount we
 * expect.
 *
 * Consequently no PAN, CVV or expiry is ever accepted by, logged by, or
 * stored in this system — which keeps the deployment out of the most
 * demanding parts of PCI-DSS scope.
 */

const SIGNATURE_HEADER = 'x-uj-signature';

/* ------------------------------------------------------------ signatures */

function computeSignature(timestamp, rawBody) {
  return createHmac('sha256', config.payments.webhookSecret)
    .update(`${timestamp}.${rawBody}`, 'utf8')
    .digest('hex');
}

/**
 * Verify a webhook.
 *
 * Checks, in order: header shape, timestamp freshness (defeats capture and
 * replay of an old-but-valid delivery), then a constant-time digest
 * comparison.
 */
export function verifyWebhookSignature(headers, rawBody) {
  const header = headers[SIGNATURE_HEADER];
  if (typeof header !== 'string' || header.length > 512) return false;

  const parts = Object.fromEntries(
    header.split(',').map((piece) => {
      const i = piece.indexOf('=');
      return i === -1 ? ['', ''] : [piece.slice(0, i).trim(), piece.slice(i + 1).trim()];
    })
  );

  const timestamp = Number(parts.t);
  const provided = parts.v1;
  if (!Number.isFinite(timestamp) || typeof provided !== 'string') return false;
  if (!/^[0-9a-f]{64}$/.test(provided)) return false;

  const ageMs = Math.abs(Date.now() - timestamp * 1000);
  if (ageMs > config.payments.webhookToleranceMs) return false;

  const expected = Buffer.from(computeSignature(timestamp, rawBody), 'hex');
  const actual = Buffer.from(provided, 'hex');
  if (expected.length !== actual.length) return false;
  return timingSafeEqual(expected, actual);
}

/** Sign an outgoing payload — used by the mock provider and by tests. */
export function signWebhook(rawBody, timestamp = Math.floor(Date.now() / 1000)) {
  return `t=${timestamp},v1=${computeSignature(timestamp, rawBody)}`;
}

/* --------------------------------------------------------------- intents */

/**
 * Create a payment intent for an order.
 *
 * The amount comes from the order row, never from the request, so a client
 * cannot ask to be charged less than it owes.
 */
export async function createIntent(order) {
  const db = await getDb();
  const now = Date.now();
  const reference = `pi_${randomToken(18)}`;

  db.run(
    `INSERT INTO payments (id, order_id, provider, provider_ref, status, amount_fils,
                           currency, expires_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'created', ?, ?, ?, ?, ?)`,
    uuid(), order.id, config.payments.provider, reference,
    order.totalFils, order.currency || config.store.currency,
    now + config.payments.intentTtlMs, now, now
  );

  const redirectUrl =
    config.payments.provider === 'mock'
      ? `/pay/${encodeURIComponent(reference)}`
      : // A real provider returns its own hosted-checkout URL here. Replace
        // this branch with that call; nothing else in the codebase changes.
        `/pay/${encodeURIComponent(reference)}`;

  return { reference, redirectUrl, amountFils: order.totalFils };
}

export async function getIntent(reference) {
  const db = await getDb();
  const row = db.get(
    `SELECT p.*, o.number, o.total_fils, o.currency, o.status AS order_status
       FROM payments p JOIN orders o ON o.id = p.order_id
      WHERE p.provider = ? AND p.provider_ref = ?`,
    config.payments.provider, reference
  );
  if (!row) throw notFound('That payment session could not be found.');
  return row;
}

/* -------------------------------------------------------------- webhooks */

/**
 * Apply a verified webhook event.
 *
 * Replay protection is a UNIQUE index, not a lookup-then-insert: the insert
 * either wins or it does not, so two simultaneous deliveries of the same
 * event cannot both proceed.
 */
export async function handleEvent(rawBody) {
  let event;
  try {
    event = JSON.parse(rawBody);
  } catch {
    throw badRequest('Malformed webhook payload.');
  }

  const eventId = String(event?.id || '');
  const type = String(event?.type || '');
  const reference = String(event?.data?.reference || '');
  if (!eventId || !type || !reference) throw badRequest('Incomplete webhook payload.');

  const db = await getDb();

  let firstDelivery = false;
  try {
    db.run(
      `INSERT INTO webhook_events (id, provider, event_id, event_type, payload_hash, received_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      uuid(), config.payments.provider, eventId, type, sha256(rawBody), Date.now()
    );
    firstDelivery = true;
  } catch (err) {
    if (!String(err?.message || '').includes('UNIQUE')) throw err;
  }

  if (!firstDelivery) {
    logger.info('webhook replay ignored', { eventId, type });
    return { applied: false, reason: 'duplicate' };
  }

  const payment = db.get(
    'SELECT * FROM payments WHERE provider = ? AND provider_ref = ?',
    config.payments.provider, reference
  );
  if (!payment) {
    logger.warn('webhook for unknown payment reference', { eventId });
    return { applied: false, reason: 'unknown_reference' };
  }

  const order = db.get('SELECT id, total_fils, currency FROM orders WHERE id = ?', payment.order_id);
  if (!order) return { applied: false, reason: 'unknown_order' };

  const now = Date.now();

  if (type === 'payment.succeeded') {
    // The provider must agree with us about how much was charged. A
    // mismatch is treated as fraud, not as a successful payment.
    const amount = Number(event?.data?.amountFils);
    const currency = String(event?.data?.currency || order.currency);
    if (amount !== order.total_fils || currency !== order.currency) {
      logger.error('webhook amount mismatch', {
        eventId, expected: order.total_fils, got: amount,
      });
      db.run(
        "UPDATE payments SET status = 'failed', failure_reason = ?, updated_at = ? WHERE id = ?",
        'amount_mismatch', now, payment.id
      );
      await markPaymentFailed(order.id, 'Payment amount did not match the order total.');
      return { applied: false, reason: 'amount_mismatch' };
    }

    const brand = String(event?.data?.cardBrand || '').slice(0, 24);
    const last4 = String(event?.data?.cardLast4 || '').replace(/\D/g, '').slice(-4);

    db.run(
      `UPDATE payments SET status = 'paid', card_brand = ?, card_last4 = ?, updated_at = ?
        WHERE id = ?`,
      brand, last4, now, payment.id
    );
    await markPaid(order.id, { provider: config.payments.provider, reference });
    logger.info('payment confirmed', { orderId: order.id, eventId });
    return { applied: true, orderId: order.id };
  }

  if (type === 'payment.failed' || type === 'payment.cancelled') {
    const reason = String(event?.data?.reason || 'Payment was not completed.').slice(0, 300);
    db.run(
      "UPDATE payments SET status = ?, failure_reason = ?, updated_at = ? WHERE id = ?",
      type === 'payment.failed' ? 'failed' : 'cancelled', reason, now, payment.id
    );
    await markPaymentFailed(order.id, reason);
    return { applied: true, orderId: order.id, failed: true };
  }

  logger.info('webhook type ignored', { type, eventId });
  return { applied: false, reason: 'unhandled_type' };
}

/**
 * Deliver a signed event to our own webhook endpoint.
 *
 * Only used by the bundled mock provider, so that the demonstration path is
 * the *same* code path a real provider exercises — signature verification
 * included — rather than a shortcut that skips it.
 */
export async function emitMockEvent(type, data) {
  if (config.payments.provider !== 'mock') {
    throw forbidden('The mock payment provider is not enabled.');
  }
  const body = JSON.stringify({
    id: `evt_${randomToken(12)}`,
    type,
    created: Math.floor(Date.now() / 1000),
    data,
  });
  return { body, signature: signWebhook(body) };
}

export { SIGNATURE_HEADER };
