import config from '../config.js';
import {
  fakeVerify,
  hashPassword,
  needsRehash,
  randomToken,
  sha256,
  uuid,
  verifyPassword,
} from '../core/crypto.js';
import { badRequest, conflict, forbidden, notFound, unauthorized } from '../core/errors.js';
import { getDb } from '../db/index.js';
import logger from '../core/logger.js';

/** Temporary lockout after repeated failures, so a stolen password list
 *  cannot be sprayed against one account at speed. */
const MAX_FAILED = 8;
const LOCKOUT_MS = 15 * 60_000;

const normalize = (email) => String(email || '').trim().toLowerCase();

/** A weak-password floor that does not devolve into character-class theatre:
 *  length is what actually matters, plus a block-list of the obvious. */
const COMMON = new Set([
  'password', 'password1', 'password123', '12345678', '123456789', '1234567890',
  'qwertyuiop', 'letmein123', 'iloveyou', 'admin12345', 'welcome123',
  'uptownjordan', 'streetwear', 'jordan123',
]);

export function assertPasswordAcceptable(password, { email = '' } = {}) {
  const pw = String(password || '');
  if (pw.length < config.password.minLength) {
    throw badRequest(`Choose a password of at least ${config.password.minLength} characters.`);
  }
  if (pw.length > config.password.maxLength) {
    throw badRequest('That password is too long.');
  }
  const lower = pw.toLowerCase();
  if (COMMON.has(lower)) throw badRequest('That password is too common. Please pick another.');
  if (/^(.)\1+$/.test(pw)) throw badRequest('That password is too simple.');
  const local = normalize(email).split('@')[0];
  if (local && local.length >= 4 && lower.includes(local)) {
    throw badRequest('Your password should not contain your email address.');
  }
  return true;
}

function present(row) {
  if (!row) return null;
  return {
    id: row.id,
    email: row.email,
    fullName: row.full_name,
    phone: row.phone,
    role: row.role,
    createdAt: row.created_at,
    totpEnabled: row.totp_enabled === 1,
  };
}

export async function findByEmail(email) {
  const db = await getDb();
  return db.get('SELECT * FROM users WHERE email_normalized = ?', normalize(email));
}

export async function findById(id) {
  const db = await getDb();
  return present(db.get('SELECT * FROM users WHERE id = ?', id));
}

/**
 * Create an account.
 *
 * Returns `{ created: false }` for an address that already exists instead of
 * throwing a conflict. The route responds identically either way, so this
 * endpoint cannot be used to discover which email addresses have accounts.
 */
export async function register({ email, password, fullName, phone }) {
  assertPasswordAcceptable(password, { email });

  const db = await getDb();
  const normalized = normalize(email);
  const existing = db.get('SELECT id FROM users WHERE email_normalized = ?', normalized);
  if (existing) {
    // Still spend the KDF time so the response is not measurably faster.
    await hashPassword(password);
    return { created: false, user: null };
  }

  const hash = await hashPassword(password);
  const now = Date.now();
  const id = uuid();

  try {
    db.run(
      `INSERT INTO users (id, email, email_normalized, password_hash, full_name, phone,
                          role, status, password_changed_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, 'customer', 'active', ?, ?, ?)`,
      id, String(email).trim(), normalized, hash, fullName || '', phone || '', now, now, now
    );
  } catch (err) {
    // Lost the race against a concurrent signup for the same address.
    if (String(err?.message || '').includes('UNIQUE')) return { created: false, user: null };
    throw err;
  }

  return { created: true, user: await findById(id) };
}

/**
 * Verify credentials.
 *
 * Every failure path — unknown address, wrong password, locked account —
 * returns the same error and takes comparable time.
 */
export async function authenticate({ email, password }) {
  const db = await getDb();
  const row = await findByEmail(email);
  const genericFailure = unauthorized('That email and password combination is not correct.');

  if (!row) {
    await fakeVerify();
    throw genericFailure;
  }

  const now = Date.now();
  if (row.locked_until && row.locked_until > now) {
    await fakeVerify();
    throw genericFailure;
  }
  if (row.status !== 'active') {
    await fakeVerify();
    throw forbidden('This account is not available. Please contact support.');
  }

  const ok = await verifyPassword(password, row.password_hash);

  if (!ok) {
    const failed = row.failed_logins + 1;
    db.run(
      'UPDATE users SET failed_logins = ?, locked_until = ?, updated_at = ? WHERE id = ?',
      failed,
      failed >= MAX_FAILED ? now + LOCKOUT_MS : null,
      now,
      row.id
    );
    if (failed >= MAX_FAILED) logger.warn('account temporarily locked', { userId: row.id });
    throw genericFailure;
  }

  // Opportunistically upgrade hashes that predate a cost increase.
  if (needsRehash(row.password_hash)) {
    try {
      db.run('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?',
        await hashPassword(password), now, row.id);
    } catch (err) {
      logger.error('password rehash failed', { userId: row.id, err });
    }
  }

  if (row.failed_logins !== 0 || row.locked_until) {
    db.run('UPDATE users SET failed_logins = 0, locked_until = NULL, updated_at = ? WHERE id = ?', now, row.id);
  }

  return {
    user: present(row),
    requiresTotp: row.totp_enabled === 1,
    totpSecret: row.totp_enabled === 1 ? row.totp_secret : null,
  };
}

export async function changePassword({ userId, currentPassword, newPassword }) {
  const db = await getDb();
  const row = db.get('SELECT * FROM users WHERE id = ?', userId);
  if (!row) throw notFound('Account not found.');

  if (!(await verifyPassword(currentPassword, row.password_hash))) {
    throw unauthorized('Your current password is not correct.');
  }
  assertPasswordAcceptable(newPassword, { email: row.email });
  if (await verifyPassword(newPassword, row.password_hash)) {
    throw badRequest('Choose a password you have not used here before.');
  }

  const now = Date.now();
  db.run(
    'UPDATE users SET password_hash = ?, password_changed_at = ?, updated_at = ?, failed_logins = 0, locked_until = NULL WHERE id = ?',
    await hashPassword(newPassword), now, now, userId
  );
  return true;
}

/* ------------------------------------------------------------------ *
 * Password reset                                                      *
 *                                                                     *
 * The token is single-use, 15-minute-lived, and stored only as a       *
 * digest. `requestReset` always reports success to the caller.         *
 * ------------------------------------------------------------------ */

const RESET_TTL_MS = 15 * 60_000;

export async function requestReset(email) {
  const db = await getDb();
  const row = await findByEmail(email);
  if (!row || row.status !== 'active') return { token: null };

  // One live token at a time.
  db.run('DELETE FROM password_resets WHERE user_id = ? AND used_at IS NULL', row.id);

  const token = randomToken(32);
  const now = Date.now();
  db.run(
    'INSERT INTO password_resets (id, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)',
    sha256(token), row.id, now, now + RESET_TTL_MS
  );
  return { token, email: row.email, userId: row.id };
}

export async function completeReset({ token, newPassword }) {
  const db = await getDb();
  const id = sha256(token);
  const row = db.get('SELECT * FROM password_resets WHERE id = ?', id);
  const invalid = badRequest('That reset link is invalid or has expired. Please request a new one.');

  if (!row || row.used_at || row.expires_at < Date.now()) throw invalid;

  const user = db.get('SELECT id, email, status FROM users WHERE id = ?', row.user_id);
  if (!user || user.status !== 'active') throw invalid;

  assertPasswordAcceptable(newPassword, { email: user.email });

  // Derive the hash before opening the transaction: scrypt is async and the
  // transaction helper is synchronous, so awaiting inside it would commit early.
  const hash = await hashPassword(newPassword);
  const now = Date.now();

  db.tx(() => {
    // Claiming the token and writing the password happen together, so a
    // double submission cannot apply the reset twice.
    const claimed = db.run(
      'UPDATE password_resets SET used_at = ? WHERE id = ? AND used_at IS NULL', now, id
    ).changes;
    if (!claimed) throw invalid;
    db.run(
      'UPDATE users SET password_hash = ?, password_changed_at = ?, updated_at = ?, failed_logins = 0, locked_until = NULL WHERE id = ?',
      hash, now, now, user.id
    );
    // Every existing session for this account is invalidated — a reset is
    // exactly the moment you want an attacker signed out.
    db.run('DELETE FROM sessions WHERE user_id = ?', user.id);
  });

  return { userId: user.id };
}

/* ------------------------------------------------------------------ *
 * Addresses                                                           *
 * ------------------------------------------------------------------ */

export async function listAddresses(userId) {
  const db = await getDb();
  return db.all(
    `SELECT id, label, full_name, phone, governorate, city, street, building, notes, is_default
       FROM addresses WHERE user_id = ? ORDER BY is_default DESC, created_at DESC`,
    userId
  ).map((a) => ({
    id: a.id,
    label: a.label,
    fullName: a.full_name,
    phone: a.phone,
    governorate: a.governorate,
    city: a.city,
    street: a.street,
    building: a.building,
    notes: a.notes,
    isDefault: a.is_default === 1,
  }));
}

export async function saveAddress(userId, input, addressId = null) {
  const db = await getDb();
  const now = Date.now();

  return db.tx(() => {
    if (input.isDefault) {
      db.run('UPDATE addresses SET is_default = 0 WHERE user_id = ?', userId);
    }
    if (addressId) {
      const changes = db.run(
        `UPDATE addresses SET label = ?, full_name = ?, phone = ?, governorate = ?, city = ?,
                              street = ?, building = ?, notes = ?, is_default = ?, updated_at = ?
          WHERE id = ? AND user_id = ?`,
        input.label, input.fullName, input.phone, input.governorate, input.city,
        input.street, input.building, input.notes, input.isDefault ? 1 : 0, now,
        addressId, userId
      ).changes;
      // Scoped by user_id as well as id: one customer cannot edit another's
      // address by guessing its identifier.
      if (!changes) throw notFound('Address not found.');
      return { id: addressId };
    }

    const count = db.get('SELECT COUNT(*) AS n FROM addresses WHERE user_id = ?', userId).n;
    if (count >= 12) throw conflict('You have reached the maximum number of saved addresses.');

    const id = uuid();
    db.run(
      `INSERT INTO addresses (id, user_id, label, full_name, phone, governorate, city,
                              street, building, notes, is_default, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      id, userId, input.label, input.fullName, input.phone, input.governorate, input.city,
      input.street, input.building, input.notes, input.isDefault || count === 0 ? 1 : 0, now, now
    );
    return { id };
  });
}

export async function deleteAddress(userId, addressId) {
  const db = await getDb();
  const changes = db.run('DELETE FROM addresses WHERE id = ? AND user_id = ?', addressId, userId).changes;
  if (!changes) throw notFound('Address not found.');
  return true;
}

export async function getAddress(userId, addressId) {
  const db = await getDb();
  const row = db.get('SELECT * FROM addresses WHERE id = ? AND user_id = ?', addressId, userId);
  if (!row) throw notFound('Address not found.');
  return {
    fullName: row.full_name,
    phone: row.phone,
    governorate: row.governorate,
    city: row.city,
    street: row.street,
    building: row.building,
    notes: row.notes,
  };
}

export async function updateProfile(userId, { fullName, phone }) {
  const db = await getDb();
  db.run('UPDATE users SET full_name = ?, phone = ?, updated_at = ? WHERE id = ?',
    fullName, phone, Date.now(), userId);
  return findById(userId);
}

export { present as presentUser };
