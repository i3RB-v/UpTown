import { uuid } from '../core/crypto.js';
import { conflict, forbidden, notFound } from '../core/errors.js';
import { getDb } from '../db/index.js';

/**
 * Product reviews.
 *
 * Two rules, both enforced in the database rather than the UI:
 *
 *  1. **Only people who received the product may review it.** Eligibility is
 *     a join against delivered orders, checked at write time. There is no
 *     endpoint that accepts a review from someone who has not bought.
 *  2. **Nothing publishes itself.** Every review lands as `pending` and a
 *     human moves it. The storefront only ever reads `published`.
 *
 * The store ships with zero reviews. Seeding invented ones would be writing
 * fake social proof, which is both dishonest to customers and the kind of
 * thing that gets a merchant account closed.
 */

/** Statuses that mean the customer has the product in hand. */
const RECEIVED = "('delivered')";

/**
 * Which products may this user review right now?
 *
 * Returns rows for delivered orders whose lines the user has not already
 * reviewed — which is exactly what the "review your purchases" prompt on the
 * account page needs.
 */
export async function reviewableFor(userId) {
  const db = await getDb();
  return db.all(
    `SELECT DISTINCT p.id   AS product_id,
            p.slug          AS slug,
            p.title         AS title,
            o.id            AS order_id,
            oi.variant_label AS size_bought,
            o.delivered_at  AS delivered_at,
            (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image_url
       FROM orders o
       JOIN order_items oi ON oi.order_id = o.id
       JOIN variants v     ON v.id = oi.variant_id
       JOIN products p     ON p.id = v.product_id
      WHERE o.user_id = ?
        AND o.status IN ${RECEIVED}
        AND NOT EXISTS (
              SELECT 1 FROM reviews r WHERE r.product_id = p.id AND r.user_id = ?
            )
      ORDER BY o.delivered_at DESC`,
    userId,
    userId
  );
}

/**
 * The delivered order that entitles this user to review this product, or
 * null. Returning the order (rather than a boolean) lets the review record
 * which purchase backs it.
 */
async function entitlement(userId, productId) {
  const db = await getDb();
  return db.get(
    `SELECT o.id AS order_id, oi.variant_label AS size_bought
       FROM orders o
       JOIN order_items oi ON oi.order_id = o.id
       JOIN variants v     ON v.id = oi.variant_id
      WHERE o.user_id = ?
        AND v.product_id = ?
        AND o.status IN ${RECEIVED}
      ORDER BY o.delivered_at DESC
      LIMIT 1`,
    userId,
    productId
  );
}

export async function submit({ userId, productSlug, rating, title, body, authorName }) {
  const db = await getDb();

  const product = db.get('SELECT id, title FROM products WHERE slug = ?', productSlug);
  if (!product) throw notFound('We could not find that piece.');

  const purchase = await entitlement(userId, product.id);
  if (!purchase) {
    // Deliberately explicit rather than a vague 403: the customer needs to
    // know *why*, and there is nothing sensitive about this fact.
    throw forbidden(
      'Reviews are open to customers who have received this piece. Once your order is delivered, you can leave one.'
    );
  }

  const existing = db.get(
    'SELECT id FROM reviews WHERE product_id = ? AND user_id = ?',
    product.id,
    userId
  );
  if (existing) throw conflict('You have already reviewed this piece.');

  const now = Date.now();
  const id = uuid();

  db.run(
    `INSERT INTO reviews (id, product_id, user_id, order_id, rating, title, body,
                          status, author_name, size_bought, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)`,
    id,
    product.id,
    userId,
    purchase.order_id,
    rating,
    title,
    body,
    authorName,
    purchase.size_bought || '',
    now,
    now
  );

  return { id, status: 'pending', productTitle: product.title };
}

/** Published reviews for the storefront, plus the rating summary. */
export async function forProduct(productSlug, { limit = 20, offset = 0 } = {}) {
  const db = await getDb();
  const product = db.get('SELECT id FROM products WHERE slug = ?', productSlug);
  if (!product) throw notFound('We could not find that piece.');

  const summary = db.get(
    `SELECT COUNT(*) AS count, COALESCE(AVG(rating), 0) AS average
       FROM reviews WHERE product_id = ? AND status = 'published'`,
    product.id
  );

  const spread = db.all(
    `SELECT rating, COUNT(*) AS n FROM reviews
      WHERE product_id = ? AND status = 'published' GROUP BY rating`,
    product.id
  );
  const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  for (const row of spread) distribution[row.rating] = row.n;

  const rows = db.all(
    `SELECT id, rating, title, body, author_name, size_bought, created_at
       FROM reviews
      WHERE product_id = ? AND status = 'published'
      ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    product.id,
    Math.min(limit, 50),
    Math.max(0, offset)
  );

  return {
    count: summary.count,
    // One decimal place is as much precision as a rating average deserves.
    average: summary.count ? Math.round(summary.average * 10) / 10 : 0,
    distribution,
    items: rows.map((r) => ({
      id: r.id,
      rating: r.rating,
      title: r.title,
      body: r.body,
      // First name plus an initial — enough to feel human, not enough to
      // identify a customer to a stranger.
      author: shortenName(r.author_name),
      sizeBought: r.size_bought,
      // Every review here passed the purchase check at write time.
      verifiedPurchase: true,
      createdAt: r.created_at,
    })),
  };
}

function shortenName(full) {
  const parts = String(full || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return 'Verified buyer';
  if (parts.length === 1) return parts[0];
  return `${parts[0]} ${parts[parts.length - 1][0].toUpperCase()}.`;
}

/**
 * Rating summaries for a batch of products, for the listing grid.
 * One query rather than N.
 */
export async function summariesFor(productIds) {
  if (!productIds.length) return new Map();
  const db = await getDb();
  const holes = productIds.map(() => '?').join(',');
  const rows = db.all(
    `SELECT product_id, COUNT(*) AS count, AVG(rating) AS average
       FROM reviews
      WHERE status = 'published' AND product_id IN (${holes})
      GROUP BY product_id`,
    ...productIds
  );
  return new Map(
    rows.map((r) => [r.product_id, { count: r.count, average: Math.round(r.average * 10) / 10 }])
  );
}

/* ---------------------------------------------------------------- moderation */

export async function pending({ status = 'pending', limit = 50, offset = 0 } = {}) {
  const db = await getDb();
  return db.all(
    `SELECT r.id, r.rating, r.title, r.body, r.author_name, r.size_bought,
            r.status, r.created_at, p.title AS product_title, p.slug AS product_slug,
            o.number AS order_number
       FROM reviews r
       JOIN products p ON p.id = r.product_id
       LEFT JOIN orders o ON o.id = r.order_id
      WHERE r.status = ?
      ORDER BY r.created_at DESC LIMIT ? OFFSET ?`,
    status,
    Math.min(limit, 100),
    Math.max(0, offset)
  ).map((r) => ({
    id: r.id,
    rating: r.rating,
    title: r.title,
    body: r.body,
    author: r.author_name,
    sizeBought: r.size_bought,
    status: r.status,
    productTitle: r.product_title,
    productSlug: r.product_slug,
    orderNumber: r.order_number,
    createdAt: r.created_at,
  }));
}

export async function moderate(reviewId, { action, moderator }) {
  const db = await getDb();
  const next = action === 'publish' ? 'published' : 'rejected';
  const changes = db.run(
    'UPDATE reviews SET status = ?, moderated_by = ?, moderated_at = ?, updated_at = ? WHERE id = ?',
    next,
    moderator,
    Date.now(),
    Date.now(),
    reviewId
  ).changes;
  if (!changes) throw notFound('Review not found.');
  return { status: next };
}
