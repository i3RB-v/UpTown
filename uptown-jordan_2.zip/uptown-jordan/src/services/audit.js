import { fingerprint, uuid } from '../core/crypto.js';
import { getDb } from '../db/index.js';
import logger from '../core/logger.js';

/**
 * Append-only audit trail for privileged actions.
 *
 * Nothing in this codebase updates or deletes from `audit_log`. If an admin
 * account is compromised, the record of what it did is still there.
 */
export async function record(ctx, action, { entity = '', entityId = '', detail = '' } = {}) {
  try {
    const db = await getDb();
    const actor = ctx?.state?.user ?? null;
    db.run(
      `INSERT INTO audit_log (id, actor_id, actor_email, action, entity, entity_id, detail, ip_hash, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      uuid(),
      actor?.id ?? null,
      actor?.email ?? '',
      action,
      entity,
      entityId,
      typeof detail === 'string' ? detail.slice(0, 2000) : JSON.stringify(detail).slice(0, 2000),
      ctx?.ip ? fingerprint(ctx.ip) : '',
      Date.now()
    );
  } catch (err) {
    // Auditing must never break the operation it is describing.
    logger.error('audit write failed', { action, err });
  }
}

export async function list({ limit = 100, offset = 0 } = {}) {
  const db = await getDb();
  return db.all(
    `SELECT id, actor_email, action, entity, entity_id, detail, created_at
       FROM audit_log ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    Math.min(limit, 500),
    Math.max(0, offset)
  );
}
