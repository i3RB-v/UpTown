import config from '../config.js';
import { fingerprint, orderNumber, randomToken, sha256, uuid } from '../core/crypto.js';
import { badRequest, conflict, notFound, unprocessable } from '../core/errors.js';
import { applyBps, formatFils } from '../core/money.js';
import { getDb } from '../db/index.js';
import logger from '../core/logger.js';
import { getPurchasableVariant } from './catalog.js';
import { cartIdFor, clearCart } from './cart.js';
import { findGovernorate, quote } from './shipping.js';

/**
 * Orders.
 *
 * Two invariants drive the design:
 *
 *  1. The client never supplies money. Every amount on an order is derived
 *     here from the catalogue and the shipping table. The request only says
 *     *what* and *where*.
 *  2. Stock is moved under a single transaction with a conditional UPDATE,
 *     so two customers racing for the last hoodie cannot both succeed. The
 *     loser gets a clean "just sold out" rather than an oversell.
 */

const OPEN_STATUSES = new Set(['pending', 'paid', 'processing']);

/* ------------------------------------------------------------- idempotency */

const IDEM_TTL_MS = 24 * 3600_000;

async function replayIdempotent(scope, key, requestHash) {
  if (!key) return null;
  const db = await getDb();
  const row = db.get(
    'SELECT request_hash, response, expires_at FROM idempotency_keys WHERE scope = ? AND key_hash = ?',
    scope, sha256(key)
  );
  if (!row || row.expires_at < Date.now()) return null;
  // Same key, different body: the client has a bug, and replaying the old
  // response would be wrong. Refuse loudly.
  if (row.request_hash !== requestHash) {
    throw conflict('This request was already submitted with different details.');
  }
  try {
    return JSON.parse(row.response);
  } catch {
    return null;
  }
}

async function rememberIdempotent(scope, key, requestHash, response) {
  if (!key) return;
  const db = await getDb();
  const now = Date.now();
  db.run(
    `INSERT INTO idempotency_keys (id, scope, key_hash, request_hash, response, created_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(scope, key_hash) DO NOTHING`,
    uuid(), scope, sha256(key), requestHash, JSON.stringify(response), now, now + IDEM_TTL_MS
  );
}

/* ------------------------------------------------------------------ events */

function addEvent(db, orderId, type, message, actor = 'system') {
  db.run(
    'INSERT INTO order_events (id, order_id, type, message, actor, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    uuid(), orderId, type, message, actor, Date.now()
  );
}

/* ------------------------------------------------------------------ create */

function checkoutRequestHash(input) {
  return sha256(
    JSON.stringify({
      m: input.paymentMethod,
      e: input.email,
      p: input.phone,
      s: input.shipping,
    })
  );
}

/**
 * Look for a stored response for this idempotency key.
 *
 * Called by the route *before* it inspects the cart: a successful first
 * attempt has already emptied the bag, so an empty-bag check would otherwise
 * mask the replay and turn a dropped connection into a confusing error.
 */
export async function replayCheckout(input) {
  if (!input.idempotencyKey) return null;
  const replayed = await replayIdempotent(
    'checkout',
    input.idempotencyKey,
    checkoutRequestHash(input)
  );
  return replayed ? { ...replayed, idempotentReplay: true } : null;
}

export async function createFromCart(ctx, input) {
  const db = await getDb();

  const requestHash = checkoutRequestHash(input);
  const replayed = await replayIdempotent('checkout', input.idempotencyKey, requestHash);
  if (replayed) return { ...replayed, idempotentReplay: true };

  const cartId = await cartIdFor(ctx);
  if (!cartId) throw badRequest('Your bag is empty.');

  const rows = db.all('SELECT variant_id, qty FROM cart_items WHERE cart_id = ? ORDER BY added_at', cartId);
  if (!rows.length) throw badRequest('Your bag is empty.');

  const gov = findGovernorate(input.shipping.governorate);
  if (!gov) throw unprocessable('We do not deliver to that governorate yet.');

  /* --- Price the order from the catalogue, not from the request --------- */
  const lines = [];
  let subtotalFils = 0;

  for (const row of rows) {
    const variant = await getPurchasableVariant(row.variant_id);
    if (!variant) {
      throw conflict('An item in your bag is no longer available. Please review your bag.');
    }
    const qty = Math.min(row.qty, config.cart.maxQtyPerLine);
    if (variant.available < qty) {
      throw conflict(`Only ${variant.available} left of ${variant.productTitle} (${variant.label}).`);
    }
    const lineFils = variant.unitFils * qty;
    subtotalFils += lineFils;
    lines.push({ variant, qty, lineFils });
  }

  const ship = quote({
    subtotalFils,
    governorate: gov.code,
    paymentMethod: input.paymentMethod,
  });
  const discountFils = 0;
  const taxFils = applyBps(subtotalFils - discountFils, config.store.taxRateBps);
  const totalFils = subtotalFils - discountFils + ship.shippingFils + taxFils;

  if (totalFils <= 0) throw badRequest('Your bag is empty.');
  if (totalFils > config.store.maxOrderValueFils) {
    throw unprocessable('This order is above the online limit. Please contact us to arrange it.');
  }

  /* --- Persist, reserving stock atomically ----------------------------- */
  const id = uuid();
  const number = orderNumber();
  const lookupToken = randomToken(24);
  const now = Date.now();

  const created = db.tx(() => {
    for (const { variant, qty } of lines) {
      // The WHERE clause is the lock. If another transaction took the last
      // unit first, `changes` is 0 and the whole order rolls back.
      const moved = db.run(
        'UPDATE variants SET reserved = reserved + ?, updated_at = ? WHERE id = ? AND (stock - reserved) >= ?',
        qty, now, variant.id, qty
      ).changes;
      if (!moved) {
        throw conflict(`${variant.productTitle} (${variant.label}) just sold out.`);
      }
    }

    db.run(
      `INSERT INTO orders (
         id, number, user_id, email, phone, status, payment_method, payment_status,
         subtotal_fils, discount_fils, shipping_fils, tax_fils, total_fils, currency,
         ship_full_name, ship_phone, ship_governorate, ship_city, ship_street,
         ship_building, ship_notes, lookup_token_hash, placed_ip_hash,
         created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'pending', ?, 'unpaid',
               ?, ?, ?, ?, ?, ?,
               ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      id, number, ctx.state.user?.id ?? null, input.email, input.phone,
      input.paymentMethod,
      subtotalFils, discountFils, ship.shippingFils, taxFils, totalFils, config.store.currency,
      input.shipping.fullName, input.shipping.phone, gov.code, input.shipping.city,
      input.shipping.street, input.shipping.building || '', input.shipping.notes || '',
      sha256(lookupToken), fingerprint(ctx.ip), now, now
    );

    for (const { variant, qty, lineFils } of lines) {
      db.run(
        `INSERT INTO order_items (id, order_id, variant_id, product_title, variant_label,
                                  sku, image_url, unit_fils, qty, line_fils)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        uuid(), id, variant.id, variant.productTitle, variant.label, variant.sku,
        variant.imageUrl, variant.unitFils, qty, lineFils
      );
    }

    addEvent(db, id, 'created', `Order placed (${input.paymentMethod.toUpperCase()}).`);
    return true;
  });

  if (!created) throw conflict('We could not place that order. Please try again.');

  await clearCart(ctx);

  logger.info('order created', {
    orderId: id, number, method: input.paymentMethod, totalFils, lines: lines.length,
  });

  const response = {
    order: {
      id,
      number,
      status: 'pending',
      paymentMethod: input.paymentMethod,
      paymentStatus: 'unpaid',
      totalFils,
      total: formatFils(totalFils),
      currency: config.store.currency,
    },
    // Returned once, at creation time. It is the guest's key to their own
    // order and is never retrievable again from the API.
    lookupToken,
  };

  await rememberIdempotent('checkout', input.idempotencyKey, requestHash, response);
  return response;
}

/* -------------------------------------------------------------- transitions */

/** Confirm payment. Idempotent: calling it twice is harmless. */
export async function markPaid(orderId, { provider = '', reference = '' } = {}) {
  const db = await getDb();
  return db.tx(() => {
    const order = db.get('SELECT id, status, payment_status FROM orders WHERE id = ?', orderId);
    if (!order) throw notFound('Order not found.');
    if (order.payment_status === 'paid') return { changed: false };
    if (order.status === 'cancelled' || order.status === 'refunded') {
      throw conflict('That order is closed.');
    }

    const now = Date.now();
    db.run(
      `UPDATE orders SET payment_status = 'paid', status = 'paid', paid_at = ?, updated_at = ?
        WHERE id = ? AND payment_status <> 'paid'`,
      now, now, orderId
    );
    addEvent(db, orderId, 'paid', `Payment confirmed${provider ? ` via ${provider}` : ''}.`, reference || 'system');
    return { changed: true };
  });
}

export async function markPaymentFailed(orderId, reason = '') {
  const db = await getDb();
  return db.tx(() => {
    const order = db.get('SELECT id, payment_status FROM orders WHERE id = ?', orderId);
    if (!order || order.payment_status === 'paid') return { changed: false };
    const now = Date.now();
    db.run("UPDATE orders SET payment_status = 'failed', updated_at = ? WHERE id = ?", now, orderId);
    addEvent(db, orderId, 'payment_failed', reason.slice(0, 500) || 'Payment was not completed.');
    return { changed: true };
  });
}

/**
 * Cancel an order and give the reserved units back to available stock.
 * The reservation release is conditional on the order not already being
 * cancelled, so a double-cancel cannot inflate inventory.
 */
export async function cancel(orderId, { reason = '', actor = 'system' } = {}) {
  const db = await getDb();
  return db.tx(() => {
    const order = db.get('SELECT id, status FROM orders WHERE id = ?', orderId);
    if (!order) throw notFound('Order not found.');
    if (order.status === 'cancelled') return { changed: false };
    if (order.status === 'shipped' || order.status === 'delivered') {
      throw conflict('That order has already shipped.');
    }

    const now = Date.now();
    const items = db.all('SELECT variant_id, qty FROM order_items WHERE order_id = ?', orderId);
    for (const item of items) {
      if (!item.variant_id) continue;
      db.run(
        'UPDATE variants SET reserved = MAX(0, reserved - ?), updated_at = ? WHERE id = ?',
        item.qty, now, item.variant_id
      );
    }

    db.run(
      "UPDATE orders SET status = 'cancelled', cancelled_reason = ?, updated_at = ? WHERE id = ?",
      reason.slice(0, 500), now, orderId
    );
    addEvent(db, orderId, 'cancelled', reason.slice(0, 500) || 'Order cancelled.', actor);
    return { changed: true };
  });
}

/** Ship an order: reserved units leave the building, so both counters drop. */
export async function markShipped(orderId, { actor = 'system' } = {}) {
  const db = await getDb();
  return db.tx(() => {
    const order = db.get('SELECT id, status FROM orders WHERE id = ?', orderId);
    if (!order) throw notFound('Order not found.');
    if (order.status === 'shipped' || order.status === 'delivered') return { changed: false };
    if (order.status === 'cancelled') throw conflict('That order was cancelled.');

    const now = Date.now();
    for (const item of db.all('SELECT variant_id, qty FROM order_items WHERE order_id = ?', orderId)) {
      if (!item.variant_id) continue;
      db.run(
        `UPDATE variants
            SET stock = MAX(0, stock - ?), reserved = MAX(0, reserved - ?), updated_at = ?
          WHERE id = ?`,
        item.qty, item.qty, now, item.variant_id
      );
    }
    db.run("UPDATE orders SET status = 'shipped', shipped_at = ?, updated_at = ? WHERE id = ?", now, now, orderId);
    addEvent(db, orderId, 'shipped', 'Order handed to courier.', actor);
    return { changed: true };
  });
}

export async function markDelivered(orderId, { actor = 'system' } = {}) {
  const db = await getDb();
  return db.tx(() => {
    const order = db.get('SELECT id, status, payment_method, payment_status FROM orders WHERE id = ?', orderId);
    if (!order) throw notFound('Order not found.');
    if (order.status === 'delivered') return { changed: false };

    const now = Date.now();
    // Cash on delivery settles at the door.
    const paid = order.payment_method === 'cod' ? 'paid' : order.payment_status;
    db.run(
      `UPDATE orders SET status = 'delivered', payment_status = ?, delivered_at = ?,
                         paid_at = COALESCE(paid_at, ?), updated_at = ? WHERE id = ?`,
      paid, now, order.payment_method === 'cod' ? now : null, now, orderId
    );
    addEvent(db, orderId, 'delivered', 'Delivered to customer.', actor);
    return { changed: true };
  });
}

/* ------------------------------------------------------------------- reads */

function presentOrder(row, items = [], events = []) {
  return {
    id: row.id,
    number: row.number,
    status: row.status,
    paymentMethod: row.payment_method,
    paymentStatus: row.payment_status,
    currency: row.currency,
    subtotalFils: row.subtotal_fils,
    subtotal: formatFils(row.subtotal_fils),
    discountFils: row.discount_fils,
    shippingFils: row.shipping_fils,
    shipping: row.shipping_fils === 0 ? 'Free' : formatFils(row.shipping_fils),
    taxFils: row.tax_fils,
    tax: formatFils(row.tax_fils),
    totalFils: row.total_fils,
    total: formatFils(row.total_fils),
    placedAt: row.created_at,
    paidAt: row.paid_at,
    shippedAt: row.shipped_at,
    deliveredAt: row.delivered_at,
    address: {
      fullName: row.ship_full_name,
      phone: row.ship_phone,
      // The code is what is stored; the display name is resolved at read
      // time so renaming a governorate never rewrites historical orders.
      governorate: findGovernorate(row.ship_governorate)?.name || row.ship_governorate,
      governorateCode: row.ship_governorate,
      city: row.ship_city,
      street: row.ship_street,
      building: row.ship_building,
      notes: row.ship_notes,
    },
    items: items.map((i) => ({
      productTitle: i.product_title,
      variantLabel: i.variant_label,
      sku: i.sku,
      imageUrl: i.image_url,
      unitFils: i.unit_fils,
      unit: formatFils(i.unit_fils),
      qty: i.qty,
      lineFils: i.line_fils,
      line: formatFils(i.line_fils),
    })),
    timeline: events.map((e) => ({ type: e.type, message: e.message, at: e.created_at })),
  };
}

async function loadOrder(where, ...params) {
  const db = await getDb();
  const row = db.get(`SELECT * FROM orders WHERE ${where}`, ...params);
  if (!row) return null;
  const items = db.all('SELECT * FROM order_items WHERE order_id = ?', row.id);
  const events = db.all(
    'SELECT type, message, created_at FROM order_events WHERE order_id = ? ORDER BY created_at',
    row.id
  );
  return { row, presented: presentOrder(row, items, events) };
}

/**
 * Guest order lookup: order number AND the secret token issued at checkout.
 * Both are required, and the token is compared as a digest, so the order
 * number alone — which appears in emails and on receipts — is not enough.
 */
export async function lookup(number, token) {
  const found = await loadOrder('number = ?', String(number).trim().toUpperCase());
  if (!found) throw notFound('We could not find that order.');
  if (found.row.lookup_token_hash !== sha256(token)) throw notFound('We could not find that order.');
  return found.presented;
}

export async function getForUser(userId, orderId) {
  const found = await loadOrder('id = ? AND user_id = ?', orderId, userId);
  if (!found) throw notFound('We could not find that order.');
  return found.presented;
}

export async function listForUser(userId, { limit = 20, offset = 0 } = {}) {
  const db = await getDb();
  const rows = db.all(
    `SELECT id, number, status, payment_status, payment_method, total_fils, currency, created_at
       FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    userId, Math.min(limit, 50), Math.max(0, offset)
  );
  return rows.map((r) => ({
    id: r.id,
    number: r.number,
    status: r.status,
    paymentStatus: r.payment_status,
    paymentMethod: r.payment_method,
    totalFils: r.total_fils,
    total: formatFils(r.total_fils),
    placedAt: r.created_at,
  }));
}

export async function adminList({ status, search, limit = 30, offset = 0 } = {}) {
  const db = await getDb();
  const where = [];
  const params = [];
  if (status) {
    where.push('status = ?');
    params.push(status);
  }
  if (search) {
    const needle = `%${String(search).replace(/[\\%_]/g, (m) => `\\${m}`)}%`;
    where.push("(number LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\' OR ship_full_name LIKE ? ESCAPE '\\')");
    params.push(needle, needle, needle);
  }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const total = db.get(`SELECT COUNT(*) AS n FROM orders ${clause}`, ...params).n;
  const rows = db.all(
    `SELECT id, number, email, ship_full_name, ship_governorate, status, payment_status,
            payment_method, total_fils, created_at
       FROM orders ${clause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    ...params, Math.min(limit, 100), Math.max(0, offset)
  );

  return {
    total,
    items: rows.map((r) => ({
      id: r.id,
      number: r.number,
      email: r.email,
      customer: r.ship_full_name,
      governorate: r.ship_governorate,
      status: r.status,
      paymentStatus: r.payment_status,
      paymentMethod: r.payment_method,
      totalFils: r.total_fils,
      total: formatFils(r.total_fils),
      placedAt: r.created_at,
    })),
  };
}

export async function adminGet(orderId) {
  const found = await loadOrder('id = ?', orderId);
  if (!found) throw notFound('Order not found.');
  return found.presented;
}

export async function stats() {
  const db = await getDb();
  const since = Date.now() - 30 * 86_400_000;
  const revenue = db.get(
    `SELECT COALESCE(SUM(total_fils), 0) AS total, COUNT(*) AS orders
       FROM orders WHERE created_at >= ? AND status NOT IN ('cancelled','refunded')`,
    since
  );
  const open = db.get(
    `SELECT COUNT(*) AS n FROM orders WHERE status IN ('pending','paid','processing')`
  ).n;
  const lowStock = db.all(
    `SELECT v.sku, v.size, p.title, (v.stock - v.reserved) AS available
       FROM variants v JOIN products p ON p.id = v.product_id
      WHERE v.is_active = 1 AND (v.stock - v.reserved) <= 3
      ORDER BY available ASC LIMIT 12`
  );
  const byDay = db.all(
    `SELECT (created_at / 86400000) AS day, COUNT(*) AS orders, COALESCE(SUM(total_fils),0) AS revenue
       FROM orders WHERE created_at >= ? AND status NOT IN ('cancelled','refunded')
      GROUP BY day ORDER BY day`,
    since
  );

  return {
    windowDays: 30,
    revenueFils: revenue.total,
    revenue: formatFils(revenue.total),
    orderCount: revenue.orders,
    openOrders: open,
    lowStock: lowStock.map((r) => ({ sku: r.sku, title: r.title, size: r.size, available: r.available })),
    series: byDay.map((r) => ({
      date: new Date(r.day * 86_400_000).toISOString().slice(0, 10),
      orders: r.orders,
      revenueFils: r.revenue,
    })),
  };
}

export { OPEN_STATUSES, presentOrder };
