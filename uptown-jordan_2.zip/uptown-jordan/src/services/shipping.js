import config from '../config.js';

/**
 * Jordan shipping rules.
 *
 * Rates live here, server-side, and are recomputed on every quote. The
 * client never sends a shipping amount — it only names a governorate, which
 * is validated against this table.
 */
export const GOVERNORATES = [
  { code: 'amman',    name: 'Amman',    feeFils: 2_500, sameDay: true,  etaDays: [0, 1] },
  { code: 'zarqa',    name: 'Zarqa',    feeFils: 3_000, sameDay: false, etaDays: [1, 2] },
  { code: 'irbid',    name: 'Irbid',    feeFils: 3_500, sameDay: false, etaDays: [1, 3] },
  { code: 'balqa',    name: 'Balqa',    feeFils: 3_000, sameDay: false, etaDays: [1, 2] },
  { code: 'madaba',   name: 'Madaba',   feeFils: 3_000, sameDay: false, etaDays: [1, 2] },
  { code: 'mafraq',   name: 'Mafraq',   feeFils: 4_000, sameDay: false, etaDays: [2, 4] },
  { code: 'jerash',   name: 'Jerash',   feeFils: 3_500, sameDay: false, etaDays: [1, 3] },
  { code: 'ajloun',   name: 'Ajloun',   feeFils: 3_500, sameDay: false, etaDays: [1, 3] },
  { code: 'karak',    name: 'Karak',    feeFils: 4_000, sameDay: false, etaDays: [2, 4] },
  { code: 'tafilah',  name: 'Tafilah',  feeFils: 4_500, sameDay: false, etaDays: [2, 4] },
  { code: 'maan',     name: "Ma'an",    feeFils: 4_500, sameDay: false, etaDays: [2, 5] },
  { code: 'aqaba',    name: 'Aqaba',    feeFils: 5_000, sameDay: false, etaDays: [2, 5] },
];

const BY_CODE = new Map(GOVERNORATES.map((g) => [g.code, g]));

export const governorateCodes = () => GOVERNORATES.map((g) => g.code);

export const findGovernorate = (code) => BY_CODE.get(String(code || '').toLowerCase()) || null;

/**
 * Shipping for a given subtotal + destination.
 * Free over the threshold — the same threshold the storefront advertises,
 * read from one place so the banner and the invoice cannot disagree.
 */
export function quote({ subtotalFils, governorate, paymentMethod }) {
  const gov = findGovernorate(governorate);
  const base = gov ? gov.feeFils : config.store.defaultShippingFils;
  const free = subtotalFils >= config.store.freeShippingThreshold;
  const surcharge = paymentMethod === 'cod' ? config.store.codSurchargeFils : 0;

  return {
    governorate: gov?.code ?? null,
    governorateName: gov?.name ?? '',
    shippingFils: free ? surcharge : base + surcharge,
    freeShippingApplied: free,
    freeShippingThresholdFils: config.store.freeShippingThreshold,
    etaDays: gov?.etaDays ?? [2, 5],
    sameDayEligible: Boolean(gov?.sameDay),
  };
}
