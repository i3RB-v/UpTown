import { formatFils } from '../core/money.js';
import { notFound } from '../core/errors.js';
import { getDb } from '../db/index.js';
import { summariesFor } from './reviews.js';

/**
 * Catalogue reads.
 *
 * Every function here returns a *presentation* shape built field by field —
 * database rows are never spread wholesale into an API response. That is
 * what keeps internal columns (reserved stock, sort keys, draft status) from
 * leaking into the storefront just because someone added a column later.
 */

const PUBLIC_STATUS = 'active';

function variantPrice(product, variant) {
  return variant.price_fils ?? product.price_fils;
}

function presentVariant(product, variant, { admin = false } = {}) {
  const price = variantPrice(product, variant);
  const available = Math.max(0, variant.stock - variant.reserved);
  return {
    id: variant.id,
    sku: variant.sku,
    size: variant.size,
    colour: variant.colour,
    priceFils: price,
    price: formatFils(price),
    // The exact count is not published — it is competitive information and
    // an inventory oracle. Only the buying-relevant facts are exposed.
    inStock: available > 0,
    lowStock: available > 0 && available <= 3,
    maxQty: Math.min(available, 10),
    // Real inventory figures are for staff only — see the note above.
    ...(admin ? { stock: variant.stock, reserved: variant.reserved, available } : {}),
  };
}

function presentProduct(product, { images = [], variants = [], admin = false, rating = null } = {}) {
  const prices = variants.length
    ? variants.map((v) => variantPrice(product, v))
    : [product.price_fils];
  const minPrice = Math.min(...prices);

  return {
    id: product.id,
    slug: product.slug,
    title: product.title,
    subtitle: product.subtitle,
    description: product.description,
    material: product.material,
    care: product.care,
    badge: product.badge,
    collection: product.collection_slug
      ? { slug: product.collection_slug, title: product.collection_title }
      : null,
    priceFils: minPrice,
    price: formatFils(minPrice),
    compareAtFils: product.compare_at_fils ?? null,
    compareAt: product.compare_at_fils ? formatFils(product.compare_at_fils) : null,
    discountPercent:
      product.compare_at_fils && product.compare_at_fils > minPrice
        ? Math.round(((product.compare_at_fils - minPrice) / product.compare_at_fils) * 100)
        : 0,
    isFeatured: product.is_featured === 1,
    images: images.map((i) => ({ url: i.url, alt: i.alt })),
    image: images[0] ? { url: images[0].url, alt: images[0].alt } : null,
    variants: variants.map((v) => presentVariant(product, v, { admin })),
    inStock: variants.some((v) => v.stock - v.reserved > 0),
    // Absent until a real customer leaves one. The storefront renders
    // "no reviews yet" rather than a fabricated score.
    rating: rating ?? null,
    ...(admin ? { status: product.status } : {}),
  };
}

const PRODUCT_COLUMNS = `
  p.id, p.slug, p.title, p.subtitle, p.description, p.material, p.care,
  p.price_fils, p.compare_at_fils, p.badge, p.is_featured, p.status,
  c.slug AS collection_slug, c.title AS collection_title`;

export async function listCollections() {
  const db = await getDb();
  const rows = db.all(
    `SELECT id, slug, title, subtitle FROM collections
      WHERE is_active = 1 ORDER BY sort_order, title`
  );
  return rows.map((r) => ({ slug: r.slug, title: r.title, subtitle: r.subtitle }));
}

/**
 * Product listing.
 *
 * `sort` is mapped through a fixed table rather than interpolated — a client
 * cannot inject SQL through an ORDER BY clause, which is the one place people
 * commonly forget that parameter binding does not apply.
 */
const SORTS = {
  featured: 'p.is_featured DESC, p.sort_order, p.created_at DESC',
  newest: 'p.created_at DESC',
  price_asc: 'p.price_fils ASC',
  price_desc: 'p.price_fils DESC',
  name: 'p.title ASC',
};

export async function listProducts({
  collection,
  search,
  sort = 'featured',
  limit = 24,
  offset = 0,
  featuredOnly = false,
  includeDrafts = false,
} = {}) {
  const db = await getDb();

  const where = [];
  const params = [];

  if (!includeDrafts) {
    where.push('p.status = ?');
    params.push(PUBLIC_STATUS);
  }
  if (collection) {
    where.push('c.slug = ?');
    params.push(collection);
  }
  if (featuredOnly) where.push('p.is_featured = 1');
  if (search) {
    // LIKE with bound parameters. The wildcards are added to the *value*,
    // and % / _ inside the user's text are escaped so a search for "50%"
    // cannot turn into a full-table wildcard scan.
    const needle = `%${String(search).replace(/[\\%_]/g, (m) => `\\${m}`)}%`;
    where.push("(p.title LIKE ? ESCAPE '\\' OR p.subtitle LIKE ? ESCAPE '\\' OR p.description LIKE ? ESCAPE '\\')");
    params.push(needle, needle, needle);
  }

  const orderBy = SORTS[sort] || SORTS.featured;
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const total = db.get(
    `SELECT COUNT(*) AS n FROM products p
       LEFT JOIN collections c ON c.id = p.collection_id ${clause}`,
    ...params
  ).n;

  const rows = db.all(
    `SELECT ${PRODUCT_COLUMNS} FROM products p
       LEFT JOIN collections c ON c.id = p.collection_id
       ${clause}
       ORDER BY ${orderBy}
       LIMIT ? OFFSET ?`,
    ...params,
    Math.min(Math.max(1, limit), 60),
    Math.max(0, offset)
  );

  if (!rows.length) return { items: [], total, limit, offset };

  const ids = rows.map((r) => r.id);
  const holes = ids.map(() => '?').join(',');

  const images = db.all(
    `SELECT product_id, url, alt FROM product_images
      WHERE product_id IN (${holes}) ORDER BY product_id, sort_order`,
    ...ids
  );
  const variants = db.all(
    `SELECT id, product_id, sku, size, colour, price_fils, stock, reserved
       FROM variants WHERE product_id IN (${holes}) AND is_active = 1
      ORDER BY product_id, sort_order`,
    ...ids
  );

  const imagesBy = new Map();
  for (const img of images) {
    if (!imagesBy.has(img.product_id)) imagesBy.set(img.product_id, []);
    imagesBy.get(img.product_id).push(img);
  }
  const variantsBy = new Map();
  for (const v of variants) {
    if (!variantsBy.has(v.product_id)) variantsBy.set(v.product_id, []);
    variantsBy.get(v.product_id).push(v);
  }

  const ratings = await summariesFor(ids);

  return {
    items: rows.map((row) =>
      presentProduct(row, {
        images: imagesBy.get(row.id) || [],
        variants: variantsBy.get(row.id) || [],
        admin: includeDrafts,
        rating: ratings.get(row.id) || null,
      })
    ),
    total,
    limit,
    offset,
  };
}

export async function getProductBySlug(slug, { includeDrafts = false } = {}) {
  const db = await getDb();

  const product = db.get(
    `SELECT ${PRODUCT_COLUMNS} FROM products p
       LEFT JOIN collections c ON c.id = p.collection_id
      WHERE p.slug = ?${includeDrafts ? '' : ' AND p.status = ?'}`,
    ...(includeDrafts ? [slug] : [slug, PUBLIC_STATUS])
  );
  if (!product) throw notFound('We could not find that piece.');

  const images = db.all(
    'SELECT url, alt FROM product_images WHERE product_id = ? ORDER BY sort_order',
    product.id
  );
  const variants = db.all(
    `SELECT id, sku, size, colour, price_fils, stock, reserved
       FROM variants WHERE product_id = ? AND is_active = 1 ORDER BY sort_order`,
    product.id
  );

  const ratings = await summariesFor([product.id]);
  const presented = presentProduct(product, {
    images,
    variants,
    rating: ratings.get(product.id) || null,
  });

  const related = db.all(
    `SELECT ${PRODUCT_COLUMNS} FROM products p
       LEFT JOIN collections c ON c.id = p.collection_id
      WHERE p.status = ? AND p.id <> ?
      ORDER BY (p.collection_id IS NOT NULL AND p.collection_id = (
                 SELECT collection_id FROM products WHERE id = ?)) DESC,
               p.is_featured DESC, p.created_at DESC
      LIMIT 4`,
    PUBLIC_STATUS,
    product.id,
    product.id
  );

  const relatedIds = related.map((r) => r.id);
  let relatedImages = [];
  if (relatedIds.length) {
    relatedImages = db.all(
      `SELECT product_id, url, alt FROM product_images
        WHERE product_id IN (${relatedIds.map(() => '?').join(',')})
        ORDER BY product_id, sort_order`,
      ...relatedIds
    );
  }
  const relImgBy = new Map();
  for (const img of relatedImages) {
    if (!relImgBy.has(img.product_id)) relImgBy.set(img.product_id, []);
    relImgBy.get(img.product_id).push(img);
  }

  return {
    product: presented,
    related: related.map((r) => presentProduct(r, { images: relImgBy.get(r.id) || [] })),
  };
}

/** Variant + its product, resolved for cart and checkout. Returns null for
 *  anything not currently purchasable. */
export async function getPurchasableVariant(variantId) {
  const db = await getDb();
  const row = db.get(
    `SELECT v.id, v.sku, v.size, v.colour, v.price_fils AS variant_price,
            v.stock, v.reserved, v.is_active,
            p.id AS product_id, p.title, p.slug, p.price_fils AS product_price, p.status
       FROM variants v
       JOIN products p ON p.id = v.product_id
      WHERE v.id = ?`,
    variantId
  );
  if (!row || row.is_active !== 1 || row.status !== PUBLIC_STATUS) return null;

  const image = db.get(
    'SELECT url FROM product_images WHERE product_id = ? ORDER BY sort_order LIMIT 1',
    row.product_id
  );

  return {
    id: row.id,
    sku: row.sku,
    productId: row.product_id,
    productTitle: row.title,
    productSlug: row.slug,
    label: [row.size, row.colour].filter(Boolean).join(' · '),
    unitFils: row.variant_price ?? row.product_price,
    available: Math.max(0, row.stock - row.reserved),
    imageUrl: image?.url || '',
  };
}

export { presentProduct };
