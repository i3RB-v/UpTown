import config from '../config.js';
import { randomToken, sha256, uuid } from '../core/crypto.js';
import { badRequest, notFound } from '../core/errors.js';
import logger from '../core/logger.js';
import { getDb } from '../db/index.js';

/**
 * Newsletter, back-in-stock alerts and contact enquiries.
 *
 * None of these send mail — no provider is wired in. They capture intent
 * durably and correctly so that connecting a provider later is one function,
 * and nothing collected in the meantime is lost.
 *
 * Every endpoint here is unauthenticated and therefore a spam target, so all
 * three are rate limited at the route, and none of them reveal whether an
 * address is already on file.
 */

/* ---------------------------------------------------------------- newsletter */

/**
 * Subscribe, with double opt-in.
 *
 * Nobody becomes mailable from a form post alone — that is how you end up
 * sending to addresses their owner never entered. The row is created
 * unconfirmed with a hashed token; `confirm` is what makes it live.
 *
 * The response is identical whether the address is new, already pending or
 * already subscribed, so the form cannot be used to test whether someone is
 * on the list.
 */
export async function subscribe(email, { source = 'footer' } = {}) {
  const db = await getDb();
  const hash = sha256(email);
  const now = Date.now();
  const token = randomToken(24);

  const existing = db.get(
    'SELECT id, confirmed_at, unsubscribed_at FROM newsletter WHERE email_hash = ?',
    hash
  );

  if (existing) {
    if (existing.confirmed_at && !existing.unsubscribed_at) {
      // Already subscribed. Nothing to do, and nothing to disclose.
      return { created: false, token: null };
    }
    // Pending, or previously unsubscribed and coming back. Re-issue.
    db.run(
      'UPDATE newsletter SET confirm_token_hash = ?, unsubscribed_at = NULL, source = ? WHERE id = ?',
      sha256(token),
      source,
      existing.id
    );
    return { created: false, token };
  }

  db.run(
    `INSERT INTO newsletter (id, email_hash, email, confirm_token_hash, source, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    uuid(),
    hash,
    email,
    sha256(token),
    source,
    now
  );

  logger.info('newsletter signup pending confirmation', { source });
  return { created: true, token };
}

export async function confirm(token) {
  const db = await getDb();
  const row = db.get(
    'SELECT id, confirmed_at FROM newsletter WHERE confirm_token_hash = ?',
    sha256(token)
  );
  if (!row) throw badRequest('That confirmation link is not valid or has already been used.');
  if (row.confirmed_at) return { alreadyConfirmed: true };

  db.run(
    'UPDATE newsletter SET confirmed_at = ?, confirm_token_hash = NULL WHERE id = ?',
    Date.now(),
    row.id
  );
  return { alreadyConfirmed: false };
}

/** One-click unsubscribe. Keeps the row so the address is not re-added silently. */
export async function unsubscribe(email) {
  const db = await getDb();
  db.run(
    'UPDATE newsletter SET unsubscribed_at = ?, confirm_token_hash = NULL WHERE email_hash = ?',
    Date.now(),
    sha256(email)
  );
  return { ok: true };
}

/* ------------------------------------------------------------- stock alerts */

/** "Tell me when my size is back." */
export async function watchVariant(variantId, email) {
  const db = await getDb();

  const variant = db.get(
    `SELECT v.id, v.size, v.stock, v.reserved, p.title, p.slug
       FROM variants v JOIN products p ON p.id = v.product_id
      WHERE v.id = ? AND v.is_active = 1 AND p.status = 'active'`,
    variantId
  );
  if (!variant) throw notFound('That size is no longer listed.');

  if (variant.stock - variant.reserved > 0) {
    return { inStock: true, product: variant.title, size: variant.size, slug: variant.slug };
  }

  db.run(
    `INSERT INTO stock_alerts (id, variant_id, email, email_hash, created_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(variant_id, email_hash) DO NOTHING`,
    uuid(),
    variantId,
    email,
    sha256(email),
    Date.now()
  );

  return { inStock: false, product: variant.title, size: variant.size, slug: variant.slug };
}

/**
 * Everyone waiting on sizes that are now back.
 *
 * Nothing calls this on a schedule yet, because there is no mail transport.
 * Once one exists, run it after restocks: send to each row, then mark
 * `notified_at`. Written as a read so it is safe to call and inspect now.
 */
export async function pendingStockAlerts({ limit = 200 } = {}) {
  const db = await getDb();
  return db.all(
    `SELECT sa.id, sa.email, sa.created_at, v.size, p.title, p.slug
       FROM stock_alerts sa
       JOIN variants v ON v.id = sa.variant_id
       JOIN products p ON p.id = v.product_id
      WHERE sa.notified_at IS NULL
        AND (v.stock - v.reserved) > 0
        AND v.is_active = 1
        AND p.status = 'active'
      ORDER BY sa.created_at LIMIT ?`,
    Math.min(limit, 500)
  );
}

export async function markAlertsSent(ids) {
  if (!ids.length) return 0;
  const db = await getDb();
  const holes = ids.map(() => '?').join(',');
  return db.run(
    `UPDATE stock_alerts SET notified_at = ? WHERE id IN (${holes})`,
    Date.now(),
    ...ids
  ).changes;
}

/* ---------------------------------------------------------------- enquiries */

export async function recordEnquiry({ name, email, phone, topic, orderNumber, message, ipHash }) {
  const db = await getDb();
  const id = uuid();
  db.run(
    `INSERT INTO enquiries (id, name, email, phone, topic, order_number, message, ip_hash, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    name,
    email,
    phone || '',
    topic,
    orderNumber || '',
    message,
    ipHash || '',
    Date.now()
  );
  logger.info('enquiry received', { topic });
  return { id };
}

export async function listEnquiries({ status = 'open', limit = 50, offset = 0 } = {}) {
  const db = await getDb();
  return db.all(
    `SELECT id, name, email, phone, topic, order_number, message, status, created_at
       FROM enquiries WHERE status = ? ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    status,
    Math.min(limit, 100),
    Math.max(0, offset)
  );
}

export async function closeEnquiry(id, status) {
  const db = await getDb();
  const changes = db.run('UPDATE enquiries SET status = ? WHERE id = ?', status, id).changes;
  if (!changes) throw notFound('Enquiry not found.');
  return { status };
}

/** Subscriber counts for the dashboard. */
export async function newsletterStats() {
  const db = await getDb();
  const row = db.get(
    `SELECT
       COUNT(*) AS total,
       SUM(CASE WHEN confirmed_at IS NOT NULL AND unsubscribed_at IS NULL THEN 1 ELSE 0 END) AS confirmed,
       SUM(CASE WHEN confirmed_at IS NULL AND unsubscribed_at IS NULL THEN 1 ELSE 0 END) AS pending
     FROM newsletter`
  );
  return {
    total: row.total || 0,
    confirmed: row.confirmed || 0,
    pending: row.pending || 0,
  };
}

export const confirmUrl = (token) =>
  `${config.origin}/newsletter/confirm?token=${encodeURIComponent(token)}`;
