import config from '../config.js';
import { randomToken, sha256, uuid } from '../core/crypto.js';
import { badRequest, conflict, notFound } from '../core/errors.js';
import { setCookie } from '../core/http.js';
import { applyBps, formatFils } from '../core/money.js';
import { getDb } from '../db/index.js';
import { getPurchasableVariant } from './catalog.js';
import { quote } from './shipping.js';

/**
 * The cart lives on the server.
 *
 * This is the single most important decision in the commerce layer. The
 * client can only ever say "variant X, quantity N". Prices, discounts,
 * shipping and totals are recomputed from the catalogue on every read and
 * again at checkout, so there is no request a tampered client can send that
 * results in being charged an amount it chose.
 *
 * The cookie holds an opaque token; the table is keyed by its SHA-256.
 */

const COOKIE = config.cart.cookie;

async function insertCart(ctx, userId) {
  const db = await getDb();
  const token = randomToken(32);
  const now = Date.now();
  db.run(
    'INSERT INTO carts (id, user_id, created_at, updated_at, expires_at) VALUES (?, ?, ?, ?, ?)',
    sha256(token),
    userId ?? null,
    now,
    now,
    now + config.cart.ttlMs
  );
  setCookie(ctx.res, COOKIE, token, {
    httpOnly: true,
    sameSite: 'Lax',
    maxAgeMs: config.cart.ttlMs,
  });
  ctx.cookies[COOKIE] = token;
  return sha256(token);
}

/** Find this client's cart, optionally creating one. */
export async function resolveCart(ctx, { create = false } = {}) {
  const db = await getDb();
  const raw = ctx.cookies?.[COOKIE];
  const userId = ctx.state.user?.id ?? null;

  if (raw) {
    const id = sha256(raw);
    const row = db.get('SELECT id, user_id, expires_at FROM carts WHERE id = ?', id);
    if (row && row.expires_at > Date.now()) {
      // Claim a guest cart for the account that just signed in.
      if (userId && row.user_id !== userId) {
        db.run('UPDATE carts SET user_id = ?, updated_at = ? WHERE id = ?', userId, Date.now(), id);
      }
      return id;
    }
  }

  if (!create) return null;
  return insertCart(ctx, userId);
}

function touch(db, cartId) {
  db.run('UPDATE carts SET updated_at = ?, expires_at = ? WHERE id = ?',
    Date.now(), Date.now() + config.cart.ttlMs, cartId);
}

/**
 * Read a cart with live pricing.
 *
 * Lines whose variant has been archived or sold out are surfaced as
 * `unavailable` rather than silently dropped, so the customer is told what
 * changed instead of finding their basket quietly different.
 */
export async function getCart(ctx, { governorate, paymentMethod = 'cod' } = {}) {
  const db = await getDb();
  const cartId = await resolveCart(ctx);

  const empty = {
    lines: [],
    count: 0,
    subtotalFils: 0,
    subtotal: formatFils(0),
    discountFils: 0,
    shippingFils: 0,
    taxFils: 0,
    totalFils: 0,
    total: formatFils(0),
    currency: config.store.currency,
    shipping: quote({ subtotalFils: 0, governorate, paymentMethod }),
    issues: [],
  };
  if (!cartId) return empty;

  const rows = db.all(
    'SELECT variant_id, qty FROM cart_items WHERE cart_id = ? ORDER BY added_at',
    cartId
  );
  if (!rows.length) return empty;

  const lines = [];
  const issues = [];
  let subtotalFils = 0;
  let count = 0;

  for (const row of rows) {
    const variant = await getPurchasableVariant(row.variant_id);

    if (!variant) {
      issues.push({ variantId: row.variant_id, reason: 'unavailable', message: 'An item is no longer available and was removed.' });
      db.run('DELETE FROM cart_items WHERE cart_id = ? AND variant_id = ?', cartId, row.variant_id);
      continue;
    }

    // Clamp rather than reject: a basket that silently exceeds stock would
    // only fail later, at the worst possible moment.
    let qty = row.qty;
    if (variant.available < qty) {
      qty = variant.available;
      if (qty <= 0) {
        issues.push({ variantId: variant.id, reason: 'out_of_stock', message: `${variant.productTitle} (${variant.label}) sold out.` });
        db.run('DELETE FROM cart_items WHERE cart_id = ? AND variant_id = ?', cartId, variant.id);
        continue;
      }
      issues.push({ variantId: variant.id, reason: 'reduced', message: `Only ${qty} left of ${variant.productTitle} (${variant.label}).` });
      db.run('UPDATE cart_items SET qty = ? WHERE cart_id = ? AND variant_id = ?', qty, cartId, variant.id);
    }

    const lineFils = variant.unitFils * qty;
    subtotalFils += lineFils;
    count += qty;

    lines.push({
      variantId: variant.id,
      productTitle: variant.productTitle,
      productSlug: variant.productSlug,
      variantLabel: variant.label,
      sku: variant.sku,
      imageUrl: variant.imageUrl,
      unitFils: variant.unitFils,
      unit: formatFils(variant.unitFils),
      qty,
      maxQty: Math.min(variant.available, config.cart.maxQtyPerLine),
      lineFils,
      line: formatFils(lineFils),
    });
  }

  const ship = quote({ subtotalFils, governorate, paymentMethod });
  const discountFils = 0;
  const taxFils = applyBps(subtotalFils - discountFils, config.store.taxRateBps);
  const totalFils = subtotalFils - discountFils + ship.shippingFils + taxFils;

  return {
    lines,
    count,
    subtotalFils,
    subtotal: formatFils(subtotalFils),
    discountFils,
    discount: formatFils(discountFils),
    shippingFils: ship.shippingFils,
    shippingLabel: ship.freeShippingApplied ? 'Free' : formatFils(ship.shippingFils),
    taxFils,
    tax: formatFils(taxFils),
    totalFils,
    total: formatFils(totalFils),
    currency: config.store.currency,
    shipping: ship,
    issues,
  };
}

export async function addItem(ctx, variantId, qty) {
  const db = await getDb();
  const variant = await getPurchasableVariant(variantId);
  if (!variant) throw notFound('That piece is no longer available.');
  if (variant.available <= 0) throw conflict('That size just sold out.');

  const cartId = await resolveCart(ctx, { create: true });

  const lineCount = db.get('SELECT COUNT(*) AS n FROM cart_items WHERE cart_id = ?', cartId).n;
  const existing = db.get(
    'SELECT qty FROM cart_items WHERE cart_id = ? AND variant_id = ?',
    cartId, variantId
  );
  if (!existing && lineCount >= config.cart.maxLines) {
    throw badRequest('Your bag is full. Remove something first.');
  }

  const requested = (existing?.qty ?? 0) + qty;
  const capped = Math.min(requested, config.cart.maxQtyPerLine, variant.available);
  if (capped <= 0) throw conflict('That size just sold out.');

  db.tx(() => {
    db.run(
      `INSERT INTO cart_items (cart_id, variant_id, qty, added_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(cart_id, variant_id) DO UPDATE SET qty = excluded.qty`,
      cartId, variantId, capped, Date.now()
    );
    touch(db, cartId);
  });

  return { capped, requested, clamped: capped < requested };
}

export async function setQty(ctx, variantId, qty) {
  const db = await getDb();
  const cartId = await resolveCart(ctx);
  if (!cartId) throw notFound('Your bag is empty.');

  if (qty <= 0) {
    db.tx(() => {
      db.run('DELETE FROM cart_items WHERE cart_id = ? AND variant_id = ?', cartId, variantId);
      touch(db, cartId);
    });
    return { removed: true };
  }

  const variant = await getPurchasableVariant(variantId);
  if (!variant) {
    db.run('DELETE FROM cart_items WHERE cart_id = ? AND variant_id = ?', cartId, variantId);
    throw notFound('That piece is no longer available.');
  }

  const capped = Math.min(qty, config.cart.maxQtyPerLine, variant.available);
  if (capped <= 0) throw conflict('That size just sold out.');

  const result = db.tx(() => {
    const changed = db.run(
      'UPDATE cart_items SET qty = ? WHERE cart_id = ? AND variant_id = ?',
      capped, cartId, variantId
    ).changes;
    touch(db, cartId);
    return changed;
  });
  if (!result) throw notFound('That item is not in your bag.');

  return { qty: capped, clamped: capped < qty };
}

export async function removeItem(ctx, variantId) {
  const db = await getDb();
  const cartId = await resolveCart(ctx);
  if (!cartId) return { removed: false };
  const changes = db.tx(() => {
    const n = db.run('DELETE FROM cart_items WHERE cart_id = ? AND variant_id = ?', cartId, variantId).changes;
    touch(db, cartId);
    return n;
  });
  return { removed: changes > 0 };
}

export async function clearCart(ctx) {
  const db = await getDb();
  const cartId = await resolveCart(ctx);
  if (!cartId) return;
  db.run('DELETE FROM cart_items WHERE cart_id = ?', cartId);
  touch(db, cartId);
}

/** Fold a guest cart into the account's existing cart at sign-in. */
export async function mergeGuestCart(ctx, userId) {
  const db = await getDb();
  const raw = ctx.cookies?.[COOKIE];
  if (!raw) return;
  const guestId = sha256(raw);

  const guest = db.get('SELECT id FROM carts WHERE id = ?', guestId);
  if (!guest) return;

  const prior = db.get(
    `SELECT id FROM carts WHERE user_id = ? AND id <> ? ORDER BY updated_at DESC LIMIT 1`,
    userId, guestId
  );

  db.tx(() => {
    if (prior) {
      for (const item of db.all('SELECT variant_id, qty FROM cart_items WHERE cart_id = ?', prior.id)) {
        const mine = db.get('SELECT qty FROM cart_items WHERE cart_id = ? AND variant_id = ?', guestId, item.variant_id);
        const merged = Math.min((mine?.qty ?? 0) + item.qty, config.cart.maxQtyPerLine);
        db.run(
          `INSERT INTO cart_items (cart_id, variant_id, qty, added_at) VALUES (?, ?, ?, ?)
           ON CONFLICT(cart_id, variant_id) DO UPDATE SET qty = excluded.qty`,
          guestId, item.variant_id, merged, Date.now()
        );
      }
      db.run('DELETE FROM carts WHERE id = ?', prior.id);
    }
    db.run('UPDATE carts SET user_id = ?, updated_at = ? WHERE id = ?', userId, Date.now(), guestId);
  });
}

export async function cartIdFor(ctx) {
  return resolveCart(ctx);
}

export function cartCookieName() {
  return COOKIE;
}
