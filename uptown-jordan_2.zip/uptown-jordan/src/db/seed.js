import { pathToFileURL } from 'node:url';
import { uuid } from '../core/crypto.js';
import { getDb, migrate, closeDb } from './index.js';
import logger from '../core/logger.js';

/**
 * Catalogue seed.
 *
 * Idempotent: re-running updates existing rows by slug/SKU rather than
 * duplicating them, so `npm run seed` is safe against a live database.
 * Stock is only set for *new* variants — an existing variant's stock is left
 * alone, because that is real inventory and a seed script has no business
 * overwriting it.
 */

const CDN = 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P';

const img = (file) => `${CDN}/${file}`;

const COLLECTIONS = [
  { slug: 'arrivals', title: 'New Arrivals', subtitle: 'The latest drop, fresh off the press', order: 1 },
  { slug: 'hoodies', title: 'Hoodies & Terry', subtitle: 'Heavyweight French terry, boxy cuts', order: 2 },
  { slug: 'streetwear', title: 'Streetwear', subtitle: 'Everyday silhouettes with an edge', order: 3 },
  { slug: 'footwear', title: 'Footwear', subtitle: 'Finishing the fit', order: 4 },
  { slug: 'outlets', title: 'Outlet', subtitle: 'Last sizes, last chances', order: 5 },
];

const APPAREL_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const BOTTOM_SIZES = ['28', '30', '32', '34', '36'];

const PRODUCTS = [
  {
    slug: 'vintage-washed-hoodie',
    title: 'Vintage Washed Hoodie',
    subtitle: 'Heavy terry · Boxy fit',
    description:
      'A 480 GSM French terry hoodie put through a three-stage garment wash, so it arrives already broken in. Dropped shoulders, a boxy body and a double-layer hood that holds its shape.',
    material: '100% combed cotton, 480 GSM French terry',
    care: 'Cold machine wash inside out. Line dry. Do not tumble.',
    collection: 'hoodies',
    price: 38_000,
    compareAt: 50_000,
    badge: '-25%',
    featured: true,
    images: [
      { file: 'hf_20260912_110423_3b5dcf24-cc07-4f3b-8423-b597fffcdbfb.png', alt: 'Heavyweight Washed Vintage Hoodie' },
      { file: 'hf_20260912_110422_a90a35d7-ae20-4ce3-86d7-e3f6f658a6bc.png', alt: 'Vintage washed hoodie, minimal styling' },
    ],
    sizes: APPAREL_SIZES,
    stock: [4, 9, 14, 12, 7, 3],
  },
  {
    slug: 'relaxed-cargo-pants',
    title: 'Relaxed Cargo Pants',
    subtitle: 'Tactical pocket · Tapered leg',
    description:
      'Ripstop cargos cut with a relaxed thigh and a clean taper from the knee. Bellowed side pockets sit flat when empty, so the silhouette stays sharp.',
    material: '98% cotton ripstop, 2% elastane',
    care: 'Machine wash cold with like colours. Warm iron if needed.',
    collection: 'streetwear',
    price: 32_000,
    featured: true,
    images: [
      { file: 'hf_20260912_110504_50ec81be-8341-447f-a0c2-a5673a465447.png', alt: 'Relaxed Fit Tech Cargo Pants' },
    ],
    sizes: BOTTOM_SIZES,
    stock: [6, 11, 13, 8, 4],
  },
  {
    slug: 'uptown-club-set',
    title: 'Uptown Club Set',
    subtitle: '2-piece ensemble',
    description:
      'The matching set: a boxy half-zip and wide-leg trouser in the same brushed-back terry. Buy it together, wear it apart.',
    material: '100% cotton, brushed-back terry, 420 GSM',
    care: 'Cold wash. Reshape while damp. Do not bleach.',
    collection: 'arrivals',
    price: 65_000,
    compareAt: 85_000,
    badge: 'SET',
    featured: true,
    images: [
      { file: 'hf_20260912_110504_fd208d72-9112-4cde-b509-8d273b470c6f.png', alt: 'Uptown Layered Streetwear Set' },
      { file: 'hf_20260912_110423_87ec2115-3157-47ef-ac98-973f8ad6532d.png', alt: 'Uptown club set styled on the street' },
    ],
    sizes: APPAREL_SIZES,
    stock: [2, 6, 9, 8, 5, 2],
  },
  {
    slug: 'acid-wash-boxy-tee',
    title: 'Acid Wash Boxy Tee',
    subtitle: '260 GSM cotton',
    description:
      'A proper heavyweight tee that will not go translucent after a month. Acid washed in small batches, so no two are identical.',
    material: '100% cotton, 260 GSM, acid washed',
    care: 'Wash separately for the first three washes.',
    collection: 'streetwear',
    price: 22_000,
    badge: 'NEW',
    featured: true,
    images: [
      { file: 'hf_20260912_110504_9731544c-a83b-48c4-bacb-e31e4d4b9f42.png', alt: 'Graphic Oversized Boxy Tee' },
    ],
    sizes: APPAREL_SIZES,
    stock: [8, 16, 20, 18, 10, 5],
  },
  {
    slug: 'minimal-hoodie',
    title: 'Minimal Hoodie',
    subtitle: 'Unbranded · Pigment dyed',
    description:
      'No logo, no print, no seasonal graphic. Pigment dyed so it fades with you rather than against you.',
    material: '100% cotton, 420 GSM, pigment dyed',
    care: 'Cold wash inside out. Expect gentle fading — that is the point.',
    collection: 'hoodies',
    price: 42_000,
    images: [
      { file: 'hf_20260912_110422_a90a35d7-ae20-4ce3-86d7-e3f6f658a6bc.png', alt: 'Minimal unbranded hoodie in pigment dye' },
    ],
    sizes: APPAREL_SIZES,
    stock: [3, 7, 11, 9, 6, 2],
  },
  {
    slug: 'signature-oversize-crew',
    title: 'Signature Oversize Crew',
    subtitle: 'Crafted for everyday movement',
    description:
      'The house silhouette: an exaggerated shoulder, a shortened body and ribbing heavy enough to hold the hem where you put it.',
    material: '80% cotton, 20% recycled polyester, 450 GSM',
    care: 'Machine wash cold. Tumble dry low.',
    collection: 'arrivals',
    price: 46_000,
    featured: true,
    images: [
      { file: 'hf_20260912_110422_de267714-7647-4d9a-a0a9-55325683b2a2.png', alt: 'Signature oversize crew in the Uptown cut' },
    ],
    sizes: APPAREL_SIZES,
    stock: [5, 10, 12, 10, 6, 3],
  },
  {
    slug: 'summer-drop-shirt',
    title: 'Summer Drop Shirt',
    subtitle: 'Camp collar · Airflow weave',
    description:
      'An open-weave camp collar cut long enough to wear untucked. Built for Amman in August.',
    material: '55% linen, 45% cotton',
    care: 'Cool wash. Iron while slightly damp.',
    collection: 'streetwear',
    price: 28_000,
    images: [
      { file: 'hf_20260912_110504_80eda275-e380-4ccb-b51f-332f25337079.png', alt: 'Summer drop camp collar shirt' },
    ],
    sizes: APPAREL_SIZES,
    stock: [4, 8, 10, 9, 5, 2],
  },
  {
    slug: 'capsule-26-jacket',
    title: "Capsule '26 Jacket",
    subtitle: 'Limited run of 120',
    description:
      'The capsule piece: a cropped coach jacket with a tonal back panel and hidden snap placket. Numbered, and not returning.',
    material: 'Cotton twill shell, satin lining',
    care: 'Spot clean or dry clean only.',
    collection: 'arrivals',
    price: 89_000,
    badge: 'LIMITED',
    featured: true,
    images: [
      { file: 'hf_20260912_110423_ba46182e-43bc-43a8-9007-a8234acf442d.png', alt: "Uptown Capsule '26 cropped coach jacket" },
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    stock: [2, 4, 4, 2],
  },
  {
    slug: 'urban-cuts-tee',
    title: 'Urban Cuts Tee',
    subtitle: 'Hoodies · Cargo · Tees',
    description:
      'The everyday tee in the Uptown block cut. Wears well on its own and layers under everything else in the collection.',
    material: '100% ring-spun cotton, 220 GSM',
    care: 'Machine wash cold. Tumble dry low.',
    collection: 'streetwear',
    price: 18_000,
    images: [
      { file: 'hf_20260912_110423_06cfbb84-6f96-48f6-be45-e03516510e48.png', alt: 'Urban cuts everyday tee' },
    ],
    sizes: APPAREL_SIZES,
    stock: [12, 20, 24, 20, 12, 6],
  },
  {
    slug: 'heritage-terry-crew',
    title: 'Heritage Terry Crew',
    subtitle: 'Tailored in Amman',
    description:
      'Bespoke boxy cuts and premium wash treatments, made in a small Amman workshop we have worked with since the first drop.',
    material: 'Heavyweight French terry, 500 GSM',
    care: 'Cold wash. Line dry in shade.',
    collection: 'hoodies',
    price: 52_000,
    images: [
      { file: 'hf_20260912_110422_634bf390-f171-4f5d-9151-0d2c86c26e7b.png', alt: 'Heritage terry crew, tailored in Amman' },
    ],
    sizes: APPAREL_SIZES,
    stock: [3, 6, 8, 7, 4, 2],
  },
  {
    slug: 'outlet-seasonal-hoodie',
    title: 'Seasonal Hoodie — Outlet',
    subtitle: 'Last sizes · 40% off',
    description:
      'End-of-season pieces at outlet pricing. Sizes are whatever is left, and once they are gone they are gone.',
    material: '100% cotton, 420 GSM',
    care: 'Cold wash inside out.',
    collection: 'outlets',
    price: 27_000,
    compareAt: 45_000,
    badge: '-40%',
    images: [
      { file: 'hf_20260912_110422_d6ba08f5-4ff8-4f09-8abe-93ee6bb0e34e.png', alt: 'Seasonal outlet hoodie at 40 percent off' },
    ],
    sizes: ['S', 'M', 'XL'],
    stock: [2, 3, 1],
  },
  {
    slug: 'everyday-runner',
    title: 'Everyday Runner',
    subtitle: 'Low profile · Gum sole',
    description:
      'A stripped-back trainer with a gum outsole and a padded collar. Sits low enough to disappear under a wide-leg trouser.',
    material: 'Suede and mesh upper, rubber outsole',
    care: 'Brush clean. Protect with a suede spray before first wear.',
    collection: 'footwear',
    price: 58_000,
    images: [
      { file: 'hf_20260912_110422_0fc34393-7417-41b0-a200-43fd2b08a37f.png', alt: 'Everyday runner trainer with gum sole' },
    ],
    sizes: ['40', '41', '42', '43', '44', '45'],
    stock: [3, 5, 8, 7, 5, 2],
  },
];

export async function seed() {
  await migrate();
  const db = await getDb();
  const now = Date.now();

  const collectionIds = new Map();

  db.tx(() => {
    for (const c of COLLECTIONS) {
      const existing = db.get('SELECT id FROM collections WHERE slug = ?', c.slug);
      if (existing) {
        db.run(
          'UPDATE collections SET title = ?, subtitle = ?, sort_order = ?, updated_at = ? WHERE id = ?',
          c.title, c.subtitle, c.order, now, existing.id
        );
        collectionIds.set(c.slug, existing.id);
        continue;
      }
      const id = uuid();
      db.run(
        `INSERT INTO collections (id, slug, title, subtitle, sort_order, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?)`,
        id, c.slug, c.title, c.subtitle, c.order, now, now
      );
      collectionIds.set(c.slug, id);
    }

    PRODUCTS.forEach((p, index) => {
      const collectionId = collectionIds.get(p.collection) ?? null;
      let productId = db.get('SELECT id FROM products WHERE slug = ?', p.slug)?.id;

      if (productId) {
        db.run(
          `UPDATE products SET title = ?, subtitle = ?, description = ?, material = ?, care = ?,
                               collection_id = ?, price_fils = ?, compare_at_fils = ?, badge = ?,
                               status = 'active', is_featured = ?, sort_order = ?, updated_at = ?
            WHERE id = ?`,
          p.title, p.subtitle, p.description, p.material, p.care, collectionId,
          p.price, p.compareAt ?? null, p.badge ?? '', p.featured ? 1 : 0, index, now, productId
        );
      } else {
        productId = uuid();
        db.run(
          `INSERT INTO products (id, slug, title, subtitle, description, material, care,
                                 collection_id, price_fils, compare_at_fils, badge, status,
                                 is_featured, sort_order, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)`,
          productId, p.slug, p.title, p.subtitle, p.description, p.material, p.care,
          collectionId, p.price, p.compareAt ?? null, p.badge ?? '',
          p.featured ? 1 : 0, index, now, now
        );
      }

      db.run('DELETE FROM product_images WHERE product_id = ?', productId);
      p.images.forEach((image, i) => {
        db.run(
          'INSERT INTO product_images (id, product_id, url, alt, sort_order) VALUES (?, ?, ?, ?, ?)',
          uuid(), productId, img(image.file), image.alt, i
        );
      });

      p.sizes.forEach((size, i) => {
        const sku = `${p.slug.toUpperCase().replace(/-/g, '')}-${size}`.slice(0, 40);
        const existing = db.get('SELECT id FROM variants WHERE sku = ?', sku);
        if (existing) {
          // Keep real stock; only refresh the descriptive fields.
          db.run(
            'UPDATE variants SET size = ?, sort_order = ?, is_active = 1, updated_at = ? WHERE id = ?',
            size, i, now, existing.id
          );
          return;
        }
        db.run(
          `INSERT INTO variants (id, product_id, sku, size, colour, price_fils, stock, reserved,
                                 is_active, sort_order, created_at, updated_at)
           VALUES (?, ?, ?, ?, '', NULL, ?, 0, 1, ?, ?, ?)`,
          uuid(), productId, sku, size, p.stock[i] ?? 5, i, now, now
        );
      });
    });
  });

  const counts = {
    collections: db.get('SELECT COUNT(*) AS n FROM collections').n,
    products: db.get('SELECT COUNT(*) AS n FROM products').n,
    variants: db.get('SELECT COUNT(*) AS n FROM variants').n,
  };
  logger.info('seed complete', counts);
  return counts;
}

// See the note in server.js — string-concatenated file:// URLs do not match
// on Windows, which made `npm run seed` exit without doing anything.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  seed()
    .then((counts) => {
      console.log(
        `Seeded ${counts.products} products / ${counts.variants} variants across ${counts.collections} collections.`
      );
      return closeDb();
    })
    .catch((err) => {
      console.error('Seed failed:', err.message);
      process.exit(1);
    });
}
