-- ============================================================================
--  Uptown Jordan — schema
--
--  Conventions that matter for safety:
--    * Every monetary column is an INTEGER count of fils (1 JOD = 1000 fils).
--      No floats touch money, anywhere.
--    * Every foreign key is declared and PRAGMA foreign_keys is ON, so the
--      database refuses to hold an order line pointing at a deleted variant.
--    * Prices are COPIED onto order lines at capture time. Changing a product
--      price later can never rewrite the history of what someone was charged.
--    * Secrets (session ids, cart tokens, reset tokens) are stored only as
--      SHA-256 digests. A database leak does not hand over live credentials.
--    * Timestamps are INTEGER epoch milliseconds (UTC), never local strings.
--    * CHECK constraints encode the invariants so that a bug in application
--      code cannot persist nonsense (negative stock, qty 0, unknown status).
-- ============================================================================

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------- migrations
CREATE TABLE IF NOT EXISTS schema_migrations (
  version     INTEGER PRIMARY KEY,
  name        TEXT    NOT NULL,
  applied_at  INTEGER NOT NULL
);

-- --------------------------------------------------------------------- users
CREATE TABLE IF NOT EXISTS users (
  id                 TEXT    PRIMARY KEY,
  email              TEXT    NOT NULL,
  -- Lower-cased, trimmed copy. Uniqueness is enforced on this, so
  -- Hisham@x.com and hisham@x.com cannot both register.
  email_normalized   TEXT    NOT NULL UNIQUE,
  password_hash      TEXT    NOT NULL,
  full_name          TEXT    NOT NULL DEFAULT '',
  phone              TEXT    NOT NULL DEFAULT '',
  role               TEXT    NOT NULL DEFAULT 'customer'
                             CHECK (role IN ('customer','staff','admin')),
  status             TEXT    NOT NULL DEFAULT 'active'
                             CHECK (status IN ('active','locked','disabled')),
  -- Consecutive failed logins; drives temporary lockout.
  failed_logins      INTEGER NOT NULL DEFAULT 0 CHECK (failed_logins >= 0),
  locked_until       INTEGER,
  -- Base32 TOTP secret for admin/staff two-factor. NULL = not enrolled.
  totp_secret        TEXT,
  totp_enabled       INTEGER NOT NULL DEFAULT 0 CHECK (totp_enabled IN (0,1)),
  password_changed_at INTEGER NOT NULL,
  created_at         INTEGER NOT NULL,
  updated_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role) WHERE role <> 'customer';

-- ------------------------------------------------------------------ sessions
-- `id` is the SHA-256 of the cookie value, never the cookie value itself.
CREATE TABLE IF NOT EXISTS sessions (
  id            TEXT    PRIMARY KEY,
  user_id       TEXT    REFERENCES users(id) ON DELETE CASCADE,
  role          TEXT    NOT NULL DEFAULT 'guest',
  -- Truncated HMACs, not raw values: enough to spot a stolen cookie being
  -- replayed from elsewhere, not enough to be a tracking database.
  ip_hash       TEXT    NOT NULL DEFAULT '',
  ua_hash       TEXT    NOT NULL DEFAULT '',
  -- Set once the second factor has been satisfied for this session.
  mfa_ok        INTEGER NOT NULL DEFAULT 0 CHECK (mfa_ok IN (0,1)),
  created_at    INTEGER NOT NULL,
  last_seen_at  INTEGER NOT NULL,
  expires_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user    ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

-- Single-use, short-lived, hashed. Consumed rows are kept until expiry so a
-- replay is answered "already used" rather than "unknown token".
CREATE TABLE IF NOT EXISTS password_resets (
  id          TEXT    PRIMARY KEY,
  user_id     TEXT    NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL,
  used_at     INTEGER
);
CREATE INDEX IF NOT EXISTS idx_resets_user ON password_resets(user_id);

-- ----------------------------------------------------------------- addresses
CREATE TABLE IF NOT EXISTS addresses (
  id           TEXT    PRIMARY KEY,
  user_id      TEXT    NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label        TEXT    NOT NULL DEFAULT '',
  full_name    TEXT    NOT NULL,
  phone        TEXT    NOT NULL,
  governorate  TEXT    NOT NULL,
  city         TEXT    NOT NULL,
  street       TEXT    NOT NULL,
  building     TEXT    NOT NULL DEFAULT '',
  notes        TEXT    NOT NULL DEFAULT '',
  is_default   INTEGER NOT NULL DEFAULT 0 CHECK (is_default IN (0,1)),
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_addresses_user ON addresses(user_id);

-- ----------------------------------------------------------------- catalogue
CREATE TABLE IF NOT EXISTS collections (
  id          TEXT    PRIMARY KEY,
  slug        TEXT    NOT NULL UNIQUE,
  title       TEXT    NOT NULL,
  subtitle    TEXT    NOT NULL DEFAULT '',
  sort_order  INTEGER NOT NULL DEFAULT 0,
  is_active   INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id              TEXT    PRIMARY KEY,
  slug            TEXT    NOT NULL UNIQUE,
  title           TEXT    NOT NULL,
  subtitle        TEXT    NOT NULL DEFAULT '',
  description     TEXT    NOT NULL DEFAULT '',
  -- Stored as plain text and rendered with textContent on the client.
  -- No HTML is ever accepted or emitted for merchant-authored copy.
  material        TEXT    NOT NULL DEFAULT '',
  care            TEXT    NOT NULL DEFAULT '',
  collection_id   TEXT    REFERENCES collections(id) ON DELETE SET NULL,
  price_fils      INTEGER NOT NULL CHECK (price_fils >= 0),
  compare_at_fils INTEGER CHECK (compare_at_fils IS NULL OR compare_at_fils >= 0),
  badge           TEXT    NOT NULL DEFAULT '',
  status          TEXT    NOT NULL DEFAULT 'active'
                          CHECK (status IN ('draft','active','archived')),
  is_featured     INTEGER NOT NULL DEFAULT 0 CHECK (is_featured IN (0,1)),
  sort_order      INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_status     ON products(status);
CREATE INDEX IF NOT EXISTS idx_products_collection ON products(collection_id);
CREATE INDEX IF NOT EXISTS idx_products_featured   ON products(is_featured) WHERE is_featured = 1;

CREATE TABLE IF NOT EXISTS product_images (
  id          TEXT    PRIMARY KEY,
  product_id  TEXT    NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url         TEXT    NOT NULL,
  alt         TEXT    NOT NULL DEFAULT '',
  sort_order  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_images_product ON product_images(product_id, sort_order);

CREATE TABLE IF NOT EXISTS variants (
  id              TEXT    PRIMARY KEY,
  product_id      TEXT    NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  sku             TEXT    NOT NULL UNIQUE,
  size            TEXT    NOT NULL,
  colour          TEXT    NOT NULL DEFAULT '',
  -- NULL means "inherit the product price".
  price_fils      INTEGER CHECK (price_fils IS NULL OR price_fils >= 0),
  stock           INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  -- Units held by unpaid/unfulfilled orders. available = stock - reserved.
  reserved        INTEGER NOT NULL DEFAULT 0 CHECK (reserved >= 0),
  is_active       INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  sort_order      INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  CHECK (reserved <= stock)
);
CREATE INDEX IF NOT EXISTS idx_variants_product ON variants(product_id, sort_order);

-- ---------------------------------------------------------------------- cart
-- `id` is the SHA-256 of the cart cookie value.
CREATE TABLE IF NOT EXISTS carts (
  id          TEXT    PRIMARY KEY,
  user_id     TEXT    REFERENCES users(id) ON DELETE SET NULL,
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_carts_expires ON carts(expires_at);
CREATE INDEX IF NOT EXISTS idx_carts_user    ON carts(user_id);

-- No price column by design. A cart line is (what, how many); the price is
-- always recomputed from the catalogue, so a tampered client cannot set it.
CREATE TABLE IF NOT EXISTS cart_items (
  cart_id     TEXT    NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
  variant_id  TEXT    NOT NULL REFERENCES variants(id) ON DELETE CASCADE,
  qty         INTEGER NOT NULL CHECK (qty > 0),
  added_at    INTEGER NOT NULL,
  PRIMARY KEY (cart_id, variant_id)
);

-- -------------------------------------------------------------------- orders
CREATE TABLE IF NOT EXISTS orders (
  id                 TEXT    PRIMARY KEY,
  -- Human-facing reference, e.g. UJ-2609-8H3KQ.
  number             TEXT    NOT NULL UNIQUE,
  user_id            TEXT    REFERENCES users(id) ON DELETE SET NULL,
  email              TEXT    NOT NULL,
  phone              TEXT    NOT NULL,

  status             TEXT    NOT NULL DEFAULT 'pending'
                             CHECK (status IN ('pending','paid','processing',
                                               'shipped','delivered',
                                               'cancelled','refunded')),
  payment_method     TEXT    NOT NULL CHECK (payment_method IN ('cod','card')),
  payment_status     TEXT    NOT NULL DEFAULT 'unpaid'
                             CHECK (payment_status IN ('unpaid','authorized',
                                                       'paid','failed',
                                                       'refunded')),

  -- Money, all in fils, all computed server-side at capture time.
  subtotal_fils      INTEGER NOT NULL CHECK (subtotal_fils >= 0),
  discount_fils      INTEGER NOT NULL DEFAULT 0 CHECK (discount_fils >= 0),
  shipping_fils      INTEGER NOT NULL DEFAULT 0 CHECK (shipping_fils >= 0),
  tax_fils           INTEGER NOT NULL DEFAULT 0 CHECK (tax_fils >= 0),
  total_fils         INTEGER NOT NULL CHECK (total_fils >= 0),
  currency           TEXT    NOT NULL DEFAULT 'JOD',

  ship_full_name     TEXT    NOT NULL,
  ship_phone         TEXT    NOT NULL,
  ship_governorate   TEXT    NOT NULL,
  ship_city          TEXT    NOT NULL,
  ship_street        TEXT    NOT NULL,
  ship_building      TEXT    NOT NULL DEFAULT '',
  ship_notes         TEXT    NOT NULL DEFAULT '',

  -- SHA-256 of a random lookup token, so a guest can check their order
  -- without an account and without the order id being guessable.
  lookup_token_hash  TEXT    NOT NULL,

  placed_ip_hash     TEXT    NOT NULL DEFAULT '',
  cancelled_reason   TEXT    NOT NULL DEFAULT '',
  created_at         INTEGER NOT NULL,
  updated_at         INTEGER NOT NULL,
  paid_at            INTEGER,
  shipped_at         INTEGER,
  delivered_at       INTEGER,

  CHECK (total_fils = subtotal_fils - discount_fils + shipping_fils + tax_fils)
);
CREATE INDEX IF NOT EXISTS idx_orders_user    ON orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status  ON orders(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_lookup  ON orders(lookup_token_hash);

-- Denormalised on purpose: an order line must remain readable exactly as it
-- was sold even if the product is renamed, repriced or deleted.
CREATE TABLE IF NOT EXISTS order_items (
  id             TEXT    PRIMARY KEY,
  order_id       TEXT    NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  variant_id     TEXT    REFERENCES variants(id) ON DELETE SET NULL,
  product_title  TEXT    NOT NULL,
  variant_label  TEXT    NOT NULL,
  sku            TEXT    NOT NULL,
  image_url      TEXT    NOT NULL DEFAULT '',
  unit_fils      INTEGER NOT NULL CHECK (unit_fils >= 0),
  qty            INTEGER NOT NULL CHECK (qty > 0),
  line_fils      INTEGER NOT NULL CHECK (line_fils >= 0),
  CHECK (line_fils = unit_fils * qty)
);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS order_events (
  id          TEXT    PRIMARY KEY,
  order_id    TEXT    NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  type        TEXT    NOT NULL,
  message     TEXT    NOT NULL DEFAULT '',
  actor       TEXT    NOT NULL DEFAULT 'system',
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_events_order ON order_events(order_id, created_at);

-- ------------------------------------------------------------------ payments
CREATE TABLE IF NOT EXISTS payments (
  id                TEXT    PRIMARY KEY,
  order_id          TEXT    NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  provider          TEXT    NOT NULL,
  -- The provider's id for the intent/session. Unique so a replayed webhook
  -- cannot create a second payment row.
  provider_ref      TEXT    NOT NULL,
  status            TEXT    NOT NULL DEFAULT 'created'
                            CHECK (status IN ('created','authorized','paid',
                                              'failed','cancelled','refunded')),
  amount_fils       INTEGER NOT NULL CHECK (amount_fils >= 0),
  currency          TEXT    NOT NULL DEFAULT 'JOD',
  -- Only ever the last four digits and a brand string. No PAN, no CVV,
  -- no expiry is accepted by, or stored in, this system.
  card_brand        TEXT    NOT NULL DEFAULT '',
  card_last4        TEXT    NOT NULL DEFAULT '' CHECK (length(card_last4) <= 4),
  failure_reason    TEXT    NOT NULL DEFAULT '',
  expires_at        INTEGER,
  created_at        INTEGER NOT NULL,
  updated_at        INTEGER NOT NULL,
  UNIQUE (provider, provider_ref)
);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);

-- Every webhook event id is recorded before it is acted on. A replayed
-- delivery hits this unique index and becomes a no-op.
CREATE TABLE IF NOT EXISTS webhook_events (
  id           TEXT    PRIMARY KEY,
  provider     TEXT    NOT NULL,
  event_id     TEXT    NOT NULL,
  event_type   TEXT    NOT NULL DEFAULT '',
  payload_hash TEXT    NOT NULL,
  received_at  INTEGER NOT NULL,
  UNIQUE (provider, event_id)
);

-- Makes checkout safe to retry: the same key returns the same order instead
-- of charging a customer twice because their phone lost signal mid-request.
CREATE TABLE IF NOT EXISTS idempotency_keys (
  id           TEXT    PRIMARY KEY,
  scope        TEXT    NOT NULL,
  key_hash     TEXT    NOT NULL,
  request_hash TEXT    NOT NULL,
  response     TEXT    NOT NULL,
  created_at   INTEGER NOT NULL,
  expires_at   INTEGER NOT NULL,
  UNIQUE (scope, key_hash)
);
CREATE INDEX IF NOT EXISTS idx_idem_expires ON idempotency_keys(expires_at);

-- ------------------------------------------------------------ rate limiting
-- Kept in the database rather than memory so limits survive a restart and
-- hold across multiple workers.
CREATE TABLE IF NOT EXISTS rate_limits (
  bucket        TEXT    PRIMARY KEY,
  count         INTEGER NOT NULL DEFAULT 0,
  window_start  INTEGER NOT NULL,
  expires_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rate_expires ON rate_limits(expires_at);

-- --------------------------------------------------------------- audit trail
-- Append-only record of every privileged mutation. Never updated or deleted
-- by application code.
CREATE TABLE IF NOT EXISTS audit_log (
  id          TEXT    PRIMARY KEY,
  actor_id    TEXT,
  actor_email TEXT    NOT NULL DEFAULT '',
  action      TEXT    NOT NULL,
  entity      TEXT    NOT NULL DEFAULT '',
  entity_id   TEXT    NOT NULL DEFAULT '',
  detail      TEXT    NOT NULL DEFAULT '',
  ip_hash     TEXT    NOT NULL DEFAULT '',
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_actor   ON audit_log(actor_id, created_at DESC);

-- ------------------------------------------------------------------ contacts
CREATE TABLE IF NOT EXISTS newsletter (
  id            TEXT    PRIMARY KEY,
  email_hash    TEXT    NOT NULL UNIQUE,
  email         TEXT    NOT NULL,
  -- Double opt-in: a subscriber is only mailable once confirmed_at is set.
  -- The token is stored as a digest, like every other secret here.
  confirm_token_hash TEXT,
  confirmed_at  INTEGER,
  unsubscribed_at INTEGER,
  source        TEXT    NOT NULL DEFAULT 'footer',
  created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_newsletter_confirmed
  ON newsletter(confirmed_at) WHERE confirmed_at IS NOT NULL AND unsubscribed_at IS NULL;

-- ============================================================================
--  v2 — reviews, stock alerts, contact
-- ============================================================================

-- Reviews are written only by customers who actually received the product.
-- The order_id is recorded on the row so that claim is auditable later, and
-- the UNIQUE(product_id, user_id) pair keeps one voice to one review.
CREATE TABLE IF NOT EXISTS reviews (
  id            TEXT    PRIMARY KEY,
  product_id    TEXT    NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  user_id       TEXT    NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  -- The delivered order that entitles this review. Kept even if the order is
  -- later archived, so "verified purchase" can always be re-checked.
  order_id      TEXT    REFERENCES orders(id) ON DELETE SET NULL,
  rating        INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title         TEXT    NOT NULL DEFAULT '',
  body          TEXT    NOT NULL DEFAULT '',
  -- Reviews are held until a human publishes them. Nothing reaches the
  -- storefront unread.
  status        TEXT    NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','published','rejected')),
  -- Display name captured at write time, so a later profile edit does not
  -- silently rewrite an attributed opinion.
  author_name   TEXT    NOT NULL DEFAULT '',
  size_bought   TEXT    NOT NULL DEFAULT '',
  moderated_by  TEXT,
  moderated_at  INTEGER,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL,
  UNIQUE (product_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reviews_status  ON reviews(status, created_at DESC);

-- "Tell me when my size is back." Email stored alongside a digest so the same
-- address cannot queue the same variant twice.
CREATE TABLE IF NOT EXISTS stock_alerts (
  id           TEXT    PRIMARY KEY,
  variant_id   TEXT    NOT NULL REFERENCES variants(id) ON DELETE CASCADE,
  email        TEXT    NOT NULL,
  email_hash   TEXT    NOT NULL,
  created_at   INTEGER NOT NULL,
  notified_at  INTEGER,
  UNIQUE (variant_id, email_hash)
);
CREATE INDEX IF NOT EXISTS idx_alerts_variant ON stock_alerts(variant_id) WHERE notified_at IS NULL;

-- Messages from the contact form. Held in the database rather than emailed
-- straight out, so nothing is lost if mail delivery is down.
CREATE TABLE IF NOT EXISTS enquiries (
  id           TEXT    PRIMARY KEY,
  name         TEXT    NOT NULL,
  email        TEXT    NOT NULL,
  phone        TEXT    NOT NULL DEFAULT '',
  topic        TEXT    NOT NULL DEFAULT 'general',
  order_number TEXT    NOT NULL DEFAULT '',
  message      TEXT    NOT NULL,
  status       TEXT    NOT NULL DEFAULT 'open'
                       CHECK (status IN ('open','answered','closed')),
  ip_hash      TEXT    NOT NULL DEFAULT '',
  created_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_enquiries_status ON enquiries(status, created_at DESC);
