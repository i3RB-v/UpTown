/**
 * Thin SQLite adapter.
 *
 * Presents one small surface over two interchangeable engines:
 *
 *   - better-sqlite3 : the battle-tested native binding. Used automatically
 *                      when it is installed (`npm i better-sqlite3`).
 *   - node:sqlite    : Node's built-in engine. Zero dependencies, which is
 *                      why it is the default here.
 *
 * Only positional `?` parameters are used anywhere in this codebase, so the
 * two engines are drop-in equivalents. Every query in the application goes
 * through prepared statements — there is no string interpolation of user
 * input into SQL anywhere, which is what makes SQL injection structurally
 * impossible rather than merely unlikely.
 */
import config from '../config.js';

async function loadEngine() {
  const want = config.db.driver;

  if (want === 'better-sqlite3' || want === 'auto') {
    try {
      const mod = await import('better-sqlite3');
      return { name: 'better-sqlite3', Ctor: mod.default };
    } catch (err) {
      if (want === 'better-sqlite3') throw err;
    }
  }

  const { DatabaseSync } = await import('node:sqlite');
  return { name: 'node:sqlite', Ctor: DatabaseSync };
}

/** Coerce null-prototype rows (node:sqlite) into ordinary objects. */
function plain(row) {
  return row == null ? row : { ...row };
}

export async function openDatabase(file) {
  const { name, Ctor } = await loadEngine();
  const raw = new Ctor(file);

  const exec = (sql) => raw.exec(sql);

  // `pragma journal_mode=WAL` returns a row; exec() cannot read it, so the
  // engines' differing pragma APIs are normalised here.
  const pragma = (text) => {
    if (typeof raw.pragma === 'function') return raw.pragma(text); // better-sqlite3
    return raw.prepare(`PRAGMA ${text}`).all(); // node:sqlite
  };

  let depth = 0;

  const api = {
    engine: name,
    file,
    raw,
    exec,
    pragma,

    prepare(sql) {
      const stmt = raw.prepare(sql);
      return {
        get: (...params) => plain(stmt.get(...params)),
        all: (...params) => stmt.all(...params).map(plain),
        run: (...params) => {
          const r = stmt.run(...params);
          return {
            changes: Number(r.changes ?? 0),
            lastInsertRowid: Number(r.lastInsertRowid ?? 0),
          };
        },
      };
    },

    get: (sql, ...p) => api.prepare(sql).get(...p),
    all: (sql, ...p) => api.prepare(sql).all(...p),
    run: (sql, ...p) => api.prepare(sql).run(...p),

    /**
     * Run `fn` inside a transaction. Nested calls use SAVEPOINTs so that a
     * service can be composed into a larger unit of work without either
     * committing early or dead-locking.
     *
     * BEGIN IMMEDIATE takes the write lock up front, which turns
     * "database is locked" races into a clean wait instead of a mid-
     * transaction failure.
     */
    tx(fn) {
      const name = `sp_${depth}`;
      if (depth === 0) exec('BEGIN IMMEDIATE');
      else exec(`SAVEPOINT ${name}`);
      depth += 1;
      try {
        const out = fn();
        depth -= 1;
        if (depth === 0) exec('COMMIT');
        else exec(`RELEASE ${name}`);
        return out;
      } catch (err) {
        depth -= 1;
        try {
          if (depth === 0) exec('ROLLBACK');
          else exec(`ROLLBACK TO ${name}`);
        } catch {
          /* the outer handler reports the original failure */
        }
        throw err;
      }
    },

    close() {
      try {
        // Fold the WAL back into the main file so a copied/backed-up .db
        // is self-contained.
        pragma('wal_checkpoint(TRUNCATE)');
      } catch {
        /* non-fatal */
      }
      raw.close();
    },
  };

  return api;
}
