import { chmodSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import config, { ROOT } from '../config.js';
import { openDatabase } from './driver.js';

let db = null;

/** Pragmas applied to every connection. Order matters: WAL before writes. */
function harden(handle) {
  // Referential integrity is off by default in SQLite and is per-connection.
  handle.pragma('foreign_keys = ON');

  // WAL: readers never block the writer, and a crash cannot tear a commit.
  handle.pragma('journal_mode = WAL');

  // NORMAL is the correct pairing with WAL — durable across process crashes,
  // and only at risk from an OS-level power loss mid-checkpoint.
  handle.pragma('synchronous = NORMAL');

  // Wait rather than immediately failing when another writer holds the lock.
  handle.pragma('busy_timeout = 5000');

  // Refuse to run functions/virtual tables named by the schema itself. Blocks
  // the class of attack where a tampered DB file executes on open.
  handle.pragma('trusted_schema = OFF');

  // Detect corrupt pages on read rather than returning garbage.
  handle.pragma('cell_size_check = ON');

  // Cap the WAL so it cannot grow without bound between checkpoints.
  handle.pragma('journal_size_limit = 67108864');

  // Keep temp material in memory; nothing sensitive is written to /tmp.
  handle.pragma('temp_store = MEMORY');
}

export async function getDb() {
  if (db) return db;

  const file = config.db.file;
  const dir = path.dirname(file);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true, mode: 0o750 });

  db = await openDatabase(file);
  harden(db);

  // The database file holds order and customer data. Nothing but the service
  // account should be able to read it.
  if (file !== ':memory:' && existsSync(file)) {
    try {
      chmodSync(file, 0o600);
    } catch {
      /* best effort — Windows and some mounts do not support it */
    }
  }

  return db;
}

/** Apply schema.sql. Idempotent: every statement is CREATE ... IF NOT EXISTS. */
export async function migrate() {
  const handle = await getDb();
  const sql = readFileSync(path.join(ROOT, 'src', 'db', 'schema.sql'), 'utf8');

  handle.exec(sql);
  handle
    .prepare(
      `INSERT INTO schema_migrations (version, name, applied_at)
       VALUES (?, ?, ?)
       ON CONFLICT(version) DO NOTHING`
    )
    .run(1, 'initial_schema', Date.now());

  return handle;
}

/** Fast structural check plus a foreign-key sweep. Used by /healthz and backups. */
export async function integrityCheck() {
  const handle = await getDb();
  const quick = handle.pragma('quick_check');
  const fk = handle.pragma('foreign_key_check');
  const ok =
    quick.length === 1 &&
    Object.values(quick[0])[0] === 'ok' &&
    fk.length === 0;
  return { ok, quick, foreignKeyViolations: fk.length };
}

/** Delete rows that are past their expiry. Called on an interval by server.js. */
export async function sweepExpired(now = Date.now()) {
  const handle = await getDb();
  return handle.tx(() => {
    const sessions = handle.run('DELETE FROM sessions WHERE expires_at < ?', now).changes;
    const carts = handle.run('DELETE FROM carts WHERE expires_at < ?', now).changes;
    const limits = handle.run('DELETE FROM rate_limits WHERE expires_at < ?', now).changes;
    const idem = handle.run('DELETE FROM idempotency_keys WHERE expires_at < ?', now).changes;
    const resets = handle.run('DELETE FROM password_resets WHERE expires_at < ?', now).changes;
    // Webhook ids are kept for 30 days — long enough to defeat replays,
    // short enough that the table does not grow forever.
    const hooks = handle.run(
      'DELETE FROM webhook_events WHERE received_at < ?',
      now - 30 * 86_400_000
    ).changes;
    return { sessions, carts, limits, idem, resets, hooks };
  });
}

export async function closeDb() {
  if (!db) return;
  db.close();
  db = null;
}
