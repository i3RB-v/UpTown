import { closeDb, integrityCheck, migrate } from './index.js';

const handle = await migrate();
const health = await integrityCheck();

const tables = handle
  .all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
  .map((r) => r.name);

console.log(`Engine     : ${handle.engine}`);
console.log(`Database   : ${handle.file}`);
console.log(`Journal    : ${Object.values(handle.pragma('journal_mode')[0])[0]}`);
console.log(`Foreign key: ${Object.values(handle.pragma('foreign_keys')[0])[0] ? 'ON' : 'OFF'}`);
console.log(`Integrity  : ${health.ok ? 'ok' : 'FAILED'}`);
console.log(`Tables (${tables.length}): ${tables.join(', ')}`);

await closeDb();
