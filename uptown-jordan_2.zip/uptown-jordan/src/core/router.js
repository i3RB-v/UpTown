import config from '../config.js';
import { notFound, AppError } from './errors.js';
import { clientIp, parseCookies, redirect, sendJson, sendText } from './http.js';
import logger from './logger.js';

/**
 * A minimal method + path router with an onion middleware chain.
 *
 * Patterns support `:name` segments and a trailing `*`. Nothing is compiled
 * from user input into a RegExp at request time, so there is no ReDoS surface
 * in routing itself.
 */

const MAX_URL_LENGTH = 2048;

function compile(pattern) {
  return pattern.split('/').filter((s) => s.length > 0);
}

function match(segments, parts) {
  const params = {};
  for (let i = 0; i < segments.length; i += 1) {
    const seg = segments[i];
    if (seg === '*') {
      params['*'] = parts.slice(i).join('/');
      return params;
    }
    if (i >= parts.length) return null;
    if (seg.startsWith(':')) {
      params[seg.slice(1)] = parts[i];
      continue;
    }
    if (seg !== parts[i]) return null;
  }
  return segments.length === parts.length ? params : null;
}

export class Router {
  constructor() {
    this.routes = [];
    this.middleware = [];
  }

  use(fn) {
    this.middleware.push(fn);
    return this;
  }

  add(method, pattern, ...handlers) {
    this.routes.push({
      method,
      pattern,
      segments: compile(pattern),
      handlers,
    });
    return this;
  }

  get(p, ...h) { return this.add('GET', p, ...h); }
  post(p, ...h) { return this.add('POST', p, ...h); }
  patch(p, ...h) { return this.add('PATCH', p, ...h); }
  put(p, ...h) { return this.add('PUT', p, ...h); }
  delete(p, ...h) { return this.add('DELETE', p, ...h); }

  /** Mount another router's routes under a prefix. */
  mount(prefix, router) {
    for (const route of router.routes) {
      const pattern = `${prefix}${route.pattern === '/' ? '' : route.pattern}`;
      this.add(route.method, pattern, ...route.handlers);
    }
    return this;
  }

  createContext(req, res) {
    const rawUrl = req.url || '/';
    const url = new URL(rawUrl, config.origin);
    const query = Object.create(null);
    for (const [k, value] of url.searchParams) {
      if (k === '__proto__') continue;
      if (!(k in query)) query[k] = value;
    }

    return {
      req,
      res,
      method: req.method === 'HEAD' ? 'GET' : req.method,
      rawMethod: req.method,
      url,
      path: url.pathname,
      query,
      params: {},
      cookies: parseCookies(req.headers.cookie),
      ip: clientIp(req),
      state: {},
      startedAt: Date.now(),

      json: (status, payload, headers) => sendJson(res, status, payload, headers),
      text: (status, body, headers) => sendText(res, status, body, headers),
      redirect: (location, status) => redirect(res, location, status),
    };
  }

  async handle(req, res) {
    if ((req.url || '').length > MAX_URL_LENGTH) {
      sendJson(res, 414, { error: { code: 'uri_too_long', message: 'Request URL is too long' } });
      return;
    }

    const ctx = this.createContext(req, res);

    // Decoded, normalised path segments. Any `..` is rejected outright rather
    // than normalised away, so no route or static handler can be reached by
    // a traversal-shaped URL.
    let parts;
    try {
      parts = ctx.path
        .split('/')
        .filter((s) => s.length > 0)
        .map((s) => decodeURIComponent(s));
    } catch {
      sendJson(res, 400, { error: { code: 'bad_request', message: 'Malformed URL' } });
      return;
    }
    if (parts.some((p) => p === '..' || p === '.' || p.includes('\0'))) {
      sendJson(res, 400, { error: { code: 'bad_request', message: 'Malformed URL' } });
      return;
    }

    let handlers = null;
    let methodMismatch = false;

    for (const route of this.routes) {
      const params = match(route.segments, parts);
      if (!params) continue;
      if (route.method !== ctx.method) {
        methodMismatch = true;
        continue;
      }
      ctx.params = params;
      ctx.route = route.pattern;
      handlers = route.handlers;
      break;
    }

    const terminal = async () => {
      if (!handlers) {
        if (methodMismatch) {
          const err = new AppError(405, 'method_not_allowed', 'Method not allowed');
          throw err;
        }
        throw notFound('That page could not be found.');
      }
      let result;
      for (const handler of handlers) {
        result = await handler(ctx);
        if (res.writableEnded) return result;
      }
      return result;
    };

    // Compose middleware right-to-left around the terminal handler.
    let next = terminal;
    for (let i = this.middleware.length - 1; i >= 0; i -= 1) {
      const fn = this.middleware[i];
      const downstream = next;
      next = () => fn(ctx, downstream);
    }

    try {
      const result = await next();
      if (res.writableEnded) return;
      if (result === undefined || result === null) {
        res.writeHead(204, { 'Cache-Control': 'no-store' });
        res.end();
        return;
      }
      sendJson(res, 200, result);
    } catch (err) {
      this.onError(ctx, err);
    }
  }

  onError(ctx, err) {
    const { res } = ctx;
    const isApp = err instanceof AppError;
    const status = isApp ? err.status : 500;

    if (status >= 500) {
      logger.error('request failed', {
        path: ctx.path,
        method: ctx.rawMethod,
        err: { name: err?.name, message: err?.message, stack: err?.stack?.split('\n').slice(0, 4) },
      });
    } else {
      logger.debug('request rejected', { path: ctx.path, status, code: isApp ? err.code : 'error' });
    }

    if (res.writableEnded) return;

    // Only curated messages cross the wire. A 500 never reveals the
    // underlying exception text, which is where stack traces, file paths
    // and SQL fragments would otherwise leak.
    const body = {
      error: {
        code: isApp ? err.code : 'server_error',
        message: isApp ? err.message : 'Something went wrong. Please try again.',
        ...(isApp && err.details ? { details: err.details } : {}),
      },
    };

    const headers = {};
    if (status === 429 && err.details?.retryAfterSeconds) {
      headers['Retry-After'] = String(err.details.retryAfterSeconds);
    }
    if (status === 405) headers.Allow = 'GET, POST, PATCH, DELETE';
    // The request body was abandoned unread, so this connection cannot be
    // reused for a following request.
    if (status === 413) headers.Connection = 'close';

    if ((ctx.req.headers.accept || '').includes('text/html') && !ctx.path.startsWith('/api/')) {
      sendText(res, status, body.error.message, headers);
      return;
    }
    sendJson(res, status, body, headers);
  }
}

export default Router;
