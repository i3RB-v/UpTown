import config from '../config.js';

const SCALE = config.store.currencyScale; // 1000 fils to the dinar

/** Parse "38.500" / "38,5" / 38.5 into an integer count of fils.
 *  Returns null when the input is not a sane amount. */
export function parseAmount(input) {
  if (typeof input === 'number') {
    if (!Number.isFinite(input) || input < 0) return null;
    return Math.round(input * SCALE);
  }
  const text = String(input ?? '').trim().replace(',', '.');
  if (!/^\d{1,9}(\.\d{1,3})?$/.test(text)) return null;
  const [whole, frac = ''] = text.split('.');
  const padded = (frac + '000').slice(0, 3);
  return Number(whole) * SCALE + Number(padded);
}

/** 38500 -> "38.500" */
export function formatFils(fils) {
  const n = Math.max(0, Math.trunc(Number(fils) || 0));
  const whole = Math.floor(n / SCALE);
  const frac = String(n % SCALE).padStart(3, '0');
  return `${whole}.${frac}`;
}

/** 38500 -> "38.500 JOD" */
export const formatMoney = (fils) => `${formatFils(fils)} ${config.store.currency}`;

/** Basis points applied with banker-safe integer rounding. */
export function applyBps(fils, bps) {
  if (!bps) return 0;
  return Math.round((fils * bps) / 10_000);
}
