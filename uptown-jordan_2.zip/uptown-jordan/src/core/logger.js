import config from '../config.js';

const LEVELS = { silent: 100, error: 50, warn: 40, info: 30, debug: 20 };
const threshold = LEVELS[config.logLevel] ?? LEVELS.info;

/**
 * Keys whose values are never written to the log, at any depth. Logs get
 * shipped, tailed and pasted into tickets; credentials and customer contact
 * details must not ride along.
 */
const REDACT = new Set([
  'password', 'password_hash', 'passwordhash', 'newpassword', 'currentpassword',
  'token', 'sid', 'cookie', 'authorization', 'secret', 'totp', 'totpsecret',
  'totp_secret', 'csrf', 'signature', 'card', 'pan', 'cvv', 'cvc',
  'lookup_token', 'lookuptoken', 'email', 'phone', 'street', 'building',
]);

function scrub(value, depth = 0) {
  if (depth > 6) return '[deep]';
  if (value == null) return value;
  if (Array.isArray(value)) return value.slice(0, 50).map((v) => scrub(v, depth + 1));
  if (value instanceof Error) {
    return { name: value.name, message: value.message, code: value.code };
  }
  if (typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = REDACT.has(k.toLowerCase()) ? '[redacted]' : scrub(v, depth + 1);
    }
    return out;
  }
  if (typeof value === 'string' && value.length > 2000) return `${value.slice(0, 2000)}…`;
  return value;
}

function emit(level, msg, fields) {
  if (LEVELS[level] < threshold) return;
  const line = JSON.stringify({
    t: new Date().toISOString(),
    level,
    msg: String(msg),
    ...(fields ? scrub(fields) : {}),
  });
  if (level === 'error' || level === 'warn') process.stderr.write(line + '\n');
  else process.stdout.write(line + '\n');
}

export const logger = {
  debug: (m, f) => emit('debug', m, f),
  info:  (m, f) => emit('info', m, f),
  warn:  (m, f) => emit('warn', m, f),
  error: (m, f) => emit('error', m, f),
};

export default logger;
