/**
 * Application errors.
 *
 * `AppError` carries a machine-readable `code` and an HTTP `status`. The
 * message is assumed to be safe to show a user; anything else (stack traces,
 * SQL text, file paths) is logged but never serialised into a response.
 */
export class AppError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.details = details;
    this.expose = true;
  }
}

export const badRequest   = (m = 'Invalid request', d) => new AppError(400, 'bad_request', m, d);
export const unauthorized = (m = 'Sign in to continue')  => new AppError(401, 'unauthorized', m);
export const forbidden    = (m = 'Not allowed')          => new AppError(403, 'forbidden', m);
export const notFound     = (m = 'Not found')            => new AppError(404, 'not_found', m);
export const conflict     = (m = 'Conflict', d)          => new AppError(409, 'conflict', m, d);
export const gone         = (m = 'No longer available')  => new AppError(410, 'gone', m);
export const tooLarge     = (m = 'Payload too large')    => new AppError(413, 'payload_too_large', m);
export const unprocessable= (m = 'Could not process', d) => new AppError(422, 'unprocessable', m, d);
export const tooMany      = (m = 'Too many requests', d) => new AppError(429, 'rate_limited', m, d);
export const serverError  = (m = 'Something went wrong') => new AppError(500, 'server_error', m);
