import { StringDecoder } from 'node:string_decoder';
import config from '../config.js';
import { badRequest, tooLarge } from './errors.js';

/* ------------------------------------------------------------------ *
 * Cookies                                                             *
 * ------------------------------------------------------------------ */

export function parseCookies(header) {
  const out = Object.create(null);
  if (!header) return out;
  for (const part of String(header).split(';')) {
    const eq = part.indexOf('=');
    if (eq === -1) continue;
    const key = part.slice(0, eq).trim();
    if (!key || key === '__proto__') continue;
    try {
      out[key] = decodeURIComponent(part.slice(eq + 1).trim());
    } catch {
      /* a malformed cookie is simply ignored */
    }
  }
  return out;
}

/**
 * Cookie defaults, and why:
 *   httpOnly  — script cannot read it, so an XSS cannot exfiltrate sessions
 *   secure    — never sent over plaintext (required by the __Host- prefix)
 *   sameSite  — Lax blocks cross-site POSTs, the CSRF precondition
 *   path=/    — required by the __Host- prefix; no Domain attribute, so the
 *               cookie cannot be scoped to (and stolen by) a sibling subdomain
 */
export function setCookie(res, name, value, opts = {}) {
  const {
    maxAgeMs,
    httpOnly = true,
    sameSite = 'Lax',
    path = '/',
    secure = config.isProd,
  } = opts;

  const bits = [`${name}=${encodeURIComponent(value)}`, `Path=${path}`, `SameSite=${sameSite}`];
  if (httpOnly) bits.push('HttpOnly');
  if (secure) bits.push('Secure');
  if (typeof maxAgeMs === 'number') {
    bits.push(`Max-Age=${Math.floor(maxAgeMs / 1000)}`);
    bits.push(`Expires=${new Date(Date.now() + maxAgeMs).toUTCString()}`);
  }

  const existing = res.getHeader('Set-Cookie');
  const list = existing ? (Array.isArray(existing) ? existing : [existing]) : [];
  list.push(bits.join('; '));
  res.setHeader('Set-Cookie', list);
}

export function clearCookie(res, name, opts = {}) {
  setCookie(res, name, '', { ...opts, maxAgeMs: 0 });
}

/* ------------------------------------------------------------------ *
 * Client address                                                      *
 * ------------------------------------------------------------------ */

/**
 * X-Forwarded-For is attacker-controlled unless a proxy you trust rewrites
 * it. TRUST_PROXY gates that, and only the *last* hop is taken — the one
 * appended by our own nginx — rather than the leftmost value a client can
 * pre-populate to evade rate limiting.
 */
export function clientIp(req) {
  if (config.trustProxy) {
    const xff = req.headers['x-forwarded-for'];
    if (typeof xff === 'string' && xff.length) {
      const hops = xff.split(',').map((s) => s.trim()).filter(Boolean);
      if (hops.length) return hops[hops.length - 1];
    }
  }
  return req.socket?.remoteAddress || '0.0.0.0';
}

/* ------------------------------------------------------------------ *
 * Body reading                                                        *
 * ------------------------------------------------------------------ */

function readRaw(req, limit) {
  return new Promise((resolve, reject) => {
    // Trust the declared length when it already exceeds the cap: refuse
    // before reading a single byte of the body.
    const declared = Number(req.headers['content-length']);
    if (Number.isFinite(declared) && declared > limit) {
      // Pause rather than destroy: destroying the socket here kills the
      // connection before the 413 can be written, and the client sees a
      // network error instead of a usable message.
      req.pause();
      reject(tooLarge());
      return;
    }

    const decoder = new StringDecoder('utf8');
    let text = '';
    let size = 0;
    let settled = false;

    const done = (err, value) => {
      if (settled) return;
      settled = true;
      req.removeAllListeners('data');
      req.removeAllListeners('end');
      req.removeAllListeners('error');
      if (err) reject(err);
      else resolve(value);
    };

    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        // Stop buffering immediately, but leave the socket alive long enough
        // for the 413 response to reach the client.
        req.pause();
        done(tooLarge());
        return;
      }
      text += decoder.write(chunk);
    });
    req.on('end', () => done(null, text + decoder.end()));
    req.on('error', () => done(badRequest('Could not read the request body')));
  });
}

export async function readJson(req, limit = config.limits.bodyBytes) {
  const type = String(req.headers['content-type'] || '');
  if (!type.includes('application/json')) {
    throw badRequest('Expected application/json');
  }
  const raw = await readRaw(req, limit);
  if (!raw.trim()) return {};
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw badRequest('Request body is not valid JSON');
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw badRequest('Request body must be a JSON object');
  }
  return parsed;
}

/** Raw body plus its exact bytes — webhook signatures are computed over the
 *  byte stream, so it must not be re-serialised before verification. */
export async function readRawBody(req, limit = config.limits.bodyBytes) {
  return readRaw(req, limit);
}

/* ------------------------------------------------------------------ *
 * Responses                                                           *
 * ------------------------------------------------------------------ */

export function sendJson(res, status, payload, headers = {}) {
  if (res.writableEnded) return;
  const body = JSON.stringify(payload ?? null);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    // API responses are per-user and must never land in a shared cache.
    'Cache-Control': 'no-store, private',
    ...headers,
  });
  res.end(body);
}

export function sendText(res, status, text, headers = {}) {
  if (res.writableEnded) return;
  const body = String(text);
  res.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(body);
}

export function redirect(res, location, status = 302) {
  res.writeHead(status, { Location: location, 'Cache-Control': 'no-store' });
  res.end();
}
