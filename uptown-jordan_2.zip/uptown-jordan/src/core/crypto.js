import {
  createHash,
  createHmac,
  randomBytes,
  randomUUID,
  scrypt as scryptCb,
  timingSafeEqual,
} from 'node:crypto';
import { promisify } from 'node:util';
import config from '../config.js';

const scrypt = promisify(scryptCb);

/* ------------------------------------------------------------------ *
 * Primitives                                                          *
 * ------------------------------------------------------------------ */

export const uuid = () => randomUUID();

/** URL-safe random token. 32 bytes = 256 bits of entropy. */
export function randomToken(bytes = 32) {
  return randomBytes(bytes).toString('base64url');
}

export const sha256 = (value) =>
  createHash('sha256').update(String(value), 'utf8').digest('hex');

export const hmac = (secret, value) =>
  createHmac('sha256', secret).update(String(value), 'utf8').digest('hex');

/**
 * Constant-time string comparison.
 *
 * timingSafeEqual throws on length mismatch — which would itself leak the
 * length — so both sides are hashed to a fixed width first.
 */
export function safeEqual(a, b) {
  const ha = createHash('sha256').update(String(a ?? ''), 'utf8').digest();
  const hb = createHash('sha256').update(String(b ?? ''), 'utf8').digest();
  return timingSafeEqual(ha, hb);
}

/** Pseudonymises an IP or user-agent for storage. Keyed, so not reversible
 *  by rainbow table, and truncated because only collision-resistance over a
 *  short horizon is needed. */
export const fingerprint = (value) =>
  hmac(config.secrets.session, `fp:${value ?? ''}`).slice(0, 32);

/* ------------------------------------------------------------------ *
 * Passwords — scrypt (memory-hard), peppered                          *
 *                                                                     *
 * Stored form:  scrypt$N$r$p$<salt b64url>$<hash b64url>              *
 *                                                                     *
 * The pepper is a server-side secret mixed in via HMAC before the KDF. *
 * It lives in the environment, not the database, so a dump of the      *
 * users table alone cannot be cracked offline.                         *
 * ------------------------------------------------------------------ */

const PW = config.password;

function pepper(password) {
  return createHmac('sha256', config.secrets.pepper)
    .update(String(password), 'utf8')
    .digest();
}

export async function hashPassword(password) {
  if (typeof password !== 'string') throw new TypeError('password must be a string');
  if (password.length > PW.maxLength) throw new Error('password too long');

  const salt = randomBytes(16);
  const derived = await scrypt(pepper(password), salt, PW.keyLen, {
    N: PW.N,
    r: PW.r,
    p: PW.p,
    maxmem: PW.maxmem,
  });

  return [
    'scrypt',
    PW.N,
    PW.r,
    PW.p,
    salt.toString('base64url'),
    derived.toString('base64url'),
  ].join('$');
}

export async function verifyPassword(password, stored) {
  if (typeof stored !== 'string') return false;
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;

  const N = Number(parts[1]);
  const r = Number(parts[2]);
  const p = Number(parts[3]);
  if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p)) return false;
  // Refuse absurd parameters from a tampered row rather than allocating GBs.
  if (N > 1 << 20 || r > 32 || p > 16) return false;

  let salt;
  let expected;
  try {
    salt = Buffer.from(parts[4], 'base64url');
    expected = Buffer.from(parts[5], 'base64url');
  } catch {
    return false;
  }
  if (!salt.length || !expected.length) return false;

  let derived;
  try {
    derived = await scrypt(pepper(password), salt, expected.length, {
      N,
      r,
      p,
      maxmem: Math.max(PW.maxmem, 128 * N * r * 2),
    });
  } catch {
    return false;
  }

  return derived.length === expected.length && timingSafeEqual(derived, expected);
}

/** True when a stored hash was made with weaker parameters than current
 *  policy — the caller silently upgrades it on next successful login. */
export function needsRehash(stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return true;
  return Number(parts[1]) < PW.N || Number(parts[2]) < PW.r || Number(parts[3]) < PW.p;
}

/**
 * Burns roughly the same CPU as a real verification.
 *
 * Called on login attempts for addresses that do not exist, so that
 * "no such user" and "wrong password" take indistinguishable time and the
 * endpoint cannot be used to enumerate which emails are registered.
 */
export async function fakeVerify() {
  await scrypt(pepper('decoy'), Buffer.alloc(16, 7), PW.keyLen, {
    N: PW.N,
    r: PW.r,
    p: PW.p,
    maxmem: PW.maxmem,
  });
  return false;
}

/* ------------------------------------------------------------------ *
 * TOTP (RFC 6238) — optional second factor for staff and admins       *
 * ------------------------------------------------------------------ */

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function base32Encode(buf) {
  let bits = 0;
  let value = 0;
  let out = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(str) {
  const clean = String(str).toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let value = 0;
  const out = [];
  for (const ch of clean) {
    const idx = B32.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export const newTotpSecret = () => base32Encode(randomBytes(20));

function totpAt(secretB32, counter) {
  const key = base32Decode(secretB32);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const digest = createHmac('sha1', key).update(buf).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const code =
    ((digest[offset] & 0x7f) << 24) |
    (digest[offset + 1] << 16) |
    (digest[offset + 2] << 8) |
    digest[offset + 3];
  return String(code % 1_000_000).padStart(6, '0');
}

/** Accepts the current step plus one on either side (±30s clock drift). */
export function verifyTotp(secretB32, token, now = Date.now()) {
  const candidate = String(token || '').replace(/\D/g, '');
  if (candidate.length !== 6) return false;
  const counter = Math.floor(now / 30_000);
  for (let drift = -1; drift <= 1; drift += 1) {
    if (safeEqual(totpAt(secretB32, counter + drift), candidate)) return true;
  }
  return false;
}

export function totpUri(secretB32, label, issuer = 'Uptown Jordan') {
  const l = encodeURIComponent(`${issuer}:${label}`);
  return `otpauth://totp/${l}?secret=${secretB32}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

/* ------------------------------------------------------------------ *
 * Identifiers                                                         *
 * ------------------------------------------------------------------ */

const ORDER_ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // no 0/O/1/I

/** UJ-YYMM-XXXXX — short enough to read over the phone, random enough
 *  that order numbers cannot be walked. */
export function orderNumber(date = new Date()) {
  const yy = String(date.getUTCFullYear()).slice(2);
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const bytes = randomBytes(5);
  let tail = '';
  for (const b of bytes) tail += ORDER_ALPHABET[b % ORDER_ALPHABET.length];
  return `UJ-${yy}${mm}-${tail}`;
}
