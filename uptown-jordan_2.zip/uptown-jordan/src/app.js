import config from './config.js';
import Router from './core/router.js';
import logger from './core/logger.js';
import { integrityCheck, migrate } from './db/index.js';
import { csrfProtection } from './middleware/csrf.js';
import { consume } from './middleware/ratelimit.js';
import securityHeaders from './middleware/security.js';
import { attachSession } from './middleware/session.js';
import { sendHtml, staticAssets } from './middleware/static.js';
import adminRoutes from './routes/admin.routes.js';
import authRoutes from './routes/auth.routes.js';
import pageRoutes from './routes/pages.js';
import paymentRoutes from './routes/payments.routes.js';
import storeRoutes from './routes/store.routes.js';

export async function createApp() {
  await migrate();

  const router = new Router();

  /* ----------------------------------------------------------- pipeline */

  router.use(securityHeaders());

  router.use(async (ctx, next) => {
    try {
      return await next();
    } finally {
      const ms = Date.now() - ctx.startedAt;
      if (ms > 500 || ctx.res.statusCode >= 500) {
        logger.warn('slow or failed request', {
          method: ctx.rawMethod, path: ctx.path, status: ctx.res.statusCode, ms,
        });
      } else {
        logger.debug('request', {
          method: ctx.rawMethod, path: ctx.path, status: ctx.res.statusCode, ms,
        });
      }
    }
  });

  router.use(attachSession());

  // The webhook authenticates by HMAC signature over its raw body, so it is
  // exempt from the cookie-based CSRF check (and could not satisfy it — a
  // payment provider has no cookie jar).
  router.use(csrfProtection({ exempt: ['/api/webhooks/'] }));

  // A blanket per-IP budget on the API surface. Individual endpoints layer
  // tighter, purpose-built limits on top (login, checkout, lookup).
  router.use(async (ctx, next) => {
    if (!ctx.path.startsWith('/api/') || ctx.path === '/api/healthz') return next();
    const [max, windowMs] = config.limits.api;
    const result = await consume('api', ctx.ip, max, windowMs);
    ctx.res.setHeader('RateLimit-Limit', String(max));
    ctx.res.setHeader('RateLimit-Remaining', String(result.remaining));
    if (!result.allowed) {
      const { tooMany } = await import('./core/errors.js');
      throw tooMany('Too many requests. Please slow down.', {
        retryAfterSeconds: result.retryAfterSeconds,
      });
    }
    return next();
  });

  /* ------------------------------------------------------------- health */

  router.get('/api/healthz', async () => {
    const health = await integrityCheck();
    return {
      ok: health.ok,
      env: config.env,
      time: new Date().toISOString(),
      database: { ok: health.ok, foreignKeyViolations: health.foreignKeyViolations },
    };
  });

  /* --------------------------------------------------------------- API */

  router.mount('/api', storeRoutes);
  router.mount('/api', authRoutes);
  router.mount('/api', paymentRoutes);
  router.mount('/api/admin', adminRoutes);

  /* ------------------------------------------------------------ static */

  router.get('/assets/*', staticAssets());

  router.get('/robots.txt', async (ctx) =>
    ctx.text(
      200,
      [
        'User-agent: *',
        'Allow: /$',
        'Allow: /shop',
        'Allow: /product/',
        'Allow: /about',
        'Allow: /size-guide',
        'Allow: /shipping-returns',
        'Allow: /faq',
        'Allow: /contact',
        'Disallow: /admin',
        'Disallow: /account',
        'Disallow: /cart',
        'Disallow: /checkout',
        'Disallow: /order',
        'Disallow: /pay/',
        'Disallow: /api/',
        `Sitemap: ${config.origin}/sitemap.xml`,
      ].join('\n'),
      { 'Cache-Control': 'public, max-age=86400' }
    )
  );

  router.get('/sitemap.xml', async (ctx) => {
    const { listProducts } = await import('./services/catalog.js');
    const { items } = await listProducts({ limit: 60 });
    const urls = [
      `${config.origin}/`,
      `${config.origin}/shop`,
      `${config.origin}/about`,
      `${config.origin}/size-guide`,
      `${config.origin}/shipping-returns`,
      `${config.origin}/faq`,
      `${config.origin}/contact`,
      ...items.map((p) => `${config.origin}/product/${p.slug}`),
    ];
    const xml =
      '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
      urls.map((u) => `  <url><loc>${u.replace(/&/g, '&amp;')}</loc></url>`).join('\n') +
      '\n</urlset>';
    ctx.res.writeHead(200, {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, max-age=3600',
    });
    ctx.res.end(xml);
  });

  /* -------------------------------------------------------------- pages */

  // Mounted last so that /api/* and /assets/* win any overlap.
  router.mount('', pageRoutes);

  /* ------------------------------------------------------------ 404s */

  const originalOnError = router.onError.bind(router);
  router.onError = (ctx, err) => {
    const wantsHtml =
      (ctx.req.headers.accept || '').includes('text/html') && !ctx.path.startsWith('/api/');
    if (wantsHtml && err?.status === 404) {
      sendHtml(ctx, '404.html', 404).catch(() => originalOnError(ctx, err));
      return;
    }
    originalOnError(ctx, err);
  };

  return router;
}

export default createApp;
