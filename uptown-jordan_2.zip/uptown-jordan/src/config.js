import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(fileURLToPath(import.meta.url), '../..');

/* ------------------------------------------------------------------ *
 * .env loading (no dotenv dependency). Real environment always wins.  *
 * ------------------------------------------------------------------ */
function loadEnvFile(file) {
  if (!existsSync(file)) return;
  const text = readFileSync(file, 'utf8');
  for (const rawLine of text.split('\n')) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = value;
  }
}
loadEnvFile(path.join(ROOT, '.env'));

const NODE_ENV = process.env.NODE_ENV || 'development';
const isProd = NODE_ENV === 'production';
const isTest = NODE_ENV === 'test';

function str(key, fallback) {
  const v = process.env[key];
  return v === undefined || v === '' ? fallback : v;
}
function int(key, fallback) {
  const v = process.env[key];
  if (v === undefined || v === '') return fallback;
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) throw new Error(`Env ${key} must be an integer`);
  return n;
}
function bool(key, fallback) {
  const v = process.env[key];
  if (v === undefined || v === '') return fallback;
  return v === '1' || v.toLowerCase() === 'true';
}

/* ------------------------------------------------------------------ *
 * Secrets                                                             *
 *                                                                     *
 * In production every secret must be supplied and be >= 32 chars —    *
 * the process refuses to boot otherwise, so a misconfigured deploy    *
 * fails loudly instead of silently running on a guessable key.        *
 * Outside production we generate ephemeral ones.                      *
 * ------------------------------------------------------------------ */
const secretProblems = [];
function secret(key) {
  const v = process.env[key];
  if (v && v.length >= 32) return v;
  if (isProd) {
    secretProblems.push(
      v ? `${key} is shorter than 32 characters` : `${key} is not set`
    );
    return randomBytes(32).toString('hex');
  }
  return v || randomBytes(32).toString('hex');
}

export const config = {
  env: NODE_ENV,
  isProd,
  isTest,

  host: str('HOST', '0.0.0.0'),
  port: int('PORT', 3000),

  /** Public origin, e.g. https://uptownjordan.com — used for absolute URLs,
   *  cookie scoping and strict Origin checking on state-changing requests. */
  origin: str('PUBLIC_ORIGIN', `http://localhost:${int('PORT', 3000)}`),

  /** Trust X-Forwarded-For. Only enable when a reverse proxy you control
   *  (the bundled nginx) sits in front — otherwise clients can spoof their
   *  IP and defeat rate limiting. */
  trustProxy: bool('TRUST_PROXY', isProd),

  db: {
    file: str('DATABASE_FILE', path.join(ROOT, 'data', 'uptown.db')),
    /** Prefer better-sqlite3 when installed; fall back to node:sqlite. */
    driver: str('DB_DRIVER', 'auto'),
  },

  secrets: {
    session: secret('SESSION_SECRET'),
    csrf: secret('CSRF_SECRET'),
    /** Peppers the password hash. Rotating it invalidates all passwords. */
    pepper: secret('PASSWORD_PEPPER'),
  },

  session: {
    cookie: isProd ? '__Host-uj_sid' : 'uj_sid',
    /** Absolute lifetime — a session dies at this age no matter what. */
    absoluteMs: int('SESSION_ABSOLUTE_HOURS', 24 * 14) * 3600_000,
    /** Idle lifetime — a session dies after this long without a request. */
    idleMs: int('SESSION_IDLE_HOURS', 24 * 3) * 3600_000,
  },

  cart: {
    cookie: isProd ? '__Host-uj_cart' : 'uj_cart',
    ttlMs: int('CART_TTL_DAYS', 30) * 86_400_000,
    maxLines: 40,
    maxQtyPerLine: 10,
  },

  csrf: {
    cookie: isProd ? '__Host-uj_csrf' : 'uj_csrf',
    header: 'x-csrf-token',
    ttlMs: 8 * 3600_000,
  },

  password: {
    /** scrypt cost. N must be a power of two. 2^15 ≈ 32 MB, ~100ms. */
    N: int('SCRYPT_N', 32768),
    r: int('SCRYPT_R', 8),
    p: int('SCRYPT_P', 1),
    keyLen: 32,
    /** Guards against scrypt's memory ceiling (128 * N * r bytes). */
    maxmem: int('SCRYPT_MAXMEM', 128 * 32768 * 8 * 3),
    minLength: 10,
    maxLength: 200,
  },

  store: {
    name: 'Uptown Jordan',
    currency: 'JOD',
    /** Minor unit: Jordanian dinar has 3 decimal places (1 JOD = 1000 fils).
     *  Every amount in this codebase is an integer number of fils. */
    currencyScale: 1000,
    freeShippingThreshold: int('FREE_SHIPPING_FILS', 50_000), // 50.000 JOD
    defaultShippingFils: int('SHIPPING_FILS', 3_000), // 3.000 JOD
    codSurchargeFils: int('COD_SURCHARGE_FILS', 0),
    taxRateBps: int('TAX_RATE_BPS', 0), // basis points; 1600 = 16% GST
    maxOrderValueFils: int('MAX_ORDER_VALUE_FILS', 5_000_000),
    supportWhatsapp: str('SUPPORT_WHATSAPP', '962790000000'),
  },

  payments: {
    /** 'mock' ships a working hosted-checkout simulator so the full
     *  redirect + webhook flow is exercisable without a merchant account.
     *  Swap for a real provider in src/services/payments.js. */
    provider: str('PAYMENT_PROVIDER', 'mock'),
    webhookSecret: secret('PAYMENT_WEBHOOK_SECRET'),
    /** Reject webhooks whose signed timestamp is older than this. */
    webhookToleranceMs: int('PAYMENT_WEBHOOK_TOLERANCE_SECONDS', 300) * 1000,
    intentTtlMs: int('PAYMENT_INTENT_TTL_MINUTES', 30) * 60_000,
  },

  limits: {
    /** Max request body. Deliberately small: nothing here needs more. */
    bodyBytes: int('MAX_BODY_BYTES', 64 * 1024),
    /** Per-IP budgets: [max requests, window ms] */
    api: [int('RL_API_MAX', 300), 60_000],
    auth: [int('RL_AUTH_MAX', 8), 15 * 60_000],
    register: [int('RL_REGISTER_MAX', 5), 60 * 60_000],
    checkout: [int('RL_CHECKOUT_MAX', 15), 60 * 60_000],
    webhook: [int('RL_WEBHOOK_MAX', 240), 60_000],
    admin: [int('RL_ADMIN_MAX', 600), 60_000],
  },

  /** Image origin used by the storefront. Pinned in the CSP. */
  assetOrigin: str(
    'ASSET_ORIGIN',
    'https://d8j0ntlcm91z4.cloudfront.net'
  ),

  logLevel: str('LOG_LEVEL', isTest ? 'silent' : isProd ? 'info' : 'debug'),
};

if (secretProblems.length) {
  console.error(
    '\nFATAL: refusing to start in production with unsafe secrets:\n' +
      secretProblems.map((p) => `  - ${p}`).join('\n') +
      '\n\nGenerate one with:  node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"\n'
  );
  process.exit(1);
}

if (isProd && !config.origin.startsWith('https://')) {
  console.error(
    '\nFATAL: PUBLIC_ORIGIN must be an https:// URL in production.\n' +
      'Secure cookies and the __Host- prefix require TLS.\n'
  );
  process.exit(1);
}

export default config;
