import { $, api, ApiError, el, formatDate, onSubmit, refreshBag, render, shot, toast } from './app.js';
import { ratingLine, stars } from './stars.js';

const host = $('[data-product]');
const errorBox = $('[data-error]');
const slug = decodeURIComponent(location.pathname.split('/').filter(Boolean).pop() || '');

let selectedVariant = null;

function gallery(product) {
  const main = el('div', {
    style: 'position:relative;aspect-ratio:3/4;border-radius:18px;overflow:hidden;border:1px solid var(--hair-2);background:linear-gradient(150deg,#1d2836,#121922 60%,#1b1524)',
  });
  const img = product.images[0] ? shot(product.images[0].url, product.images[0].alt) : el('div');
  img.style.width = '100%';
  img.style.height = '100%';
  img.style.objectFit = 'cover';
  main.append(img);

  const thumbs = product.images.length > 1
    ? el('div', { style: 'display:flex;gap:10px;margin-top:12px;flex-wrap:wrap' },
        product.images.map((image, i) =>
          el('button', {
            type: 'button',
            'aria-label': `View image ${i + 1}`,
            style: 'width:72px;aspect-ratio:3/4;border-radius:10px;overflow:hidden;border:1px solid var(--hair-2);background:#101722;cursor:pointer;padding:0',
            onclick: () => {
              img.src = image.url;
              img.alt = image.alt || product.title;
            },
          }, shot(image.url, image.alt))
        ))
    : null;

  return el('div', [main, thumbs]);
}

function sizePicker(product, onPick, onSoldOut) {
  const buttons = product.variants.map((variant) =>
    el('button.chip', {
      type: 'button',
      'aria-pressed': 'false',
      dataset: { variant: variant.id },
      // A sold-out size stays clickable on purpose — clicking it offers a
      // restock alert instead of the add-to-bag button. A disabled control
      // would be a dead end for the customer most likely to want the piece.
      style: variant.inStock ? '' : 'opacity:.45;text-decoration:line-through',
      onclick: (event) => {
        for (const node of event.currentTarget.parentElement.children) {
          node.setAttribute('aria-pressed', 'false');
        }
        event.currentTarget.setAttribute('aria-pressed', 'true');
        if (variant.inStock) onPick(variant);
        else onSoldOut(variant);
      },
    }, variant.size)
  );
  return el('div', { style: 'display:flex;flex-wrap:wrap;gap:9px' }, buttons);
}

/** Inline restock-alert form, shown when a sold-out size is selected. */
function notifyForm(product, variant, host) {
  const form = el('form', { style: 'margin-top:14px' }, [
    el('p', { style: 'font-size:13px;color:var(--muted);margin-bottom:10px' },
      `${variant.size} is sold out. Leave your email and we'll tell you the moment it's back — nothing else gets sent there.`),
    el('div', { style: 'display:flex;gap:8px' }, [
      el('input', {
        type: 'email', name: 'email', required: true, autocomplete: 'email',
        placeholder: 'you@example.com', 'aria-label': `Notify me when ${variant.size} is back`,
        style: 'flex:1;min-width:0',
      }),
      el('button.btn.sm', { type: 'submit' }, 'Notify me'),
    ]),
    el('div.notice.error', { 'data-error': '', hidden: true, style: 'margin-top:10px' }),
  ]);

  render(host, form);

  onSubmit(form, async (values) => {
    const result = await api.post(`/api/variants/${variant.id}/notify-me`, { email: values.email });
    render(host, el('div.notice.ok', { style: 'margin-top:14px' }, result.message));
  });
}

function details(product) {
  const stockNote = el('p', { style: 'font-size:12.5px;color:var(--muted-2);min-height:18px' }, '');
  const addButton = el('button.btn.block', { type: 'button', disabled: true }, 'Select a size');
  const notifyHost = el('div');

  const pick = (variant) => {
    selectedVariant = variant;
    render(notifyHost, []);
    addButton.hidden = false;
    addButton.disabled = false;
    addButton.textContent = `Add to bag — ${variant.price} JOD`;
    stockNote.textContent = variant.lowStock
      ? `Only ${variant.maxQty} left in ${variant.size}.`
      : 'In stock · ships in 1–3 days';
  };

  const soldOut = (variant) => {
    selectedVariant = null;
    addButton.hidden = true;
    stockNote.textContent = '';
    notifyForm(product, variant, notifyHost);
  };

  addButton.addEventListener('click', async () => {
    if (!selectedVariant) return;
    addButton.disabled = true;
    const label = addButton.textContent;
    addButton.textContent = 'Adding…';
    try {
      const result = await api.post('/api/cart/items', { variantId: selectedVariant.id, qty: 1 });
      await refreshBag();
      toast(result.message || `${product.title} added to your bag.`, 'ok');
      addButton.textContent = 'Added ✓';
      setTimeout(() => {
        addButton.textContent = label;
        addButton.disabled = false;
      }, 1400);
    } catch (err) {
      toast(err instanceof ApiError ? err.message : 'Could not add that to your bag.', 'error');
      addButton.textContent = label;
      addButton.disabled = false;
    }
  });

  const facts = [
    product.material && ['Material', product.material],
    product.care && ['Care', product.care],
    product.collection && ['Collection', product.collection.title],
  ].filter(Boolean);

  return el('div', [
    product.badge ? el('span.tag', { style: 'position:static;display:inline-block;margin-bottom:14px' }, product.badge) : null,
    el('h1.display', { style: 'font-size:clamp(26px,4vw,40px)' }, product.title),
    el('p', { style: 'color:var(--muted);margin-top:8px' }, product.subtitle || ''),

    // Only rendered once real customers have reviewed the piece.
    product.rating?.count
      ? el('a', {
          href: '#reviews',
          style: 'display:inline-block;margin-top:12px',
        }, ratingLine(product.rating))
      : null,

    el('div', { style: 'display:flex;align-items:baseline;gap:12px;margin:22px 0 6px' }, [
      el('span', { style: 'font-size:26px;font-weight:800' }, `${product.price} JOD`),
      product.compareAt ? el('s', { style: 'color:var(--muted-2)' }, `${product.compareAt} JOD`) : null,
      product.discountPercent ? el('span.tag.sale', { style: 'position:static' }, `-${product.discountPercent}%`) : null,
    ]),
    el('p', { style: 'font-size:12.5px;color:var(--muted-2)' }, 'Inclusive of all taxes'),

    el('div', {
      style: 'margin:26px 0 12px;display:flex;align-items:baseline;justify-content:space-between;gap:12px',
    }, [
      el('span', { style: 'font-size:12px;letter-spacing:.18em;text-transform:uppercase;color:var(--muted-2)' }, 'Size'),
      el('a.link', { href: '/size-guide', style: 'font-size:12.5px' }, 'Size guide'),
    ]),
    product.variants.length
      ? sizePicker(product, pick, soldOut)
      : el('p', { style: 'color:var(--muted)' }, 'Currently unavailable.'),
    stockNote,
    notifyHost,

    el('div', { style: 'margin-top:20px;display:flex;flex-direction:column;gap:10px' }, [
      addButton,
      el('a.btn-ghost', { href: '/cart', style: 'text-align:center' }, 'View bag'),
    ]),

    el('p', { style: 'margin-top:26px;color:var(--muted);font-size:14px;line-height:1.7' }, product.description || ''),

    facts.length
      ? el('dl', { style: 'margin-top:24px;display:grid;gap:12px;border-top:1px solid var(--hair-2);padding-top:22px' },
          facts.map(([k, v]) =>
            el('div', { style: 'display:grid;grid-template-columns:110px 1fr;gap:12px;font-size:13.5px' }, [
              el('dt', { style: 'color:var(--muted-2)' }, k),
              el('dd', { style: 'color:var(--muted)' }, v),
            ])
          ))
      : null,

    el('div.notice', { style: 'margin-top:22px' },
      'Free delivery on orders over 50.000 JOD · Cash on delivery available · 14-day exchange'),
  ]);
}

/* ---------------------------------------------------------------- reviews */

function distributionBars(distribution, total) {
  return el('div.bars', [5, 4, 3, 2, 1].map((score) => {
    const n = distribution[score] || 0;
    const pct = total ? Math.round((n / total) * 100) : 0;
    return el('div.bar', [
      el('span', { style: 'width:12px' }, String(score)),
      el('div.track', el('div.fill-bar', { style: `width:${pct}%` })),
      el('span', { style: 'width:26px;text-align:right' }, String(n)),
    ]);
  }));
}

function reviewItem(review) {
  return el('article.review', [
    el('div.top', [
      stars(review.rating),
      review.title ? el('b', review.title) : null,
    ]),
    el('div.top', { style: 'margin-bottom:10px' }, [
      el('span.who', review.author),
      review.sizeBought ? el('span.who', `· bought ${review.sizeBought}`) : null,
      el('span.who', `· ${formatDate(review.createdAt).split(',')[0]}`),
      el('span.verified', [
        el('span', { 'aria-hidden': 'true' }, '\u2713'),
        'Verified purchase',
      ]),
    ]),
    el('p', review.body),
  ]);
}

/**
 * The write-a-review panel.
 *
 * Only offered to signed-in customers whose order for this piece has been
 * delivered — the server enforces that independently, so this is a
 * convenience, not the control.
 */
function reviewForm(product, onDone) {
  const form = el('form.panel', { style: 'margin-top:26px' }, [
    el('h3', { style: 'font-size:15px;font-weight:600;margin-bottom:16px' },
      `Review ${product.title}`),
    el('div.notice.error', { 'data-error': '', hidden: true }),

    el('div.field', [
      el('label', { for: 'rv-rating' }, 'Your rating'),
      el('select', { id: 'rv-rating', name: 'rating', required: true }, [
        el('option', { value: '5' }, '5 — excellent'),
        el('option', { value: '4' }, '4 — good'),
        el('option', { value: '3' }, '3 — fine'),
        el('option', { value: '2' }, '2 — disappointing'),
        el('option', { value: '1' }, '1 — poor'),
      ]),
    ]),
    el('div.field', [
      el('label', { for: 'rv-title' }, 'Headline'),
      el('input', { id: 'rv-title', name: 'title', required: true, maxlength: '90',
        placeholder: 'Sums it up in a few words' }),
    ]),
    el('div.field', [
      el('label', { for: 'rv-body' }, 'Your review'),
      el('textarea', { id: 'rv-body', name: 'body', rows: '5', required: true,
        minlength: '10', maxlength: '1500',
        placeholder: 'How does it fit? How does the fabric feel after a wash? What would you tell a friend?' }),
    ]),
    el('button.btn.block', { type: 'submit' }, 'Submit review'),
    el('p', { style: 'margin-top:12px;font-size:12px;color:var(--muted-2);text-align:center' },
      'Published under your first name and last initial, once read.'),
  ]);

  onSubmit(form, async (values) => {
    const result = await api.post(`/api/products/${encodeURIComponent(product.slug)}/reviews`, {
      rating: Number(values.rating),
      title: values.title,
      body: values.body,
    });
    onDone(result.message);
  });

  return form;
}

async function loadReviews(product) {
  const host = $('[data-reviews-body]');

  let data;
  try {
    ({ reviews: data } = await api.get(`/api/products/${encodeURIComponent(product.slug)}/reviews`));
  } catch {
    host.setAttribute('aria-busy', 'false');
    render(host, el('p', { style: 'color:var(--muted-2)' }, 'Reviews could not be loaded.'));
    return;
  }

  host.setAttribute('aria-busy', 'false');

  const summary = data.count
    ? el('div', {
        style: 'display:flex;gap:40px;flex-wrap:wrap;align-items:center;padding-bottom:22px;border-bottom:1px solid var(--hair-2)',
      }, [
        el('div', [
          el('div', { style: 'font-size:38px;font-weight:800;letter-spacing:-.02em;line-height:1' },
            data.average.toFixed(1)),
          el('div', { style: 'margin-top:8px' }, stars(data.average, { size: 'lg' })),
          el('div', { style: 'margin-top:6px;font-size:12.5px;color:var(--muted-2)' },
            `${data.count} ${data.count === 1 ? 'review' : 'reviews'}`),
        ]),
        distributionBars(data.distribution, data.count),
      ])
    : el('div.empty', { style: 'padding:30px 0;text-align:left' }, [
        el('h3', { style: 'font-size:18px' }, 'No reviews yet'),
        el('p', { style: 'max-width:46ch' },
          'This piece has not been reviewed. Only customers whose order has been delivered can leave one, so these build up slowly — and every one you see here is real.'),
      ]);

  const list = data.items.length
    ? el('div', { style: 'margin-top:8px' }, data.items.map(reviewItem))
    : null;

  render(host, [summary, list]);

  /* Can the person reading this actually write one? */
  try {
    const { user } = await api.get('/api/me');
    if (!user) {
      host.append(
        el('p', { style: 'margin-top:24px;font-size:13.5px;color:var(--muted-2)' }, [
          'Bought this piece? ',
          el('a.link', { href: `/login?next=${encodeURIComponent(location.pathname)}` }, 'Sign in'),
          ' to leave a review.',
        ])
      );
      return;
    }

    const { items } = await api.get('/api/account/reviewable');
    const eligible = items.some((i) => i.slug === product.slug);

    if (eligible) {
      host.append(reviewForm(product, (message) => {
        render(host, [summary, list, el('div.notice.ok', { style: 'margin-top:24px' }, message)]);
      }));
    } else {
      host.append(
        el('p', { style: 'margin-top:24px;font-size:13.5px;color:var(--muted-2)' },
          'Reviews are open to customers who have received this piece. Once your order is delivered, the form appears here.')
      );
    }
  } catch {
    /* the reviews themselves still render */
  }
}

function relatedCard(p) {
  return el('a.card', { href: `/product/${p.slug}` }, [
    el('div.shot', p.image ? shot(p.image.url, p.image.alt) : null),
    el('div.meta', [el('b', p.title), el('div.price', `${p.price} JOD`)]),
  ]);
}

(async function load() {
  try {
    const { product, related } = await api.get(`/api/products/${encodeURIComponent(slug)}`);

    document.title = `${product.title} — Uptown Jordan`;
    $('[data-crumb]').textContent = product.title;

    host.setAttribute('aria-busy', 'false');
    render(host, [gallery(product), details(product)]);

    loadReviews(product);

    if (related?.length) {
      render($('[data-related-grid]'), related.map(relatedCard));
      $('[data-related]').hidden = false;
    }
  } catch (err) {
    host.setAttribute('aria-busy', 'false');
    render(host, []);
    errorBox.textContent = err instanceof ApiError ? err.message : 'Could not load this piece.';
    errorBox.hidden = false;
    $('[data-crumb]').textContent = 'Not found';
  }
})();
