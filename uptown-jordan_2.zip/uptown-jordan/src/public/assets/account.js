import { $, api, ApiError, el, formatDate, onSubmit, render, shot, toast } from './app.js';

const ordersHost = $('[data-orders]');
const addressHost = $('[data-addresses]');
const totpHost = $('[data-totp]');

function requireSignIn() {
  location.href = `/login?next=${encodeURIComponent('/account')}`;
}

function orderRow(order) {
  return el('a', {
    href: `/order?number=${encodeURIComponent(order.number)}`,
    style: 'display:flex;gap:14px;align-items:center;justify-content:space-between;padding:15px 0;border-bottom:1px solid var(--hair-2)',
  }, [
    el('div', [
      el('b', { style: 'font-size:14px' }, order.number),
      el('div', { style: 'font-size:12.5px;color:var(--muted-2)' }, formatDate(order.placedAt)),
    ]),
    el('div', { style: 'display:flex;gap:14px;align-items:center' }, [
      el(`span.state.${order.status}`, order.status),
      el('b', { style: 'font-size:14px' }, `${order.total} JOD`),
    ]),
  ]);
}

function addressCard(address, reload) {
  return el('div', {
    style: 'padding:14px;border:1px solid var(--hair-2);border-radius:12px;font-size:13px;color:var(--muted)',
  }, [
    el('div', { style: 'display:flex;justify-content:space-between;gap:10px;align-items:start' }, [
      el('b', { style: 'color:#fff;font-size:13.5px' }, address.label || address.city),
      address.isDefault ? el('span.tag', { style: 'position:static' }, 'DEFAULT') : null,
    ]),
    el('div', { style: 'margin-top:6px;line-height:1.7' }, [
      address.fullName, el('br'),
      address.street, el('br'),
      `${address.city}, ${address.governorate}`,
    ]),
    el('button.btn-ghost.sm', {
      type: 'button',
      style: 'margin-top:12px',
      onclick: async () => {
        try {
          await api.delete(`/api/account/addresses/${address.id}`);
          toast('Address removed.', 'ok');
          reload();
        } catch (err) {
          toast(err instanceof ApiError ? err.message : 'Could not remove that address.', 'error');
        }
      },
    }, 'Remove'),
  ]);
}

function totpPanel(user, reload) {
  if (user.totpEnabled) {
    return el('div', [
      el('p', { style: 'font-size:13.5px;color:var(--muted);margin-bottom:12px' },
        'Two-factor authentication is on for this account.'),
      el('button.btn-ghost.sm.block.danger', {
        type: 'button',
        onclick: async () => {
          const password = prompt('Confirm your password to turn off two-factor:');
          if (!password) return;
          try {
            await api.post('/api/account/totp/disable', { password });
            toast('Two-factor turned off.', 'ok');
            reload();
          } catch (err) {
            toast(err instanceof ApiError ? err.message : 'Could not turn that off.', 'error');
          }
        },
      }, 'Turn off two-factor'),
    ]);
  }

  return el('div', [
    el('p', { style: 'font-size:13.5px;color:var(--muted);margin-bottom:12px' },
      'Add a second factor with any authenticator app.'),
    el('button.btn-ghost.sm.block', {
      type: 'button',
      onclick: async (event) => {
        event.currentTarget.disabled = true;
        try {
          const { secret, uri } = await api.post('/api/account/totp/start', {});
          const form = el('form', { style: 'margin-top:14px' }, [
            el('p', { style: 'font-size:12.5px;color:var(--muted-2);margin-bottom:8px' },
              'Add this key to your authenticator app, then enter the code it shows.'),
            el('code', {
              style: 'display:block;padding:10px;border-radius:8px;background:rgba(6,9,14,.7);border:1px solid var(--hair-2);font-size:12px;word-break:break-all;margin-bottom:12px',
            }, secret),
            el('a.link', { href: uri, style: 'font-size:12.5px;display:inline-block;margin-bottom:12px' }, 'Open in your authenticator app'),
            el('div.field', [
              el('label', { for: 'totp-enable' }, 'Code'),
              el('input', { id: 'totp-enable', name: 'code', inputmode: 'numeric', maxlength: '6', required: true }),
            ]),
            el('div.notice.error', { 'data-error': '', hidden: true }),
            el('button.btn.sm.block', { type: 'submit' }, 'Turn on two-factor'),
          ]);
          render(totpHost, form);
          onSubmit(form, async (values) => {
            await api.post('/api/account/totp/enable', { code: values.code });
            toast('Two-factor is on.', 'ok');
            reload();
          });
        } catch (err) {
          toast(err instanceof ApiError ? err.message : 'Could not start set-up.', 'error');
          event.currentTarget.disabled = false;
        }
      },
    }, 'Set up two-factor'),
  ]);
}

async function loadGovernorates() {
  const select = $('#ad-gov');
  if (select.options.length > 1) return;
  const { governorates } = await api.get('/api/config');
  for (const gov of governorates) select.append(el('option', { value: gov.code }, gov.name));
}

async function load() {
  let data;
  try {
    data = await api.get('/api/account');
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) return requireSignIn();
    $('[data-error]').textContent = 'Could not load your account.';
    $('[data-error]').hidden = false;
    return;
  }

  const { user, addresses } = data;
  $('[data-greeting]').textContent = user.fullName ? `Hello, ${user.fullName.split(' ')[0]}` : 'Your account';
  $('#acc-name').value = user.fullName || '';
  $('#acc-phone').value = user.phone || '';

  render(addressHost, addresses.length
    ? addresses.map((a) => addressCard(a, load))
    : el('p', { style: 'font-size:13px;color:var(--muted-2)' }, 'No saved addresses yet.'));

  render(totpHost, totpPanel(user, load));

  ordersHost.setAttribute('aria-busy', 'true');
  try {
    const { orders } = await api.get('/api/account/orders');
    ordersHost.setAttribute('aria-busy', 'false');
    render(ordersHost, orders.length
      ? orders.map(orderRow)
      : el('div.empty', { style: 'padding:40px 10px' }, [
          el('h3', 'No orders yet'),
          el('a.btn.sm', { href: '/shop', style: 'margin-top:16px' }, 'Start shopping'),
        ]));
  } catch {
    ordersHost.setAttribute('aria-busy', 'false');
    render(ordersHost, el('p', { style: 'color:var(--muted-2)' }, 'Could not load your orders.'));
  }

  await loadGovernorates();
  await loadReviewable();
}

/**
 * Pieces this customer has received but not yet reviewed.
 *
 * The list comes from delivered orders, so the prompt only ever appears for
 * something they actually own.
 */
async function loadReviewable() {
  try {
    const { items } = await api.get('/api/account/reviewable');
    if (!items.length) return;

    render($('[data-reviewable]'), items.slice(0, 4).map((item) =>
      el('a', {
        href: `/product/${item.slug}#reviews`,
        style: 'display:flex;gap:12px;align-items:center;padding:10px;border:1px solid var(--hair-2);border-radius:12px;transition:border-color .2s',
      }, [
        el('div', {
          style: 'width:44px;aspect-ratio:3/4;border-radius:7px;overflow:hidden;background:#131a24;flex:0 0 auto',
        }, shot(item.imageUrl, item.title)),
        el('div', { style: 'flex:1;min-width:0' }, [
          el('div', { style: 'font-size:13.5px;font-weight:600' }, item.title),
          el('div', { style: 'font-size:12px;color:var(--muted-2)' },
            item.sizeBought ? `Size ${item.sizeBought}` : 'Delivered'),
        ]),
        el('span.link', { style: 'font-size:12.5px;flex:0 0 auto' }, 'Review'),
      ])
    ));
    $('[data-review-prompt]').hidden = false;
  } catch {
    /* the rest of the account page is unaffected */
  }
}

onSubmit($('#profile-form'), async (values) => {
  await api.patch('/api/account', values);
  toast('Details saved.', 'ok');
  load();
});

onSubmit($('#address-form'), async (values) => {
  await api.post('/api/account/addresses', values);
  toast('Address saved.', 'ok');
  $('#address-form').reset();
  load();
});

onSubmit($('#password-form'), async (values) => {
  await api.post('/api/account/password', values);
  toast('Password changed. Other devices were signed out.', 'ok');
  $('#password-form').reset();
});

$('[data-logout]').addEventListener('click', async () => {
  try {
    await api.post('/api/logout', {});
  } finally {
    location.href = '/';
  }
});

load();
