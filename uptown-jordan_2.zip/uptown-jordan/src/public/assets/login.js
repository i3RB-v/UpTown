import { $, $$, api, onSubmit, refreshBag, toast } from './app.js';

const params = new URLSearchParams(location.search);
const next = params.get('next');
const TITLES = {
  login: 'Sign in',
  register: 'Create an account',
  forgot: 'Reset your password',
  reset: 'Choose a new password',
  totp: 'Two-factor verification',
};

function show(panel) {
  for (const node of $$('[data-panel]')) node.hidden = node.dataset.panel !== panel;
  $('[data-title]').textContent = TITLES[panel] || 'Sign in';
  const firstField = $(`[data-panel="${panel}"] input`);
  if (firstField) firstField.focus();
}

for (const button of $$('[data-show]')) {
  button.addEventListener('click', () => show(button.dataset.show));
}

function flash(message) {
  const box = $('[data-flash]');
  box.textContent = message;
  box.hidden = false;
}

/** Only ever redirect to a path on this site — never to an attacker's URL. */
function safeNext() {
  if (!next) return '/account';
  if (!next.startsWith('/') || next.startsWith('//')) return '/account';
  return next;
}

onSubmit($('#login-form'), async (values) => {
  const result = await api.post('/api/login', values);
  if (result.mfaRequired) {
    show('totp');
    return;
  }
  await refreshBag();
  location.href = safeNext();
});

onSubmit($('#totp-form'), async (values) => {
  await api.post('/api/login/totp', { code: values.code });
  await refreshBag();
  location.href = safeNext();
});

onSubmit($('#register-form'), async (values) => {
  const result = await api.post('/api/register', values);
  if (result.user) {
    await refreshBag();
    location.href = safeNext();
    return;
  }
  // The address already had an account. The server says nothing either way,
  // so neither do we.
  show('login');
  flash('Check your email to continue — if that address has an account, we have sent it a link.');
});

onSubmit($('#forgot-form'), async (values) => {
  const result = await api.post('/api/password/forgot', values);
  show('login');
  flash('If that address has an account, a reset link is on its way.');
  if (result?.devResetToken) {
    toast('Development mode: reset link opened below.', 'ok');
    history.replaceState(null, '', `/login?reset=${encodeURIComponent(result.devResetToken)}`);
    setTimeout(() => show('reset'), 400);
  }
});

onSubmit($('#reset-form'), async (values) => {
  const token = new URLSearchParams(location.search).get('reset');
  await api.post('/api/password/reset', { token, password: values.password });
  history.replaceState(null, '', '/login');
  show('login');
  flash('Your password is updated. Sign in with it now.');
});

(async function init() {
  if (params.get('reset')) {
    show('reset');
    return;
  }
  if (params.get('register') !== null) {
    show('register');
    return;
  }
  try {
    const { user } = await api.get('/api/me');
    if (user && user.mfaSatisfied !== false) {
      location.href = safeNext();
      return;
    }
  } catch {
    /* not signed in */
  }
  show('login');
})();
