/**
 * Shared storefront runtime.
 *
 * One rule governs everything in here: **no server-supplied value is ever
 * assigned to innerHTML**. Every piece of dynamic content is written with
 * textContent or set as an attribute through `el()`. That is what makes the
 * strict, nonce-based CSP a second line of defence rather than the only one.
 */

/* ------------------------------------------------------------------ DOM */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const BOOLEAN_ATTRS = new Set(['disabled', 'hidden', 'checked', 'selected', 'required']);

/**
 * Build an element.
 *   el('b.price', 'Text')
 *   el('a', { href: '/shop', 'aria-label': 'Shop' }, ['child', el('span', 'x')])
 *
 * Children that are strings become text nodes — never parsed as markup.
 */
export function el(spec, attrs, children) {
  const [tagPart, ...classes] = String(spec).split('.');
  const node = document.createElement(tagPart || 'div');
  if (classes.length) node.className = classes.join(' ');

  // A Node passed in the second position is a child, not an attribute bag.
  // Without this check `el('td', el('a'))` silently drops the anchor, because
  // a DOM element has no own enumerable properties to iterate.
  if (
    attrs != null &&
    typeof attrs === 'object' &&
    !Array.isArray(attrs) &&
    !(attrs instanceof Node)
  ) {
    for (const [key, value] of Object.entries(attrs)) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = String(value);
      else if (key === 'dataset') Object.assign(node.dataset, value);
      else if (key.startsWith('on') && typeof value === 'function') {
        node.addEventListener(key.slice(2).toLowerCase(), value);
      } else if (BOOLEAN_ATTRS.has(key)) {
        if (value) node.setAttribute(key, '');
      } else {
        node.setAttribute(key, String(value));
      }
    }
  } else if (attrs != null) {
    children = attrs;
  }

  const kids = Array.isArray(children) ? children : children == null ? [] : [children];
  for (const kid of kids) {
    if (kid == null || kid === false) continue;
    node.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return node;
}

export function clear(node) {
  while (node.firstChild) node.removeChild(node.firstChild);
  return node;
}

/** Replace a container's contents with freshly built nodes. */
export function render(node, children) {
  clear(node);
  const kids = Array.isArray(children) ? children : [children];
  for (const kid of kids) if (kid != null && kid !== false) node.append(kid);
  return node;
}

/* ------------------------------------------------------------------ API */

function readCookie(name) {
  const match = document.cookie.match(
    new RegExp(`(?:^|; )${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}=([^;]*)`)
  );
  return match ? decodeURIComponent(match[1]) : null;
}

const CSRF_COOKIES = ['__Host-uj_csrf', 'uj_csrf'];
const csrfToken = () => CSRF_COOKIES.map(readCookie).find(Boolean) || '';

export class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function request(method, path, body, options = {}) {
  const headers = { Accept: 'application/json', ...options.headers };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET') {
    const token = csrfToken();
    if (token) headers['x-csrf-token'] = token;
  }

  let res;
  try {
    res = await fetch(path, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
    });
  } catch {
    throw new ApiError(0, 'network', 'Could not reach the store. Check your connection.');
  }

  if (res.status === 204) return null;

  let payload = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }

  if (!res.ok) {
    const err = payload?.error ?? {};
    // A stale CSRF token is recoverable — refresh it once and retry, so a
    // long-open tab does not hand the customer a dead button.
    if (res.status === 403 && err.code === 'forbidden' && !options.retried) {
      await fetch('/api/csrf', { credentials: 'same-origin' });
      return request(method, path, body, { ...options, retried: true });
    }
    throw new ApiError(res.status, err.code || 'error', err.message || 'Something went wrong.', err.details);
  }

  return payload;
}

export const api = {
  get: (p, o) => request('GET', p, undefined, o),
  post: (p, b, o) => request('POST', p, b, o),
  patch: (p, b, o) => request('PATCH', p, b, o),
  delete: (p, b, o) => request('DELETE', p, b, o),
};

/* --------------------------------------------------------------- toasts */

let toastHost = null;

export function toast(message, kind = '') {
  if (!toastHost) {
    toastHost = el('div.toasts', { role: 'status', 'aria-live': 'polite' });
    document.body.append(toastHost);
  }
  const node = el(`div.toast${kind ? ` ${kind}` : ''}`, String(message));
  toastHost.append(node);
  setTimeout(() => {
    node.style.transition = 'opacity .3s, transform .3s';
    node.style.opacity = '0';
    node.style.transform = 'translateY(8px)';
    setTimeout(() => node.remove(), 320);
  }, 4200);
}

/* ----------------------------------------------------------------- misc */

export const money = (value) => String(value ?? '0.000');

export function formatDate(ms) {
  if (!ms) return '';
  return new Intl.DateTimeFormat('en-GB', {
    day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
  }).format(new Date(ms));
}

/** Product image with a graceful fallback when the CDN is unreachable. */
export function shot(url, alt) {
  const img = el('img', { src: url || '', alt: alt || '', loading: 'lazy', decoding: 'async' });
  img.addEventListener('error', () => img.classList.add('failed'));
  return img;
}

/* ------------------------------------------------------------ cart badge */

const BAG_KEY = 'uj_bag_count';

export function setBagCount(count) {
  const n = Number(count) || 0;
  for (const node of $$('[data-bag-count]')) {
    node.textContent = String(n);
    node.hidden = n === 0;
  }
  try {
    sessionStorage.setItem(BAG_KEY, String(n));
  } catch {
    /* private mode — the badge just re-fetches next page load */
  }
}

export async function refreshBag() {
  try {
    const { cart } = await api.get('/api/cart');
    setBagCount(cart.count);
    return cart;
  } catch {
    return null;
  }
}

/* ---------------------------------------------------------------- header */

function wireHeader() {
  const head = $('.site-head');
  const burger = $('.burger-btn');
  if (head && burger) {
    burger.addEventListener('click', () => {
      const open = head.classList.toggle('open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && head.classList.contains('open')) {
        head.classList.remove('open');
        burger.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Mark the current section in the nav.
  const path = location.pathname;
  for (const link of $$('.site-nav a')) {
    const href = link.getAttribute('href') || '';
    if (href === path || (href !== '/' && path.startsWith(href))) {
      link.setAttribute('aria-current', 'page');
    }
  }

  try {
    const cached = sessionStorage.getItem(BAG_KEY);
    if (cached) setBagCount(cached);
  } catch {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ boot */

let bootPromise = null;

/** Ensures a CSRF cookie exists before any mutating request is attempted. */
export function boot() {
  if (!bootPromise) {
    bootPromise = (async () => {
      wireHeader();
      if (!csrfToken()) {
        try {
          await fetch('/api/csrf', { credentials: 'same-origin' });
        } catch {
          /* handled per-request */
        }
      }
      refreshBag();
    })();
  }
  return bootPromise;
}

/** Wraps a submit handler with disabled-button + error-surface plumbing. */
export function onSubmit(form, handler) {
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = form.querySelector('[type="submit"]');
    const errorBox = form.querySelector('[data-error]');
    if (errorBox) {
      errorBox.hidden = true;
      errorBox.textContent = '';
    }
    for (const node of form.querySelectorAll('[aria-invalid]')) node.removeAttribute('aria-invalid');

    if (button) {
      button.disabled = true;
      button.dataset.label = button.textContent;
      button.textContent = 'Working…';
    }

    try {
      await handler(Object.fromEntries(new FormData(form)));
    } catch (err) {
      const message = err instanceof ApiError ? err.message : 'Something went wrong. Please try again.';
      if (errorBox) {
        errorBox.textContent = message;
        errorBox.hidden = false;
      } else {
        toast(message, 'error');
      }
      const field = err?.details?.field;
      if (field) {
        const input = form.querySelector(`[name="${CSS.escape(String(field).split('.').pop())}"]`);
        if (input) {
          input.setAttribute('aria-invalid', 'true');
          input.focus();
        }
      }
    } finally {
      if (button) {
        button.disabled = false;
        if (button.dataset.label) button.textContent = button.dataset.label;
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', boot);
