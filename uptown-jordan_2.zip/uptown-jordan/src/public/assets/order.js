import { $, api, ApiError, el, formatDate, onSubmit, render, shot } from './app.js';

const form = $('#lookup-form');
const orderHost = $('[data-order]');
const params = new URLSearchParams(location.search);

const STATUS_COPY = {
  pending: 'We have your order and are preparing it.',
  paid: 'Payment received. Your order is being packed.',
  processing: 'Being packed in the studio.',
  shipped: 'On its way with the courier.',
  delivered: 'Delivered. Thank you.',
  cancelled: 'This order was cancelled.',
  refunded: 'This order was refunded.',
};

function orderView(order) {
  return el('div', [
    el('div.panel', { style: 'margin-bottom:22px' }, [
      el('div', { style: 'display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between' }, [
        el('div', [
          el('p', { style: 'font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:var(--muted-2)' }, 'Order'),
          el('h2', { style: 'font-size:22px;font-weight:800;letter-spacing:-.01em' }, order.number),
          el('p', { style: 'font-size:13px;color:var(--muted-2);margin-top:4px' }, `Placed ${formatDate(order.placedAt)}`),
        ]),
        el(`span.state.${order.status}`, order.status),
      ]),
      el('p', { style: 'margin-top:16px;color:var(--muted)' }, STATUS_COPY[order.status] || ''),
    ]),

    el('div', { style: 'display:grid;gap:22px;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);align-items:start' }, [
      el('div.panel', [
        el('h3', { style: 'font-size:14px;font-weight:600;margin-bottom:8px' }, 'Items'),
        ...order.items.map((item) =>
          el('div.line', { style: 'grid-template-columns:64px 1fr auto' }, [
            el('div.thumb', { style: 'width:64px' }, shot(item.imageUrl, item.productTitle)),
            el('div', [
              el('b', item.productTitle),
              el('div.sub', item.variantLabel),
              el('div.sub', `×${item.qty} at ${item.unit} JOD`),
            ]),
            el('b', `${item.line} JOD`),
          ])
        ),
        el('div.totals', { style: 'margin-top:18px' }, [
          el('div', [el('span', 'Subtotal'), el('span', `${order.subtotal} JOD`)]),
          el('div', [el('span', 'Delivery'), el('span', order.shipping === 'Free' ? 'Free' : `${order.shipping} JOD`)]),
          order.taxFils > 0 ? el('div', [el('span', 'Tax'), el('span', `${order.tax} JOD`)]) : null,
          el('div.grand', [el('span', 'Total'), el('span', `${order.total} JOD`)]),
        ]),
        el('p', { style: 'margin-top:12px;font-size:12.5px;color:var(--muted-2)' },
          order.paymentMethod === 'cod'
            ? `Cash on delivery · ${order.paymentStatus === 'paid' ? 'settled' : 'pay the courier on arrival'}`
            : `Card payment · ${order.paymentStatus}`),
      ]),

      el('div', { style: 'display:flex;flex-direction:column;gap:22px' }, [
        el('div.panel', [
          el('h3', { style: 'font-size:14px;font-weight:600;margin-bottom:12px' }, 'Delivering to'),
          el('p', { style: 'font-size:13.5px;color:var(--muted);line-height:1.8' }, [
            order.address.fullName, el('br'),
            order.address.street, el('br'),
            order.address.building ? el('span', [order.address.building, el('br')]) : null,
            `${order.address.city}, ${order.address.governorate}`, el('br'),
            order.address.phone,
          ]),
        ]),
        order.timeline?.length
          ? el('div.panel', [
              el('h3', { style: 'font-size:14px;font-weight:600;margin-bottom:14px' }, 'Progress'),
              el('ul.timeline', order.timeline.map((event) =>
                el('li', [el('b', event.message), el('time', formatDate(event.at))])
              )),
            ])
          : null,
      ]),
    ]),
  ]);
}

function show(order) {
  form.hidden = true;
  orderHost.hidden = false;
  render(orderHost, orderView(order));
  $('[data-title]').textContent = params.get('placed') ? 'Order confirmed' : 'Your order';
  $('[data-eyebrow]').textContent = order.number;
  $('[data-lede]').textContent = STATUS_COPY[order.status] || '';
  document.title = `${order.number} — Uptown Jordan`;
}

onSubmit(form, async (values) => {
  const { order } = await api.post('/api/orders/lookup', {
    number: values.number.trim().toUpperCase(),
    token: values.token.trim(),
  });
  show(order);
});

/* A just-placed order carries its tracking code in sessionStorage, so the
   confirmation page resolves without asking the customer to type anything. */
(function init() {
  if (params.get('placed')) $('[data-placed]').hidden = false;

  let stored = null;
  try {
    stored = JSON.parse(sessionStorage.getItem('uj_last_order') || 'null');
  } catch {
    stored = null;
  }

  const number = params.get('number') || stored?.number;
  if (number) $('#number').value = number;

  if (stored?.number && stored?.token && (!params.get('number') || params.get('number') === stored.number)) {
    $('#token').value = stored.token;
    api
      .post('/api/orders/lookup', { number: stored.number, token: stored.token })
      .then(({ order }) => show(order))
      .catch(() => { /* fall back to the manual form */ });
  }
})();
