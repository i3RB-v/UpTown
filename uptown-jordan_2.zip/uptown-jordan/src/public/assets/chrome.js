/** Footer odds and ends shared by every page. */
import { $, $$, api, onSubmit } from './app.js';

const year = $('[data-year]');
if (year) year.textContent = String(new Date().getFullYear());

// The WhatsApp number is configuration, not markup — fetched so it can be
// changed in one place (the environment) rather than in nine HTML files.
api
  .get('/api/config')
  .then(({ store }) => {
    for (const node of $$('[data-whatsapp]')) {
      node.href = `https://wa.me/${encodeURIComponent(store.supportWhatsapp)}`;
      node.rel = 'noopener noreferrer';
      node.target = '_blank';
    }
  })
  .catch(() => {
    for (const node of $$('[data-whatsapp]')) node.remove();
  });

/* ------------------------------------------------------------- newsletter */

/**
 * Footer signup. Double opt-in, so the response is always "check your email"
 * — and it is the same response whether the address is new or already on the
 * list, so the form cannot be used to test who is subscribed.
 */
const signupForm = $('#newsletter-form');

if (signupForm) {
  const note = $('[data-newsletter-note]');

  onSubmit(signupForm, async (values) => {
    const result = await api.post('/api/newsletter', { email: values.email });
    signupForm.reset();
    if (note) {
      note.textContent = result.message;
      note.style.color = 'var(--green)';
    }

    // Without a mail provider there is no link to click, so development mode
    // returns it and we surface it rather than leaving the flow dead-ended.
    if (result.devConfirmUrl && note) {
      const link = document.createElement('a');
      link.href = result.devConfirmUrl;
      link.textContent = 'Confirm now (development only)';
      link.className = 'link';
      note.append(document.createElement('br'), link);
    }
  });
}
