import { el } from './app.js';

const PATH =
  'M12 2.6l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.4l-5.8 3.1 1.1-6.5L2.6 9.4l6.5-.9z';

/**
 * A row of five stars.
 *
 * Rounded to the nearest whole star for the mark itself; the precise average
 * is always written alongside as text, so the visual never overstates the
 * number. The whole row carries an aria-label, and the individual stars are
 * hidden from assistive tech — a screen reader should hear "rated 4.3 out of
 * 5", not "star star star star star".
 */
export function stars(value, { size = '' } = {}) {
  const filled = Math.round(Number(value) || 0);
  const row = el(`span.stars${size ? ` ${size}` : ''}`, {
    role: 'img',
    'aria-label': `Rated ${Number(value).toFixed(1)} out of 5`,
  });

  for (let i = 1; i <= 5; i += 1) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', PATH);
    path.setAttribute('class', i <= filled ? 'on' : 'off');
    svg.append(path);
    row.append(svg);
  }
  return row;
}

/** Compact "★★★★☆ 4.3 (12)" line for product cards and headers. */
export function ratingLine(rating, { size = '' } = {}) {
  if (!rating || !rating.count) return null;
  return el('div.rating-row', [
    stars(rating.average, { size }),
    el('span', `${rating.average.toFixed(1)}`),
    el('span', { style: 'color:var(--muted-2)' }, `(${rating.count})`),
  ]);
}
