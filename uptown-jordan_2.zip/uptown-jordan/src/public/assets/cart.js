import { $, api, ApiError, el, render, setBagCount, shot, toast } from './app.js';

const linesHost = $('[data-lines]');
const summaryHost = $('[data-summary]');
const issuesBox = $('[data-issues]');
const errorBox = $('[data-error]');
const layout = $('[data-layout]');

let busy = false;

async function mutate(fn) {
  if (busy) return;
  busy = true;
  linesHost.style.opacity = '.55';
  try {
    const data = await fn();
    paint(data.cart);
  } catch (err) {
    toast(err instanceof ApiError ? err.message : 'Could not update your bag.', 'error');
    await load();
  } finally {
    busy = false;
    linesHost.style.opacity = '';
  }
}

function lineRow(line) {
  const qtyLabel = el('span', { 'aria-live': 'polite' }, String(line.qty));

  const step = (delta) =>
    el('button', {
      type: 'button',
      'aria-label': delta > 0 ? `Increase quantity of ${line.productTitle}` : `Decrease quantity of ${line.productTitle}`,
      disabled: delta > 0 ? line.qty >= line.maxQty : false,
      onclick: () =>
        mutate(() =>
          api.patch(`/api/cart/items/${line.variantId}`, { qty: line.qty + delta })
        ),
    }, delta > 0 ? '+' : '−');

  return el('div.line', [
    el('a.thumb', { href: `/product/${line.productSlug}` }, shot(line.imageUrl, line.productTitle)),
    el('div', [
      el('a', { href: `/product/${line.productSlug}` }, el('b', line.productTitle)),
      el('div.sub', line.variantLabel),
      el('div.sub', { style: 'margin-top:6px' }, `${line.unit} JOD each`),
      el('button', {
        type: 'button',
        style: 'margin-top:10px;background:none;border:0;padding:0;color:var(--muted-2);font-size:12.5px;cursor:pointer;text-decoration:underline',
        onclick: () => mutate(() => api.delete(`/api/cart/items/${line.variantId}`)),
      }, 'Remove'),
    ]),
    el('div.right', [
      el('div.qty', [step(-1), qtyLabel, step(1)]),
      el('b', { style: 'font-size:15px' }, `${line.line} JOD`),
    ]),
  ]);
}

function summary(cart) {
  if (!cart.lines.length) return el('div');

  return el('div', [
    el('h2', { style: 'font-size:15px;font-weight:600;margin-bottom:18px' }, 'Summary'),
    el('div.totals', [
      el('div', [el('span', 'Subtotal'), el('span', `${cart.subtotal} JOD`)]),
      el('div', [
        el('span', 'Delivery'),
        el('span', { class: cart.shipping.freeShippingApplied ? 'free' : '' },
          cart.shipping.freeShippingApplied ? 'Free' : `${cart.shippingLabel} JOD`),
      ]),
      cart.taxFils > 0 ? el('div', [el('span', 'Tax'), el('span', `${cart.tax} JOD`)]) : null,
      el('div.grand', [el('span', 'Total'), el('span', `${cart.total} JOD`)]),
    ]),

    !cart.shipping.freeShippingApplied
      ? el('p', { style: 'margin-top:14px;font-size:12.5px;color:var(--muted-2)' },
          `Spend ${((cart.shipping.freeShippingThresholdFils - cart.subtotalFils) / 1000).toFixed(3)} JOD more for free delivery.`)
      : null,

    el('a.btn.block', { href: '/checkout', style: 'margin-top:20px' }, 'Continue to checkout'),
    el('a.btn-ghost', { href: '/shop', style: 'margin-top:10px;display:grid;text-align:center' }, 'Keep shopping'),

    el('p', { style: 'margin-top:18px;font-size:12px;color:var(--muted-2);line-height:1.6' },
      'Delivery is calculated at checkout from your governorate. Cash on delivery is available across Jordan.'),
  ]);
}

function paint(cart) {
  setBagCount(cart.count);
  linesHost.setAttribute('aria-busy', 'false');

  if (cart.issues?.length) {
    issuesBox.textContent = cart.issues.map((i) => i.message).join(' ');
    issuesBox.hidden = false;
  } else {
    issuesBox.hidden = true;
  }

  if (!cart.lines.length) {
    layout.style.gridTemplateColumns = '1fr';
    render(summaryHost, []);
    summaryHost.hidden = true;
    render(linesHost, el('div.empty', [
      el('h3', 'Your bag is empty'),
      el('p', 'Nothing in here yet — the new drop is a good place to start.'),
      el('a.btn', { href: '/shop?collection=arrivals', style: 'margin-top:22px' }, 'Shop new arrivals'),
    ]));
    return;
  }

  layout.style.gridTemplateColumns = '';
  summaryHost.hidden = false;
  render(linesHost, cart.lines.map(lineRow));
  render(summaryHost, summary(cart));
}

async function load() {
  try {
    const { cart } = await api.get('/api/cart');
    paint(cart);
  } catch (err) {
    linesHost.setAttribute('aria-busy', 'false');
    errorBox.textContent = err instanceof ApiError ? err.message : 'Could not load your bag.';
    errorBox.hidden = false;
  }
}

render(linesHost, Array.from({ length: 2 }, () =>
  el('div.line', [
    el('div.thumb.skeleton'),
    el('div', [el('div.skeleton', { style: 'height:16px;width:60%;margin-bottom:8px' }), el('div.skeleton', { style: 'height:13px;width:35%' })]),
    el('div'),
  ])
));
load();
