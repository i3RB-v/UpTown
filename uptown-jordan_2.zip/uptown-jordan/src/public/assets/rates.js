/**
 * Fills the delivery table from the live store configuration.
 *
 * The rates on this page are the same numbers checkout charges, read from one
 * place — so a published policy page cannot drift out of step with what
 * customers are actually billed.
 */
import { $, api, el, render } from './app.js';

const table = $('[data-rates] tbody');
const threshold = $('[data-free-threshold]');

api
  .get('/api/config')
  .then(({ store, governorates }) => {
    if (threshold) {
      threshold.textContent = `free over ${(store.freeShippingThresholdFils / 1000).toFixed(3)} ${store.currency}`;
    }

    render(
      table,
      governorates.map((gov) =>
        el('tr', [
          el('td.row-head', gov.name),
          el('td', `${(gov.feeFils / 1000).toFixed(3)} ${store.currency}`),
          el('td', gov.sameDay
            ? 'Same day, or next working day'
            : `${gov.etaDays[0]}–${gov.etaDays[1]} working days`),
        ])
      )
    );
  })
  .catch(() => {
    render(table, el('tr', el('td', { colspan: '3', style: 'color:var(--muted-2)' },
      'Rates are shown at checkout once you choose your governorate.')));
  });
