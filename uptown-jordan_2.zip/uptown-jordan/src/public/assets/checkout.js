import { $, api, ApiError, el, onSubmit, render, shot, toast } from './app.js';

const form = $('#checkout-form');
const summaryHost = $('[data-summary]');
const govSelect = $('#governorate');
const savedHost = $('[data-saved-addresses]');

let cart = null;

/**
 * An idempotency key generated once per page load and reused across retries.
 * If the customer double-taps, or the network drops after the server has booked
 * the order, the retry returns the *same* order instead of placing a second.
 */
const idempotencyKey = (() => {
  const key = 'uj_checkout_key';
  try {
    let existing = sessionStorage.getItem(key);
    if (!existing) {
      existing = crypto.randomUUID();
      sessionStorage.setItem(key, existing);
    }
    return existing;
  } catch {
    return crypto.randomUUID();
  }
})();

function summary(data) {
  if (!data.lines.length) {
    return el('div.empty', [
      el('h3', 'Your bag is empty'),
      el('a.btn', { href: '/shop', style: 'margin-top:18px' }, 'Shop the collection'),
    ]);
  }

  return el('div', [
    el('h2', { style: 'font-size:15px;font-weight:600;margin-bottom:16px' }, `Your bag (${data.count})`),
    el('div', { style: 'display:flex;flex-direction:column;gap:14px;margin-bottom:20px' },
      data.lines.map((line) =>
        el('div', { style: 'display:grid;grid-template-columns:52px 1fr auto;gap:12px;align-items:center' }, [
          el('div', { style: 'width:52px;aspect-ratio:3/4;border-radius:8px;overflow:hidden;background:#131a24' },
            shot(line.imageUrl, line.productTitle)),
          el('div', [
            el('div', { style: 'font-size:13.5px;font-weight:600' }, line.productTitle),
            el('div', { style: 'font-size:12px;color:var(--muted-2)' }, `${line.variantLabel} · ×${line.qty}`),
          ]),
          el('div', { style: 'font-size:13.5px;font-variant-numeric:tabular-nums' }, `${line.line}`),
        ])
      )),

    el('div.totals', { style: 'border-top:1px solid var(--hair-2);padding-top:16px' }, [
      el('div', [el('span', 'Subtotal'), el('span', `${data.subtotal} JOD`)]),
      el('div', [
        el('span', 'Delivery'),
        el('span', { class: data.shipping.freeShippingApplied ? 'free' : '' },
          data.shipping.freeShippingApplied ? 'Free' : `${data.shippingLabel} JOD`),
      ]),
      data.taxFils > 0 ? el('div', [el('span', 'Tax'), el('span', `${data.tax} JOD`)]) : null,
      el('div.grand', [el('span', 'Total'), el('span', `${data.total} JOD`)]),
    ]),

    data.shipping.governorateName
      ? el('p', { style: 'margin-top:14px;font-size:12.5px;color:var(--muted-2)' },
          `Delivering to ${data.shipping.governorateName} · about ${data.shipping.etaDays[0]}–${data.shipping.etaDays[1]} days`)
      : el('p', { style: 'margin-top:14px;font-size:12.5px;color:var(--muted-2)' },
          'Choose a governorate to see the delivery cost.'),

    el('a', { href: '/cart', class: 'link', style: 'display:inline-block;margin-top:14px;font-size:13px' }, 'Edit bag'),
  ]);
}

async function refreshTotals() {
  const governorate = govSelect.value || '';
  const method = form.querySelector('[name="paymentMethod"]:checked')?.value || 'cod';
  const query = new URLSearchParams({ paymentMethod: method });
  if (governorate) query.set('governorate', governorate);

  try {
    const data = await api.get(`/api/cart?${query}`);
    cart = data.cart;
    summaryHost.setAttribute('aria-busy', 'false');
    render(summaryHost, summary(cart));
    form.querySelector('[type="submit"]').disabled = cart.lines.length === 0;
  } catch (err) {
    summaryHost.setAttribute('aria-busy', 'false');
    render(summaryHost, el('div.notice.error', err instanceof ApiError ? err.message : 'Could not load your bag.'));
  }
}

async function loadConfig() {
  const { governorates } = await api.get('/api/config');
  for (const gov of governorates) {
    govSelect.append(
      el('option', { value: gov.code }, `${gov.name} — ${(gov.feeFils / 1000).toFixed(3)} JOD`)
    );
  }
}

/** Offer the signed-in customer their saved addresses as one-tap fills. */
async function loadSavedAddresses() {
  try {
    const { user } = await api.get('/api/me');
    if (!user) return;

    $('#email').value = user.email || '';
    if (user.phone) {
      $('#phone').value = user.phone;
      $('#shipPhone').value = user.phone;
    }
    if (user.fullName) $('#fullName').value = user.fullName;

    const { addresses } = await api.get('/api/account/addresses');
    if (!addresses.length) return;

    render(savedHost, [
      el('p', { style: 'font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted-2);margin-bottom:10px' }, 'Saved addresses'),
      el('div', { style: 'display:flex;flex-wrap:wrap;gap:8px' },
        addresses.map((address) =>
          el('button.chip', {
            type: 'button',
            onclick: () => {
              $('#fullName').value = address.fullName;
              $('#shipPhone').value = address.phone;
              govSelect.value = address.governorate;
              $('#city').value = address.city;
              $('#street').value = address.street;
              $('#building').value = address.building || '';
              $('#notes').value = address.notes || '';
              refreshTotals();
            },
          }, address.label || `${address.city}, ${address.governorate}`)
        )),
    ]);
    savedHost.hidden = false;

    const preferred = addresses.find((a) => a.isDefault) || addresses[0];
    if (preferred && !govSelect.value) {
      $('#fullName').value = preferred.fullName;
      $('#shipPhone').value = preferred.phone;
      govSelect.value = preferred.governorate;
      $('#city').value = preferred.city;
      $('#street').value = preferred.street;
      $('#building').value = preferred.building || '';
    }
  } catch {
    /* guests check out without any of this */
  }
}

govSelect.addEventListener('change', refreshTotals);
for (const radio of form.querySelectorAll('[name="paymentMethod"]')) {
  radio.addEventListener('change', refreshTotals);
}

onSubmit(form, async (values) => {
  if (!cart || !cart.lines.length) throw new ApiError(400, 'empty', 'Your bag is empty.');

  const payload = {
    email: values.email,
    phone: values.phone,
    paymentMethod: values.paymentMethod,
    shipping: {
      fullName: values.fullName,
      phone: values.shipPhone,
      governorate: values.governorate,
      city: values.city,
      street: values.street,
      building: values.building || '',
      notes: values.notes || '',
    },
    // Sent so the server can refuse the order if the price moved under us.
    // The server recomputes the real total regardless — this only decides
    // whether the customer is shown a "your bag changed" message.
    expectedTotalFils: cart.totalFils,
  };

  const result = await api.post('/api/checkout', payload, {
    headers: { 'Idempotency-Key': idempotencyKey },
  });

  try {
    sessionStorage.removeItem('uj_checkout_key');
    sessionStorage.setItem('uj_last_order', JSON.stringify({
      number: result.order.number,
      token: result.lookupToken,
    }));
  } catch {
    /* the confirmation page falls back to manual lookup */
  }

  if (result.payment?.redirectUrl) {
    location.href = result.payment.redirectUrl;
    return;
  }

  location.href = `/order?number=${encodeURIComponent(result.order.number)}&placed=1`;
});

(async function init() {
  await loadConfig();
  await loadSavedAddresses();
  await refreshTotals();
})();
