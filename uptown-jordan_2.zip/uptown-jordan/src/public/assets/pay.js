import { $, api, ApiError, el, render } from './app.js';

const reference = decodeURIComponent(location.pathname.split('/').filter(Boolean).pop() || '');
const intentHost = $('[data-intent]');
const actionsHost = $('[data-actions]');
const errorBox = $('[data-error]');

async function complete(outcome, button) {
  button.disabled = true;
  const label = button.textContent;
  button.textContent = 'Processing…';
  try {
    const result = await api.post(`/api/pay/${encodeURIComponent(reference)}/complete`, { outcome });
    location.href = `/order?number=${encodeURIComponent(result.orderNumber)}&placed=1`;
  } catch (err) {
    errorBox.textContent = err instanceof ApiError ? err.message : 'Payment could not be completed.';
    errorBox.hidden = false;
    button.disabled = false;
    button.textContent = label;
  }
}

(async function init() {
  try {
    const intent = await api.get(`/api/pay/${encodeURIComponent(reference)}/intent`);
    intentHost.setAttribute('aria-busy', 'false');
    render(intentHost, [
      el('p', { style: 'font-size:12.5px;color:var(--muted-2)' }, `Order ${intent.orderNumber}`),
      el('p', { style: 'font-size:34px;font-weight:800;letter-spacing:-.02em;margin-top:6px' },
        `${intent.amount} ${intent.currency}`),
      el('p', { style: 'font-size:13px;color:var(--muted);margin-top:10px' },
        'Confirm to complete this payment. The order is only marked paid once our server receives a signed confirmation from the provider.'),
    ]);

    render(actionsHost, [
      el('button.btn.block', { type: 'button', onclick: (e) => complete('succeed', e.currentTarget) }, 'Confirm payment'),
      el('button.btn-ghost.block', { type: 'button', onclick: (e) => complete('fail', e.currentTarget) }, 'Simulate a declined card'),
    ]);
  } catch (err) {
    intentHost.setAttribute('aria-busy', 'false');
    render(intentHost, []);
    errorBox.textContent = err instanceof ApiError ? err.message : 'This payment session could not be loaded.';
    errorBox.hidden = false;
    render(actionsHost, el('a.btn-ghost.block', { href: '/cart' }, 'Back to your bag'));
  }
})();
