import { $, api, ApiError, el, render, shot, toast } from './app.js';
import { ratingLine } from './stars.js';

const grid = $('[data-grid]');
const chipHost = $('[data-chips]');
const moreHost = $('[data-more]');
const errorBox = $('[data-error]');
const searchInput = $('#search');
const sortSelect = $('#sort');

const params = new URLSearchParams(location.search);
const state = {
  collection: params.get('collection') || null,
  search: params.get('q') || '',
  sort: 'featured',
  offset: 0,
  limit: 12,
  total: 0,
};
searchInput.value = state.search;

function skeletons(n = 8) {
  return Array.from({ length: n }, () =>
    el('div.card', el('div.shot.skeleton.sk-card'))
  );
}

function productCard(p) {
  const tags = [];
  if (!p.inStock) tags.push(el('span.tag.soldout', 'Sold out'));
  else if (p.discountPercent > 0) tags.push(el('span.tag.sale', `-${p.discountPercent}%`));
  else if (p.badge) tags.push(el(`span.tag${p.badge === 'NEW' ? '.new' : ''}`, p.badge));

  return el('a.card', { href: `/product/${p.slug}`, 'aria-label': p.title }, [
    el('div.shot', [...tags, p.image ? shot(p.image.url, p.image.alt) : null]),
    el('div.meta', [
      el('b', p.title),
      el('i', p.subtitle || ''),
      // Absent entirely until real customers have reviewed it.
      ratingLine(p.rating),
      el('div.price', [
        `${p.price} JOD`,
        p.compareAt ? el('s', `${p.compareAt} JOD`) : null,
      ]),
    ]),
  ]);
}

async function loadCollections() {
  try {
    const { collections } = await api.get('/api/collections');
    const chips = [
      el('button.chip', {
        type: 'button',
        'aria-pressed': state.collection ? 'false' : 'true',
        onclick: () => choose(null),
      }, 'Everything'),
      ...collections.map((c) =>
        el('button.chip', {
          type: 'button',
          'aria-pressed': state.collection === c.slug ? 'true' : 'false',
          onclick: () => choose(c.slug),
        }, c.title)
      ),
    ];
    render(chipHost, chips);
    applyHeading(collections);
  } catch {
    /* the grid still works without the chips */
  }
}

function applyHeading(collections) {
  const found = collections.find((c) => c.slug === state.collection);
  $('[data-title]').textContent = found ? found.title : 'Everything';
  $('[data-eyebrow]').textContent = found ? 'Collection' : 'The collection';
  if (found?.subtitle) $('[data-lede]').textContent = found.subtitle;
  document.title = `${found ? found.title : 'Shop'} — Uptown Jordan`;
}

function choose(slug) {
  state.collection = slug;
  state.offset = 0;
  const url = new URL(location.href);
  if (slug) url.searchParams.set('collection', slug);
  else url.searchParams.delete('collection');
  history.replaceState(null, '', url);
  for (const chip of chipHost.children) chip.setAttribute('aria-pressed', 'false');
  loadCollections();
  load({ replace: true });
}

async function load({ replace = false } = {}) {
  errorBox.hidden = true;
  if (replace) {
    render(grid, skeletons());
    grid.setAttribute('aria-busy', 'true');
    render(moreHost, []);
  }

  const query = new URLSearchParams({
    limit: String(state.limit),
    offset: String(state.offset),
    sort: state.sort,
  });
  if (state.collection) query.set('collection', state.collection);
  if (state.search) query.set('search', state.search);

  try {
    const data = await api.get(`/api/products?${query}`);
    state.total = data.total;

    const cards = data.items.map(productCard);
    if (replace) render(grid, cards);
    else for (const card of cards) grid.append(card);

    grid.setAttribute('aria-busy', 'false');

    if (!data.items.length && replace) {
      render(grid, []);
      grid.append(
        el('div.empty', { style: 'grid-column:1/-1' }, [
          el('h3', 'Nothing here yet'),
          el('p', state.search ? `No pieces match “${state.search}”.` : 'This collection is being restocked.'),
        ])
      );
    }

    const shown = state.offset + data.items.length;
    render(
      moreHost,
      shown < data.total
        ? el('button.btn-ghost', {
            type: 'button',
            onclick: (e) => {
              e.currentTarget.disabled = true;
              state.offset += state.limit;
              load();
            },
          }, `Load more (${data.total - shown} left)`)
        : []
    );
  } catch (err) {
    grid.setAttribute('aria-busy', 'false');
    errorBox.textContent = err instanceof ApiError ? err.message : 'Could not load the collection.';
    errorBox.hidden = false;
  }
}

let searchTimer;
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    state.search = searchInput.value.trim();
    state.offset = 0;
    load({ replace: true });
  }, 280);
});

sortSelect.addEventListener('change', () => {
  state.sort = sortSelect.value;
  state.offset = 0;
  load({ replace: true });
});

render(grid, skeletons());
loadCollections();
load({ replace: true });
