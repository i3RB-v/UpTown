import { $, api, ApiError, el, render } from './app.js';

const token = new URLSearchParams(location.search).get('token');
const title = $('[data-title]');
const message = $('[data-message]');
const actions = $('[data-actions]');

const shopButtons = () => [
  el('a.btn', { href: '/shop?collection=arrivals' }, 'Shop new arrivals'),
  el('a.btn-ghost', { href: '/' }, 'Back to the store'),
];

if (!token) {
  title.textContent = 'Link incomplete';
  message.textContent = 'That confirmation link is missing its token. Try the link in your email again.';
  render(actions, shopButtons());
} else {
  api
    .post('/api/newsletter/confirm', { token })
    .then((result) => {
      title.textContent = "You're in";
      message.textContent = result.message;
      render(actions, shopButtons());
    })
    .catch((err) => {
      title.textContent = 'Link not valid';
      message.textContent =
        err instanceof ApiError ? err.message : 'That link could not be confirmed.';
      render(actions, shopButtons());
    });
}
