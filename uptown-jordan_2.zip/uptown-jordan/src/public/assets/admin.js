import { $, api, ApiError, el, formatDate, render, toast } from './app.js';

const statsHost = $('[data-stats]');
const ordersBody = $('[data-orders]');
const inventoryBody = $('[data-inventory]');
const auditBody = $('[data-audit]');
const errorBox = $('[data-error]');

let isAdmin = false;

function fail(message) {
  errorBox.textContent = message;
  errorBox.hidden = false;
}

/* ------------------------------------------------------------------ stats */

async function loadStats() {
  const stats = await api.get('/api/admin/stats');
  statsHost.setAttribute('aria-busy', 'false');
  render(statsHost, [
    el('div.stat', [el('div.k', 'Revenue · 30 days'), el('div.v', [stats.revenue, el('small', 'JOD')])]),
    el('div.stat', [el('div.k', 'Orders · 30 days'), el('div.v', String(stats.orderCount))]),
    el('div.stat', [el('div.k', 'Open orders'), el('div.v', String(stats.openOrders))]),
    el('div.stat', [
      el('div.k', 'Low stock'),
      el('div.v', String(stats.lowStock.length)),
      stats.lowStock.length
        ? el('div', { style: 'margin-top:8px;font-size:12px;color:var(--muted-2);line-height:1.6' },
            stats.lowStock.slice(0, 4).map((item) =>
              el('div', `${item.title} · ${item.size} — ${item.available} left`)))
        : null,
    ]),
  ]);
  return stats;
}

/* ----------------------------------------------------------------- orders */

const ACTIONS = {
  pending: [['mark_paid', 'Mark paid'], ['mark_shipped', 'Ship'], ['cancel', 'Cancel']],
  paid: [['mark_shipped', 'Ship'], ['cancel', 'Cancel']],
  processing: [['mark_shipped', 'Ship'], ['cancel', 'Cancel']],
  shipped: [['mark_delivered', 'Delivered']],
  delivered: [],
  cancelled: [],
  refunded: [],
};

async function transition(orderId, action, button) {
  if (action === 'cancel' && !confirm('Cancel this order and return its stock?')) return;
  button.disabled = true;
  try {
    await api.post(`/api/admin/orders/${orderId}/transition`, { action });
    toast('Order updated.', 'ok');
    await Promise.all([loadOrders(), loadStats(), loadInventory()]);
  } catch (err) {
    toast(err instanceof ApiError ? err.message : 'Could not update that order.', 'error');
    button.disabled = false;
  }
}

function orderRow(order) {
  const actions = ACTIONS[order.status] || [];
  return el('tr', [
    el('td', el('b', order.number)),
    el('td', [order.customer, el('div', { style: 'font-size:12px;color:var(--muted-2)' }, order.email)]),
    el('td', order.governorate),
    el('td', order.paymentMethod === 'cod' ? 'COD' : `Card · ${order.paymentStatus}`),
    el('td', el(`span.state.${order.status}`, order.status)),
    el('td.num', `${order.total} JOD`),
    el('td', el('div', { style: 'display:flex;gap:6px;justify-content:flex-end' },
      actions.map(([action, label]) =>
        el('button.btn-ghost.sm', {
          type: 'button',
          onclick: (event) => transition(order.id, action, event.currentTarget),
        }, label)))),
  ]);
}

async function loadOrders() {
  const query = new URLSearchParams();
  const search = $('#order-search').value.trim();
  const status = $('#order-status').value;
  if (search) query.set('search', search);
  if (status) query.set('status', status);

  const data = await api.get(`/api/admin/orders?${query}`);
  render(ordersBody, data.items.length
    ? data.items.map(orderRow)
    : el('tr', el('td', { colspan: '7', style: 'color:var(--muted-2)' }, 'No orders match.')));
}

/* -------------------------------------------------------------- inventory */

async function loadInventory() {
  const data = await api.get('/api/admin/products?limit=60');
  const rows = [];

  for (const product of data.items) {
    for (const variant of product.variants) {
      const input = el('input', {
        type: 'number',
        min: '0',
        value: String(variant.stock ?? variant.maxQty),
        style: 'width:84px;text-align:right;padding:7px 9px',
        'aria-label': `Stock for ${product.title} ${variant.size}`,
      });
      input.addEventListener('change', async () => {
        input.disabled = true;
        try {
          await api.patch(`/api/admin/variants/${variant.id}`, {
            stock: Number(input.value),
            isActive: true,
          });
          toast(`${product.title} ${variant.size} updated.`, 'ok');
          await loadStats();
        } catch (err) {
          toast(err instanceof ApiError ? err.message : 'Could not update stock.', 'error');
        } finally {
          input.disabled = false;
        }
      });

      rows.push(el('tr', [
        el('td', product.title),
        el('td', el('code', { style: 'font-size:12px;color:var(--muted-2)' }, variant.sku)),
        el('td', variant.size),
        el('td.num', {
          style: variant.inStock ? '' : 'color:var(--red)',
        }, variant.inStock ? String(variant.available ?? variant.maxQty) : 'Sold out'),
        el('td.num', input),
      ]));
    }
  }

  render(inventoryBody, rows.length
    ? rows
    : el('tr', el('td', { colspan: '5', style: 'color:var(--muted-2)' }, 'No products yet.')));
}

/* ------------------------------------------------------------------ audit */

async function loadAudit() {
  try {
    const { entries } = await api.get('/api/admin/audit?limit=40');
    render(auditBody, entries.map((entry) =>
      el('tr', [
        el('td', { style: 'white-space:nowrap;color:var(--muted-2)' }, formatDate(entry.created_at)),
        el('td', entry.actor_email || 'system'),
        el('td', el('code', { style: 'font-size:12px' }, entry.action)),
        el('td', { style: 'color:var(--muted-2)' }, entry.detail || entry.entity_id || ''),
      ])
    ));
    $('[data-audit-section]').hidden = false;
  } catch {
    /* staff without the admin role simply do not see this section */
  }
}

/* ------------------------------------------------------------------- boot */

let searchTimer;
$('#order-search').addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadOrders().catch(() => {}), 300);
});
$('#order-status').addEventListener('change', () => loadOrders().catch(() => {}));

(async function init() {
  let me;
  try {
    me = await api.get('/api/me');
  } catch {
    location.href = `/login?next=${encodeURIComponent('/admin')}`;
    return;
  }

  if (!me.user) {
    location.href = `/login?next=${encodeURIComponent('/admin')}`;
    return;
  }
  if (!['admin', 'staff'].includes(me.user.role)) {
    fail('This area is for store staff.');
    statsHost.setAttribute('aria-busy', 'false');
    render(statsHost, []);
    render(ordersBody, []);
    render(inventoryBody, []);
    return;
  }
  isAdmin = me.user.role === 'admin';

  try {
    await Promise.all([loadStats(), loadOrders(), loadInventory()]);
    await loadExtras();
    if (isAdmin) await loadAudit();
  } catch (err) {
    if (err instanceof ApiError && err.status === 403) {
      fail(err.message === 'Two-factor verification required.'
        ? 'Two-factor verification is required. Sign in again to continue.'
        : 'This area is for store staff.');
      return;
    }
    fail('Could not load the dashboard.');
  }
})();

/* ======================================================================
   Moderation, messages and restock alerts
   ====================================================================== */

/* ---------------------------------------------------------------- reviews */

async function moderateReview(id, action, button) {
  button.disabled = true;
  try {
    await api.post(`/api/admin/reviews/${id}/moderate`, { action });
    toast(action === 'publish' ? 'Review published.' : 'Review rejected.', 'ok');
    await loadReviewQueue();
  } catch (err) {
    toast(err instanceof ApiError ? err.message : 'Could not update that review.', 'error');
    button.disabled = false;
  }
}

function reviewRow(review) {
  const isPending = review.status === 'pending';
  return el('article', {
    style: 'padding:18px 0;border-bottom:1px solid var(--hair-2)',
  }, [
    el('div', { style: 'display:flex;gap:12px;align-items:baseline;flex-wrap:wrap;margin-bottom:8px' }, [
      el('b', { style: 'font-size:14px' }, `${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}`),
      el('b', { style: 'font-size:14px' }, review.title),
      el('a.link', { href: `/product/${review.productSlug}`, style: 'font-size:12.5px' }, review.productTitle),
    ]),
    el('p', { style: 'font-size:13.5px;color:var(--muted);line-height:1.7;margin-bottom:10px' }, review.body),
    el('div', { style: 'display:flex;gap:14px;align-items:center;flex-wrap:wrap;font-size:12px;color:var(--muted-2)' }, [
      el('span', review.author || 'Unnamed'),
      review.sizeBought ? el('span', `bought ${review.sizeBought}`) : null,
      review.orderNumber ? el('span', review.orderNumber) : null,
      el('span', formatDate(review.createdAt)),
      isPending
        ? el('span', { style: 'display:flex;gap:8px;margin-left:auto' }, [
            el('button.btn-ghost.sm', {
              type: 'button',
              onclick: (e) => moderateReview(review.id, 'publish', e.currentTarget),
            }, 'Publish'),
            el('button.btn-ghost.sm.danger', {
              type: 'button',
              onclick: (e) => moderateReview(review.id, 'reject', e.currentTarget),
            }, 'Reject'),
          ])
        : el('span', { style: 'margin-left:auto' }, el(`span.state.${review.status === 'published' ? 'delivered' : 'cancelled'}`, review.status)),
    ]),
  ]);
}

async function loadReviewQueue() {
  const status = $('#review-status').value;
  const { reviews } = await api.get(`/api/admin/reviews?status=${encodeURIComponent(status)}`);
  render($('[data-review-queue]'), reviews.length
    ? reviews.map(reviewRow)
    : el('p', { style: 'color:var(--muted-2);font-size:13.5px;padding:10px 0' },
        status === 'pending' ? 'Nothing waiting. ' : 'Nothing here.'));
  $('[data-reviews-section]').hidden = false;
}

/* -------------------------------------------------------------- messages */

async function setEnquiryStatus(id, status, button) {
  button.disabled = true;
  try {
    await api.post(`/api/admin/enquiries/${id}/status`, { status });
    toast('Message updated.', 'ok');
    await loadEnquiries();
  } catch (err) {
    toast(err instanceof ApiError ? err.message : 'Could not update that message.', 'error');
    button.disabled = false;
  }
}

function enquiryRow(enquiry) {
  return el('article', { style: 'padding:18px 0;border-bottom:1px solid var(--hair-2)' }, [
    el('div', { style: 'display:flex;gap:12px;align-items:baseline;flex-wrap:wrap;margin-bottom:6px' }, [
      el('b', { style: 'font-size:14px' }, enquiry.name),
      el('span.tag', { style: 'position:static' }, enquiry.topic.toUpperCase()),
      enquiry.order_number ? el('span', { style: 'font-size:12.5px;color:var(--muted-2)' }, enquiry.order_number) : null,
    ]),
    el('p', { style: 'font-size:13.5px;color:var(--muted);line-height:1.7;margin-bottom:10px' }, enquiry.message),
    el('div', { style: 'display:flex;gap:14px;align-items:center;flex-wrap:wrap;font-size:12px;color:var(--muted-2)' }, [
      el('a.link', { href: `mailto:${enquiry.email}` }, enquiry.email),
      enquiry.phone ? el('span', enquiry.phone) : null,
      el('span', formatDate(enquiry.created_at)),
      el('span', { style: 'display:flex;gap:8px;margin-left:auto' }, [
        el('button.btn-ghost.sm', {
          type: 'button',
          onclick: (e) => setEnquiryStatus(enquiry.id, 'answered', e.currentTarget),
        }, 'Mark answered'),
        el('button.btn-ghost.sm', {
          type: 'button',
          onclick: (e) => setEnquiryStatus(enquiry.id, 'closed', e.currentTarget),
        }, 'Close'),
      ]),
    ]),
  ]);
}

async function loadEnquiries() {
  const { enquiries } = await api.get('/api/admin/enquiries?status=open');
  render($('[data-enquiries]'), enquiries.length
    ? enquiries.map(enquiryRow)
    : el('p', { style: 'color:var(--muted-2);font-size:13.5px;padding:10px 0' }, 'No open messages.'));
  $('[data-enquiries-section]').hidden = false;
}

/* --------------------------------------------------------- restock alerts */

async function loadWaiting() {
  const { waiting, newsletter } = await api.get('/api/admin/stock-alerts');

  render($('[data-waiting]'), waiting.length
    ? waiting.map((row) =>
        el('tr', [
          el('td', row.title),
          el('td', row.size),
          el('td', el('a.link', { href: `mailto:${row.email}` }, row.email)),
          el('td', { style: 'color:var(--muted-2)' }, formatDate(row.created_at)),
        ])
      )
    : el('tr', el('td', { colspan: '4', style: 'color:var(--muted-2)' },
        'Nobody is waiting on a size that is currently back in stock.')));

  const count = $('[data-newsletter-count]');
  if (count) {
    count.textContent = `Newsletter: ${newsletter.confirmed} confirmed, ${newsletter.pending} unconfirmed`;
  }
  $('[data-waiting-section]').hidden = false;
}

$('#review-status').addEventListener('change', () => loadReviewQueue().catch(() => {}));

/**
 * Loaded after the core dashboard so a failure here — a staff account without
 * permission for one of these, say — cannot blank the orders table.
 */
export async function loadExtras() {
  await Promise.allSettled([loadReviewQueue(), loadEnquiries(), loadWaiting()]);
}
