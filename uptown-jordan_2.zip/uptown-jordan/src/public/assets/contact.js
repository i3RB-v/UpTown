import { $, api, onSubmit } from './app.js';

const form = $('#contact-form');
const topic = $('#c-topic');
const orderField = $('[data-order-field]');
const sent = $('[data-sent]');

// The order-number field only appears when it is relevant, rather than
// asking everyone for something most people do not have.
const syncOrderField = () => {
  orderField.hidden = !['order', 'returns'].includes(topic.value);
};
topic.addEventListener('change', syncOrderField);
syncOrderField();

// Deep link: /contact?topic=returns preselects the reason.
const preset = new URLSearchParams(location.search).get('topic');
if (preset && [...topic.options].some((o) => o.value === preset)) {
  topic.value = preset;
  syncOrderField();
}

onSubmit(form, async (values) => {
  const result = await api.post('/api/contact', {
    name: values.name,
    email: values.email,
    phone: values.phone || '',
    topic: values.topic,
    orderNumber: values.orderNumber || '',
    message: values.message,
  });

  form.reset();
  syncOrderField();
  sent.textContent = result.message;
  sent.hidden = false;
  sent.scrollIntoView({ behavior: 'smooth', block: 'center' });
});
