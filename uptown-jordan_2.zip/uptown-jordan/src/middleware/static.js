import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { gzip as gzipCb } from 'node:zlib';
import { promisify } from 'node:util';
import config, { ROOT } from '../config.js';
import { notFound } from '../core/errors.js';

const gzip = promisify(gzipCb);

const PUBLIC_DIR = path.join(ROOT, 'src', 'public');

/**
 * Only these extensions are ever served. An allow-list rather than a
 * deny-list: a stray .env, .db, .key or backup file dropped into the public
 * folder by accident is simply not reachable over HTTP.
 */
const TYPES = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.mjs', 'text/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.svg', 'image/svg+xml'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.webp', 'image/webp'],
  ['.avif', 'image/avif'],
  ['.ico', 'image/x-icon'],
  ['.woff2', 'font/woff2'],
  ['.txt', 'text/plain; charset=utf-8'],
  ['.webmanifest', 'application/manifest+json'],
]);

const COMPRESSIBLE = new Set(['.html', '.css', '.js', '.mjs', '.json', '.svg', '.txt', '.webmanifest']);

/** In-memory cache of assembled HTML templates, keyed by absolute path. */
const htmlCache = new Map();
const partialCache = new Map();

/**
 * Expand `<!--@name-->` markers from src/public/partials/name.html.
 *
 * A deliberately dumb include: the marker name is matched against
 * /^[a-z0-9-]+$/ and resolved inside the partials directory, so a page
 * cannot include anything outside it, and partials do not nest.
 */
// `meta` is reserved: it is substituted per request in sendHtml, not from a
// partial file, so partial expansion must leave it alone.
const RESERVED_MARKERS = new Set(['meta']);

async function expandPartials(html) {
  const markers = [...html.matchAll(/<!--@([a-z0-9-]+)-->/g)];
  if (!markers.length) return html;

  let out = html;
  for (const [marker, name] of markers) {
    if (RESERVED_MARKERS.has(name)) continue;
    let partial = partialCache.get(name);
    if (partial === undefined || !config.isProd) {
      const file = path.join(PUBLIC_DIR, 'partials', `${name}.html`);
      if (!file.startsWith(path.join(PUBLIC_DIR, 'partials') + path.sep)) continue;
      try {
        partial = await readFile(file, 'utf8');
      } catch {
        partial = '';
      }
      partialCache.set(name, partial);
    }
    out = out.split(marker).join(partial);
  }
  return out;
}

function acceptsGzip(req) {
  return String(req.headers['accept-encoding'] || '').includes('gzip');
}

/**
 * Resolve a request path to a file inside PUBLIC_DIR.
 *
 * The containment check is done on the *resolved* path, which is what makes
 * symlinks and any encoding trick that survived the router unable to escape
 * the directory.
 */
function resolveSafe(relative) {
  const cleaned = relative.replace(/\0/g, '');
  const target = path.resolve(PUBLIC_DIR, `.${path.posix.resolve('/', cleaned)}`);
  if (target !== PUBLIC_DIR && !target.startsWith(PUBLIC_DIR + path.sep)) return null;
  return target;
}

async function sendFile(ctx, filePath, ext, { cacheControl }) {
  const info = await stat(filePath);
  if (!info.isFile()) throw notFound();

  const etag = `W/"${info.size.toString(16)}-${info.mtimeMs.toString(16)}"`;
  const { req, res } = ctx;

  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, { ETag: etag, 'Cache-Control': cacheControl });
    res.end();
    return;
  }

  const headers = {
    'Content-Type': TYPES.get(ext),
    'Cache-Control': cacheControl,
    ETag: etag,
    'X-Content-Type-Options': 'nosniff',
  };

  if (COMPRESSIBLE.has(ext) && acceptsGzip(req) && info.size > 512) {
    const body = await gzip(await readFile(filePath));
    res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': body.length, Vary: 'Accept-Encoding' });
    res.end(req.method === 'HEAD' ? undefined : body);
    return;
  }

  headers['Content-Length'] = info.size;
  res.writeHead(200, headers);
  if (req.method === 'HEAD') {
    res.end();
    return;
  }
  createReadStream(filePath).pipe(res);
}

/** HTML-escape a value destined for an attribute. */
function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * Build the per-page head block: canonical URL, Open Graph, Twitter card and
 * optional JSON-LD.
 *
 * This is rendered **on the server** on purpose. Link-preview crawlers —
 * WhatsApp's in particular, which is how most of this shop's links will be
 * shared — do not execute JavaScript, so metadata written by client code is
 * invisible to them.
 */
export function buildMeta({
  title,
  description,
  image,
  path = '/',
  type = 'website',
  jsonLd,
  noindex = false,
} = {}) {
  const url = `${config.origin}${path}`;
  const out = [];

  if (title) out.push(`<title>${esc(title)}</title>`);
  if (description) out.push(`<meta name="description" content="${esc(description)}">`);
  out.push(`<link rel="canonical" href="${esc(url)}">`);
  if (noindex) out.push('<meta name="robots" content="noindex, nofollow">');

  out.push(`<meta property="og:type" content="${esc(type)}">`);
  out.push(`<meta property="og:site_name" content="${esc(config.store.name)}">`);
  out.push(`<meta property="og:url" content="${esc(url)}">`);
  out.push(`<meta property="og:locale" content="en_JO">`);
  if (title) out.push(`<meta property="og:title" content="${esc(title)}">`);
  if (description) out.push(`<meta property="og:description" content="${esc(description)}">`);
  if (image) {
    out.push(`<meta property="og:image" content="${esc(image)}">`);
    out.push(`<meta name="twitter:card" content="summary_large_image">`);
    out.push(`<meta name="twitter:image" content="${esc(image)}">`);
  } else {
    out.push('<meta name="twitter:card" content="summary">');
  }
  if (title) out.push(`<meta name="twitter:title" content="${esc(title)}">`);
  if (description) out.push(`<meta name="twitter:description" content="${esc(description)}">`);

  if (jsonLd) {
    // `<` is escaped so a product title containing "</script>" cannot break
    // out of the block. JSON-LD readers unescape \u003c transparently.
    const json = JSON.stringify(jsonLd).replace(/</g, '\\u003c');
    out.push(`<script type="application/ld+json">${json}</script>`);
  }

  return out.join('\n  ');
}

/**
 * Serve an HTML page, stamping the per-request CSP nonce onto every script
 * tag. This is what lets the policy stay nonce-based (no 'unsafe-inline')
 * while the hero still carries its inline bootstrap script.
 *
 * `meta` replaces the page's `<!--@meta-->` marker with a server-rendered
 * head block (see buildMeta).
 */
export async function sendHtml(ctx, name, status = 200, meta = null) {
  const filePath = resolveSafe(name);
  if (!filePath) throw notFound();

  let template = htmlCache.get(filePath);
  if (!template || !config.isProd) {
    try {
      template = await expandPartials(await readFile(filePath, 'utf8'));
    } catch {
      throw notFound('That page could not be found.');
    }
    htmlCache.set(filePath, template);
  }

  const nonce = ctx.state.nonce || '';

  // Meta is substituted BEFORE the nonce pass, so a JSON-LD block injected
  // here also receives the nonce and satisfies the CSP.
  let body = template.replace('<!--@meta-->', meta ? buildMeta(meta) : '');
  body = body.replace(/<script\b/g, `<script nonce="${nonce}"`);

  const buf = Buffer.from(body, 'utf8');

  const headers = {
    'Content-Type': 'text/html; charset=utf-8',
    // Pages carry a per-request nonce, so they must never be cached by a
    // shared proxy and replayed to another visitor with a stale nonce.
    'Cache-Control': 'no-store, private',
    'X-Content-Type-Options': 'nosniff',
  };

  if (acceptsGzip(ctx.req)) {
    const packed = await gzip(buf);
    ctx.res.writeHead(status, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': packed.length, Vary: 'Accept-Encoding' });
    ctx.res.end(ctx.req.method === 'HEAD' ? undefined : packed);
    return;
  }

  ctx.res.writeHead(status, { ...headers, 'Content-Length': buf.length });
  ctx.res.end(ctx.req.method === 'HEAD' ? undefined : buf);
}

/** Static asset handler mounted at /assets/*. */
export function staticAssets() {
  return async function staticHandler(ctx) {
    const rest = ctx.params['*'] || '';
    const filePath = resolveSafe(path.posix.join('assets', rest));
    if (!filePath) throw notFound();

    const ext = path.extname(filePath).toLowerCase();
    if (!TYPES.has(ext)) throw notFound();

    // Assets are versioned by the ?v= query the pages append, so a long
    // immutable cache is safe and makes repeat visits free.
    const cacheControl = ctx.query.v
      ? 'public, max-age=31536000, immutable'
      : 'public, max-age=3600, must-revalidate';

    try {
      await sendFile(ctx, filePath, ext, { cacheControl });
    } catch (err) {
      if (err?.code === 'ENOENT') throw notFound();
      throw err;
    }
  };
}

/** Strong, stable build id used for cache-busting asset URLs. */
export function assetVersion() {
  return createHash('sha256')
    .update(String(process.env.BUILD_ID || config.env))
    .digest('hex')
    .slice(0, 8);
}
