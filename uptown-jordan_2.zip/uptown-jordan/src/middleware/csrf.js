import { randomBytes } from 'node:crypto';
import config from '../config.js';
import { hmac, safeEqual, sha256 } from '../core/crypto.js';
import { forbidden } from '../core/errors.js';
import { setCookie } from '../core/http.js';

/**
 * CSRF protection: signed double-submit cookie + origin checking.
 *
 * Two independent barriers have to fall for a cross-site request to succeed:
 *
 *  1. Origin / Sec-Fetch-Site. A browser sets these and script cannot forge
 *     them, so a POST from evil.com is rejected before anything is parsed.
 *  2. A token that is both HMAC-signed by the server (so it cannot be
 *     invented) and echoed from a cookie into a header (so it cannot be read
 *     cross-origin). The signature is bound to the current session id, which
 *     means a token minted before sign-in stops working after it — closing
 *     the session-fixation variant of this attack.
 *
 * SameSite=Lax on the session cookie is a third layer, but it is not relied
 * on: it is not enforced by every client, and it does not cover same-site
 * subdomain takeover.
 */

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);
const TOKEN_TTL = config.csrf.ttlMs;

function sign(nonce, bind, exp) {
  return hmac(config.secrets.csrf, `${nonce}|${bind}|${exp}`);
}

function bindingFor(ctx) {
  // Bound to the session when there is one, otherwise unbound (guests still
  // get signature + origin protection).
  const sid = ctx.cookies?.[config.session.cookie];
  return sid ? sha256(sid).slice(0, 32) : 'guest';
}

export function issueToken(ctx) {
  const nonce = randomBytes(16).toString('base64url');
  const exp = Date.now() + TOKEN_TTL;
  const token = `v1.${nonce}.${exp}.${sign(nonce, bindingFor(ctx), exp)}`;

  // Readable by script on purpose: the client copies it into a request
  // header, which is the half of the double-submit a cross-origin page
  // cannot perform.
  setCookie(ctx.res, config.csrf.cookie, token, {
    httpOnly: false,
    maxAgeMs: TOKEN_TTL,
    sameSite: 'Lax',
  });
  ctx.state.csrfToken = token;
  return token;
}

function verifyToken(ctx) {
  const header = ctx.req.headers[config.csrf.header];
  const cookie = ctx.cookies?.[config.csrf.cookie];
  if (!header || !cookie) return false;
  if (!safeEqual(header, cookie)) return false;

  const parts = String(header).split('.');
  if (parts.length !== 4 || parts[0] !== 'v1') return false;
  const [, nonce, expRaw, sig] = parts;

  const exp = Number(expRaw);
  if (!Number.isFinite(exp) || exp < Date.now()) return false;
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(nonce)) return false;

  return safeEqual(sign(nonce, bindingFor(ctx), exp), sig);
}

function originAllowed(ctx) {
  const site = ctx.req.headers['sec-fetch-site'];
  if (site && (site === 'same-origin' || site === 'none')) return true;
  if (site && site !== 'same-origin') return false;

  const origin = ctx.req.headers.origin;
  if (origin) return origin === config.origin;

  // No Origin and no Sec-Fetch-Site: fall back to Referer. Anything that
  // reaches here is an old or non-browser client, and it still needs a
  // valid signed token to proceed.
  const referer = ctx.req.headers.referer;
  if (referer) {
    try {
      return new URL(referer).origin === config.origin;
    } catch {
      return false;
    }
  }
  return false;
}

export function csrfProtection({ exempt = [] } = {}) {
  return async function csrfMiddleware(ctx, next) {
    if (SAFE_METHODS.has(ctx.rawMethod)) {
      // Refresh the token on page loads so a long-lived tab always holds a
      // usable one.
      if (!ctx.cookies?.[config.csrf.cookie]) issueToken(ctx);
      return next();
    }

    if (exempt.some((prefix) => ctx.path.startsWith(prefix))) return next();

    if (!originAllowed(ctx)) {
      throw forbidden('This request did not come from the Uptown Jordan site.');
    }
    if (!verifyToken(ctx)) {
      throw forbidden('Your session token expired. Refresh the page and try again.');
    }
    return next();
  };
}
