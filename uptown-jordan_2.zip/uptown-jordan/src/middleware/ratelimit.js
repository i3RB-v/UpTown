import config from '../config.js';
import { getDb } from '../db/index.js';
import { hmac } from '../core/crypto.js';
import { tooMany } from '../core/errors.js';
import logger from '../core/logger.js';

/**
 * Fixed-window rate limiting, stored in SQLite.
 *
 * Kept in the database rather than process memory for two reasons: limits
 * survive a restart (so an attacker cannot reset their budget by crashing or
 * waiting out a deploy), and they hold across multiple workers.
 *
 * Bucket keys are HMACed, so the table never contains a plaintext list of
 * visitor IP addresses or the email addresses people tried to log in with.
 */

const bucketKey = (name, identity) => hmac(config.secrets.session, `rl:${name}:${identity}`);

export async function consume(name, identity, max, windowMs, cost = 1) {
  const db = await getDb();
  const key = bucketKey(name, identity);
  const now = Date.now();

  return db.tx(() => {
    const row = db.get('SELECT count, window_start FROM rate_limits WHERE bucket = ?', key);

    if (!row || now - row.window_start >= windowMs) {
      db.run(
        `INSERT INTO rate_limits (bucket, count, window_start, expires_at)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(bucket) DO UPDATE SET count = excluded.count,
                                           window_start = excluded.window_start,
                                           expires_at = excluded.expires_at`,
        key, cost, now, now + windowMs
      );
      return { allowed: true, remaining: Math.max(0, max - cost), retryAfterSeconds: 0 };
    }

    if (row.count + cost > max) {
      const retryAfterSeconds = Math.max(1, Math.ceil((row.window_start + windowMs - now) / 1000));
      return { allowed: false, remaining: 0, retryAfterSeconds };
    }

    db.run('UPDATE rate_limits SET count = count + ? WHERE bucket = ?', cost, key);
    return { allowed: true, remaining: Math.max(0, max - row.count - cost), retryAfterSeconds: 0 };
  });
}

/** Undo a consumed unit — used so that a *successful* login does not
 *  count against the failed-attempt budget. */
export async function refund(name, identity, cost = 1) {
  const db = await getDb();
  const key = bucketKey(name, identity);
  db.run('UPDATE rate_limits SET count = MAX(0, count - ?) WHERE bucket = ?', cost, key);
}

/** Middleware factory. `identify` defaults to the client IP. */
export function rateLimit(name, [max, windowMs], identify) {
  return async function rateLimitMiddleware(ctx, next) {
    const identity = identify ? identify(ctx) : ctx.ip;
    const result = await consume(name, identity, max, windowMs);

    ctx.res.setHeader('RateLimit-Limit', String(max));
    ctx.res.setHeader('RateLimit-Remaining', String(result.remaining));

    if (!result.allowed) {
      logger.warn('rate limit hit', { bucket: name, path: ctx.path });
      throw tooMany('Too many requests. Please slow down and try again shortly.', {
        retryAfterSeconds: result.retryAfterSeconds,
      });
    }
    return next ? next() : undefined;
  };
}

/** Same budget logic, usable inside a handler rather than as middleware. */
export async function guard(name, identity, [max, windowMs], message) {
  const result = await consume(name, identity, max, windowMs);
  if (!result.allowed) {
    throw tooMany(message || 'Too many attempts. Please try again later.', {
      retryAfterSeconds: result.retryAfterSeconds,
    });
  }
  return result;
}
