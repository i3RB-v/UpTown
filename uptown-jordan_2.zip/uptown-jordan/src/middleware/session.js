import config from '../config.js';
import { fingerprint, randomToken, sha256, uuid } from '../core/crypto.js';
import { forbidden, unauthorized } from '../core/errors.js';
import { clearCookie, setCookie } from '../core/http.js';
import logger from '../core/logger.js';
import { getDb } from '../db/index.js';

/**
 * Server-side sessions.
 *
 * The cookie holds a 256-bit opaque token and nothing else — no user id, no
 * role, no signed claims. All state lives in the `sessions` table, which
 * means a session can be revoked instantly (logout everywhere, role change,
 * account lock) rather than remaining valid until a JWT happens to expire.
 *
 * Only the SHA-256 of the token is stored. Someone who reads the database
 * still cannot mint a cookie that authenticates as anyone.
 */

const COOKIE = config.session.cookie;

/** Write last_seen at most once a minute — otherwise every request becomes a
 *  write and the WAL churns for no benefit. */
const TOUCH_INTERVAL_MS = 60_000;

export async function loadSession(ctx) {
  const raw = ctx.cookies?.[COOKIE];
  if (!raw) return null;

  const db = await getDb();
  const id = sha256(raw);
  const now = Date.now();

  const row = db.get(
    `SELECT s.*, u.email, u.full_name, u.role AS user_role, u.status AS user_status
       FROM sessions s
       LEFT JOIN users u ON u.id = s.user_id
      WHERE s.id = ?`,
    id
  );

  if (!row) return null;

  if (row.expires_at <= now || now - row.last_seen_at > config.session.idleMs) {
    db.run('DELETE FROM sessions WHERE id = ?', id);
    clearCookie(ctx.res, COOKIE);
    return null;
  }

  // A disabled or locked account loses its sessions immediately, without
  // waiting for them to expire.
  if (row.user_id && row.user_status !== 'active') {
    db.run('DELETE FROM sessions WHERE user_id = ?', row.user_id);
    clearCookie(ctx.res, COOKIE);
    return null;
  }

  // The bound user-agent changing mid-session is a strong signal of a stolen
  // cookie. IP is deliberately *not* treated the same way — mobile networks
  // rotate addresses constantly and it would sign people out all day.
  const ua = fingerprint(ctx.req.headers['user-agent'] || '');
  if (row.ua_hash && row.ua_hash !== ua) {
    logger.warn('session user-agent mismatch; revoking', { sid: id.slice(0, 8) });
    db.run('DELETE FROM sessions WHERE id = ?', id);
    clearCookie(ctx.res, COOKIE);
    return null;
  }

  if (now - row.last_seen_at > TOUCH_INTERVAL_MS) {
    db.run('UPDATE sessions SET last_seen_at = ? WHERE id = ?', now, id);
  }

  return {
    id,
    rawId: raw,
    userId: row.user_id,
    role: row.user_id ? row.user_role : 'guest',
    mfaOk: row.mfa_ok === 1,
    createdAt: row.created_at,
    expiresAt: row.expires_at,
    user: row.user_id
      ? { id: row.user_id, email: row.email, fullName: row.full_name, role: row.user_role }
      : null,
  };
}

export function attachSession() {
  return async function sessionMiddleware(ctx, next) {
    const session = await loadSession(ctx);
    ctx.state.session = session;
    ctx.state.user = session?.user ?? null;
    return next();
  };
}

/**
 * Start a session. Always called *after* credentials are verified, and
 * always replaces any prior session id for this client — that rotation is
 * what defeats session fixation.
 */
export async function createSession(ctx, user, { mfaOk = false } = {}) {
  const db = await getDb();
  const now = Date.now();

  const previous = ctx.cookies?.[COOKIE];
  if (previous) db.run('DELETE FROM sessions WHERE id = ?', sha256(previous));

  const token = randomToken(32);
  db.run(
    `INSERT INTO sessions (id, user_id, role, ip_hash, ua_hash, mfa_ok,
                           created_at, last_seen_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    sha256(token),
    user.id,
    user.role,
    fingerprint(ctx.ip),
    fingerprint(ctx.req.headers['user-agent'] || ''),
    mfaOk ? 1 : 0,
    now,
    now,
    now + config.session.absoluteMs
  );

  setCookie(ctx.res, COOKIE, token, {
    httpOnly: true,
    sameSite: 'Lax',
    maxAgeMs: config.session.absoluteMs,
  });

  ctx.cookies[COOKIE] = token;
  ctx.state.session = { id: sha256(token), rawId: token, userId: user.id, role: user.role, mfaOk, user };
  ctx.state.user = user;
  return ctx.state.session;
}

export async function markMfaSatisfied(ctx) {
  const db = await getDb();
  const session = ctx.state.session;
  if (!session) return;
  db.run('UPDATE sessions SET mfa_ok = 1 WHERE id = ?', session.id);
  session.mfaOk = true;
}

export async function destroySession(ctx) {
  const db = await getDb();
  const raw = ctx.cookies?.[COOKIE];
  if (raw) db.run('DELETE FROM sessions WHERE id = ?', sha256(raw));
  clearCookie(ctx.res, COOKIE);
  clearCookie(ctx.res, config.csrf.cookie, { httpOnly: false });
  ctx.state.session = null;
  ctx.state.user = null;
}

/** Sign out every device for a user — used after a password change. */
export async function destroyAllSessions(userId, exceptId) {
  const db = await getDb();
  if (exceptId) db.run('DELETE FROM sessions WHERE user_id = ? AND id <> ?', userId, exceptId);
  else db.run('DELETE FROM sessions WHERE user_id = ?', userId);
}

/* ---------------------------------------------------------------- guards */

export async function requireAuth(ctx) {
  if (!ctx.state.user) throw unauthorized('Please sign in to continue.');
}

export function requireRole(...roles) {
  const allowed = new Set(roles);
  return async function roleGuard(ctx) {
    const user = ctx.state.user;
    if (!user) throw unauthorized('Please sign in to continue.');
    if (!allowed.has(user.role)) {
      logger.warn('role check failed', { path: ctx.path, role: user.role });
      // Deliberately a 404-shaped message: an unprivileged account learns
      // nothing about which admin endpoints exist.
      throw forbidden('Not found.');
    }
    // Staff and admins whose account has TOTP enrolled must have satisfied
    // it for *this* session, not merely at some point in the past.
    const db = await getDb();
    const row = db.get('SELECT totp_enabled FROM users WHERE id = ?', user.id);
    if (row?.totp_enabled === 1 && !ctx.state.session?.mfaOk) {
      throw forbidden('Two-factor verification required.');
    }
  };
}
