import { randomBytes } from 'node:crypto';
import config from '../config.js';

/**
 * Response security headers.
 *
 * The one that does real work here is the Content-Security-Policy. Its
 * script-src is nonce-based with no 'unsafe-inline' and no 'unsafe-eval',
 * which means that even if a bug let attacker text reach the DOM, the
 * browser will not execute it.
 *
 * style-src is the deliberate exception. The hero composition positions
 * dozens of elements with inline `style` attributes, and a nonce in
 * style-src would cause the browser to ignore 'unsafe-inline' and blank the
 * page. Inline *styles* are a far smaller hazard than inline *scripts*: this
 * application never renders merchant- or customer-supplied HTML, so there is
 * no path by which attacker-controlled CSS reaches a page. The strict
 * script-src is kept intact, which is where XSS actually lives.
 */
export function securityHeaders(assetOrigin = config.assetOrigin) {
  const scriptExtras = config.isTest ? " 'unsafe-inline'" : '';

  return async function securityHeadersMiddleware(ctx, next) {
    const nonce = randomBytes(16).toString('base64');
    ctx.state.nonce = nonce;

    const csp = [
      "default-src 'self'",
      `script-src 'self' 'nonce-${nonce}'${scriptExtras}`,
      `style-src 'self' 'unsafe-inline' https://fonts.googleapis.com`,
      `img-src 'self' data: blob: ${assetOrigin}`,
      `font-src 'self' https://fonts.gstatic.com`,
      "connect-src 'self'",
      "manifest-src 'self'",
      "worker-src 'self'",
      "media-src 'none'",
      "object-src 'none'",
      "base-uri 'none'",
      "form-action 'self'",
      "frame-ancestors 'none'",
      "frame-src 'none'",
    ];
    if (config.isProd) csp.push('upgrade-insecure-requests');

    const headers = {
      'Content-Security-Policy': csp.join('; '),
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Permissions-Policy':
        'accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=(), interest-cohort=()',
      'Cross-Origin-Opener-Policy': 'same-origin',
      'Cross-Origin-Resource-Policy': 'same-origin',
      'X-DNS-Prefetch-Control': 'off',
      'X-Permitted-Cross-Domain-Policies': 'none',
      'Origin-Agent-Cluster': '?1',
    };

    if (config.isProd) {
      headers['Strict-Transport-Security'] =
        'max-age=63072000; includeSubDomains; preload';
    }

    for (const [key, value] of Object.entries(headers)) {
      ctx.res.setHeader(key, value);
    }
    // Node adds no Server header by default; make sure nothing downstream
    // advertises the runtime.
    ctx.res.removeHeader?.('X-Powered-By');

    return next();
  };
}

export default securityHeaders;
